gapi.loaded_0(function(_) {
    var window = this;
    var fa, ha, ja, ka, na, pa, Ea, Sa;
    _.ea = function(a) {
        return function() {
            return _.aa[a].apply(this, arguments)
        }
    }
    ;
    _.aa = [];
    fa = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }
    ;
    ha = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype)
            return a;
        a[b] = c.value;
        return a
    }
    ;
    ja = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math)
                return c
        }
        throw Error("a");
    }
    ;
    ka = ja(this);
    na = function(a, b) {
        if (b)
            a: {
                var c = ka;
                a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c))
                        break a;
                    c = c[e]
                }
                a = a[a.length - 1];
                d = c[a];
                b = b(d);
                b != d && null != b && ha(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
    }
    ;
    na("Symbol", function(a) {
        if (a)
            return a;
        var b = function(f, h) {
            this.gS = f;
            ha(this, "description", {
                configurable: !0,
                writable: !0,
                value: h
            })
        };
        b.prototype.toString = function() {
            return this.gS
        }
        ;
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_"
          , d = 0
          , e = function(f) {
            if (this instanceof e)
                throw new TypeError("Symbol is not a constructor");
            return new b(c + (f || "") + "_" + d++,f)
        };
        return e
    });
    na("Symbol.iterator", function(a) {
        if (a)
            return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = ka[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ha(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return pa(fa(this))
                }
            })
        }
        return a
    });
    pa = function(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        }
        ;
        return a
    }
    ;
    _.Ba = function(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        return b ? b.call(a) : {
            next: fa(a)
        }
    }
    ;
    _.Ca = "function" == typeof Object.create ? Object.create : function(a) {
        var b = function() {};
        b.prototype = a;
        return new b
    }
    ;
    if ("function" == typeof Object.setPrototypeOf)
        Ea = Object.setPrototypeOf;
    else {
        var Ja;
        a: {
            var La = {
                a: !0
            }
              , Qa = {};
            try {
                Qa.__proto__ = La;
                Ja = Qa.a;
                break a
            } catch (a) {}
            Ja = !1
        }
        Ea = Ja ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b)
                throw new TypeError(a + " is not extensible");
            return a
        }
        : null
    }
    _.Ra = Ea;
    Sa = function(a, b, c) {
        if (null == a)
            throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp)
            throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    }
    ;
    na("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Sa(this, b, "startsWith")
              , e = d.length
              , f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var h = 0; h < f && c < e; )
                if (d[c++] != b[h++])
                    return !1;
            return h >= f
        }
    });
    var Ta = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
      , Ua = "function" == typeof Object.assign ? Object.assign : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d)
                    Ta(d, e) && (a[e] = d[e])
        }
        return a
    }
    ;
    na("Object.assign", function(a) {
        return a || Ua
    });
    na("WeakMap", function(a) {
        function b() {}
        function c(l) {
            var m = typeof l;
            return "object" === m && null !== l || "function" === m
        }
        function d(l) {
            if (!Ta(l, f)) {
                var m = new b;
                ha(l, f, {
                    value: m
                })
            }
        }
        function e(l) {
            var m = Object[l];
            m && (Object[l] = function(n) {
                if (n instanceof b)
                    return n;
                Object.isExtensible(n) && d(n);
                return m(n)
            }
            )
        }
        if (function() {
            if (!a || !Object.seal)
                return !1;
            try {
                var l = Object.seal({})
                  , m = Object.seal({})
                  , n = new a([[l, 2], [m, 3]]);
                if (2 != n.get(l) || 3 != n.get(m))
                    return !1;
                n.delete(l);
                n.set(m, 4);
                return !n.has(l) && 4 == n.get(m)
            } catch (q) {
                return !1
            }
        }())
            return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var h = 0
          , k = function(l) {
            this.Ba = (h += Math.random() + 1).toString();
            if (l) {
                l = _.Ba(l);
                for (var m; !(m = l.next()).done; )
                    m = m.value,
                    this.set(m[0], m[1])
            }
        };
        k.prototype.set = function(l, m) {
            if (!c(l))
                throw Error("b");
            d(l);
            if (!Ta(l, f))
                throw Error("c`" + l);
            l[f][this.Ba] = m;
            return this
        }
        ;
        k.prototype.get = function(l) {
            return c(l) && Ta(l, f) ? l[f][this.Ba] : void 0
        }
        ;
        k.prototype.has = function(l) {
            return c(l) && Ta(l, f) && Ta(l[f], this.Ba)
        }
        ;
        k.prototype.delete = function(l) {
            return c(l) && Ta(l, f) && Ta(l[f], this.Ba) ? delete l[f][this.Ba] : !1
        }
        ;
        return k
    });
    na("Map", function(a) {
        if (function() {
            if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal)
                return !1;
            try {
                var k = Object.seal({
                    x: 4
                })
                  , l = new a(_.Ba([[k, "s"]]));
                if ("s" != l.get(k) || 1 != l.size || l.get({
                    x: 4
                }) || l.set({
                    x: 4
                }, "t") != l || 2 != l.size)
                    return !1;
                var m = l.entries()
                  , n = m.next();
                if (n.done || n.value[0] != k || "s" != n.value[1])
                    return !1;
                n = m.next();
                return n.done || 4 != n.value[0].x || "t" != n.value[1] || !m.next().done ? !1 : !0
            } catch (q) {
                return !1
            }
        }())
            return a;
        var b = new WeakMap
          , c = function(k) {
            this.Af = {};
            this.Ye = f();
            this.size = 0;
            if (k) {
                k = _.Ba(k);
                for (var l; !(l = k.next()).done; )
                    l = l.value,
                    this.set(l[0], l[1])
            }
        };
        c.prototype.set = function(k, l) {
            k = 0 === k ? 0 : k;
            var m = d(this, k);
            m.list || (m.list = this.Af[m.id] = []);
            m.xe ? m.xe.value = l : (m.xe = {
                next: this.Ye,
                uj: this.Ye.uj,
                head: this.Ye,
                key: k,
                value: l
            },
            m.list.push(m.xe),
            this.Ye.uj.next = m.xe,
            this.Ye.uj = m.xe,
            this.size++);
            return this
        }
        ;
        c.prototype.delete = function(k) {
            k = d(this, k);
            return k.xe && k.list ? (k.list.splice(k.index, 1),
            k.list.length || delete this.Af[k.id],
            k.xe.uj.next = k.xe.next,
            k.xe.next.uj = k.xe.uj,
            k.xe.head = null,
            this.size--,
            !0) : !1
        }
        ;
        c.prototype.clear = function() {
            this.Af = {};
            this.Ye = this.Ye.uj = f();
            this.size = 0
        }
        ;
        c.prototype.has = function(k) {
            return !!d(this, k).xe
        }
        ;
        c.prototype.get = function(k) {
            return (k = d(this, k).xe) && k.value
        }
        ;
        c.prototype.entries = function() {
            return e(this, function(k) {
                return [k.key, k.value]
            })
        }
        ;
        c.prototype.keys = function() {
            return e(this, function(k) {
                return k.key
            })
        }
        ;
        c.prototype.values = function() {
            return e(this, function(k) {
                return k.value
            })
        }
        ;
        c.prototype.forEach = function(k, l) {
            for (var m = this.entries(), n; !(n = m.next()).done; )
                n = n.value,
                k.call(l, n[1], n[0], this)
        }
        ;
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(k, l) {
            var m = l && typeof l;
            "object" == m || "function" == m ? b.has(l) ? m = b.get(l) : (m = "" + ++h,
            b.set(l, m)) : m = "p_" + l;
            var n = k.Af[m];
            if (n && Ta(k.Af, m))
                for (k = 0; k < n.length; k++) {
                    var q = n[k];
                    if (l !== l && q.key !== q.key || l === q.key)
                        return {
                            id: m,
                            list: n,
                            index: k,
                            xe: q
                        }
                }
            return {
                id: m,
                list: n,
                index: -1,
                xe: void 0
            }
        }
          , e = function(k, l) {
            var m = k.Ye;
            return pa(function() {
                if (m) {
                    for (; m.head != k.Ye; )
                        m = m.uj;
                    for (; m.next != m.head; )
                        return m = m.next,
                        {
                            done: !1,
                            value: l(m)
                        };
                    m = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        }
          , f = function() {
            var k = {};
            return k.uj = k.next = k.head = k
        }
          , h = 0;
        return c
    });
    na("Set", function(a) {
        if (function() {
            if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal)
                return !1;
            try {
                var c = Object.seal({
                    x: 4
                })
                  , d = new a(_.Ba([c]));
                if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                    x: 4
                }) != d || 2 != d.size)
                    return !1;
                var e = d.entries()
                  , f = e.next();
                if (f.done || f.value[0] != c || f.value[1] != c)
                    return !1;
                f = e.next();
                return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
            } catch (h) {
                return !1
            }
        }())
            return a;
        var b = function(c) {
            this.va = new Map;
            if (c) {
                c = _.Ba(c);
                for (var d; !(d = c.next()).done; )
                    this.add(d.value)
            }
            this.size = this.va.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.va.set(c, c);
            this.size = this.va.size;
            return this
        }
        ;
        b.prototype.delete = function(c) {
            c = this.va.delete(c);
            this.size = this.va.size;
            return c
        }
        ;
        b.prototype.clear = function() {
            this.va.clear();
            this.size = 0
        }
        ;
        b.prototype.has = function(c) {
            return this.va.has(c)
        }
        ;
        b.prototype.entries = function() {
            return this.va.entries()
        }
        ;
        b.prototype.values = function() {
            return this.va.values()
        }
        ;
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.va.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        }
        ;
        return b
    });
    var Wa = function(a, b) {
        a instanceof String && (a += "");
        var c = 0
          , d = !1
          , e = {
            next: function() {
                if (!d && c < a.length) {
                    var f = c++;
                    return {
                        value: b(f, a[f]),
                        done: !1
                    }
                }
                d = !0;
                return {
                    done: !0,
                    value: void 0
                }
            }
        };
        e[Symbol.iterator] = function() {
            return e
        }
        ;
        return e
    };
    na("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Wa(this, function(b, c) {
                return [b, c]
            })
        }
    });
    na("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;
                d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var h = d[f];
                    if (b.call(c, h, f, d)) {
                        b = h;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    na("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    });
    na("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Wa(this, function(b) {
                return b
            })
        }
    });
    na("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Wa(this, function(b, c) {
                return c
            })
        }
    });
    na("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(k) {
                return k
            }
            ;
            var e = []
              , f = "undefined" != typeof Symbol && Symbol.iterator && b[Symbol.iterator];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var h = 0; !(f = b.next()).done; )
                    e.push(c.call(d, f.value, h++))
            } else
                for (f = b.length,
                h = 0; h < f; h++)
                    e.push(c.call(d, b[h], h));
            return e
        }
    });
    na("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [], d;
            for (d in b)
                Ta(b, d) && c.push(b[d]);
            return c
        }
    });
    na("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    na("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b))
                    return !0
            }
            return !1
        }
    });
    na("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== Sa(this, b, "includes").indexOf(b, c || 0)
        }
    });
    na("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [], d;
            for (d in b)
                Ta(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    na("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            for (var c = [], d = 0; d < this.length; d++) {
                var e = this[d];
                Array.isArray(e) && 0 < b ? (e = Array.prototype.flat.call(e, b - 1),
                c.push.apply(c, e)) : c.push(e)
            }
            return c
        }
    });
    _.r = {};
    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Xa = _.Xa || {};
    _.D = this || self;
    _.Ya = "closure_uid_" + (1E9 * Math.random() >>> 0);
    _.I = function(a, b) {
        a = a.split(".");
        var c = _.D;
        a[0]in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift()); )
            a.length || void 0 === b ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = b
    }
    ;
    _.$a = function(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.H = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.xq = function(d, e, f) {
            for (var h = Array(arguments.length - 2), k = 2; k < arguments.length; k++)
                h[k - 2] = arguments[k];
            return b.prototype[e].apply(d, h)
        }
    }
    ;
    _.bb = window.osapi = window.osapi || {};

    window.___jsl = window.___jsl || {};
    (window.___jsl.cd = window.___jsl.cd || []).push({
        gwidget: {
            parsetags: "explicit"
        },
        appsapi: {
            plus_one_service: "/plus/v1"
        },
        csi: {
            rate: .01
        },
        poshare: {
            hangoutContactPickerServer: "https://plus.google.com"
        },
        gappsutil: {
            required_scopes: ["https://www.googleapis.com/auth/plus.me", "https://www.googleapis.com/auth/plus.people.recommended"],
            display_on_page_ready: !1
        },
        appsutil: {
            required_scopes: ["https://www.googleapis.com/auth/plus.me", "https://www.googleapis.com/auth/plus.people.recommended"],
            display_on_page_ready: !1
        },
        "oauth-flow": {
            authUrl: "https://accounts.google.com/o/oauth2/auth",
            proxyUrl: "https://accounts.google.com/o/oauth2/postmessageRelay",
            redirectUri: "postmessage"
        },
        iframes: {
            sharebox: {
                params: {
                    json: "&"
                },
                url: ":socialhost:/:session_prefix:_/sharebox/dialog"
            },
            plus: {
                url: ":socialhost:/:session_prefix:_/widget/render/badge?usegapi=1"
            },
            ":socialhost:": "https://apis.google.com",
            ":im_socialhost:": "https://plus.googleapis.com",
            domains_suggest: {
                url: "https://domains.google.com/suggest/flow"
            },
            card: {
                params: {
                    s: "#",
                    userid: "&"
                },
                url: ":socialhost:/:session_prefix:_/hovercard/internalcard"
            },
            ":signuphost:": "https://plus.google.com",
            ":gplus_url:": "https://plus.google.com",
            plusone: {
                url: ":socialhost:/:session_prefix:_/+1/fastbutton?usegapi=1"
            },
            plus_share: {
                url: ":socialhost:/:session_prefix:_/+1/sharebutton?plusShare=true&usegapi=1"
            },
            plus_circle: {
                url: ":socialhost:/:session_prefix:_/widget/plus/circle?usegapi=1"
            },
            plus_followers: {
                url: ":socialhost:/_/im/_/widget/render/plus/followers?usegapi=1"
            },
            configurator: {
                url: ":socialhost:/:session_prefix:_/plusbuttonconfigurator?usegapi=1"
            },
            appcirclepicker: {
                url: ":socialhost:/:session_prefix:_/widget/render/appcirclepicker"
            },
            page: {
                url: ":socialhost:/:session_prefix:_/widget/render/page?usegapi=1"
            },
            person: {
                url: ":socialhost:/:session_prefix:_/widget/render/person?usegapi=1"
            },
            community: {
                url: ":ctx_socialhost:/:session_prefix::im_prefix:_/widget/render/community?usegapi=1"
            },
            follow: {
                url: ":socialhost:/:session_prefix:_/widget/render/follow?usegapi=1"
            },
            commentcount: {
                url: ":socialhost:/:session_prefix:_/widget/render/commentcount?usegapi=1"
            },
            comments: {
                url: ":socialhost:/:session_prefix:_/widget/render/comments?usegapi=1"
            },
            blogger: {
                url: ":socialhost:/:session_prefix:_/widget/render/blogger?usegapi=1"
            },
            youtube: {
                url: ":socialhost:/:session_prefix:_/widget/render/youtube?usegapi=1"
            },
            reportabuse: {
                url: ":socialhost:/:session_prefix:_/widget/render/reportabuse?usegapi=1"
            },
            additnow: {
                url: ":socialhost:/additnow/additnow.html"
            },
            appfinder: {
                url: "https://workspace.google.com/:session_prefix:marketplace/appfinder?usegapi=1"
            },
            ":source:": "1p"
        },
        poclient: {
            update_session: "google.updateSessionCallback"
        },
        "googleapis.config": {
            rpc: "/rpc",
            root: "https://content.googleapis.com",
            "root-1p": "https://clients6.google.com",
            useGapiForXd3: !0,
            xd3: "/static/proxy.html",
            auth: {
                useInterimAuth: !1
            }
        },
        report: {
            apis: ["iframes\\..*", "gadgets\\..*", "gapi\\.appcirclepicker\\..*", "gapi\\.client\\..*"],
            rate: 1E-4
        },
        client: {
            perApiBatch: !0
        }
    });

    window.___jsl = window.___jsl || {};
    (window.___jsl.cd = window.___jsl.cd || []).push({
        gwidget: {
            parsetags: "onload"
        },
        iframes: {
            ":source:": "3p"
        }
    });

    var ib, Fb, Hb, Ib, Jb;
    _.cb = function(a, b) {
        return _.aa[a] = b
    }
    ;
    _.gb = function(a) {
        if (a instanceof _.eb)
            return a.yP;
        throw Error("e");
    }
    ;
    ib = function(a) {
        return new _.hb(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        }
        )
    }
    ;
    _.jb = function(a, b) {
        if (Error.captureStackTrace)
            Error.captureStackTrace(this, _.jb);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        void 0 !== b && (this.XJ = b);
        this.OP = !0
    }
    ;
    _.lb = function(a, b) {
        return 0 <= (0,
        _.kb)(a, b)
    }
    ;
    _.mb = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++)
                c[d] = a[d];
            return c
        }
        return []
    }
    ;
    _.nb = function(a, b, c) {
        for (var d in a)
            b.call(c, a[d], d, a)
    }
    ;
    _.ob = function(a) {
        var b = arguments.length;
        if (1 == b && Array.isArray(arguments[0]))
            return _.ob.apply(null, arguments[0]);
        for (var c = {}, d = 0; d < b; d++)
            c[arguments[d]] = !0;
        return c
    }
    ;
    _.rb = function(a) {
        return _.pb(_.qb, a)
    }
    ;
    _.sb = function() {
        return _.rb("Opera")
    }
    ;
    _.tb = function() {
        return _.rb("Trident") || _.rb("MSIE")
    }
    ;
    _.vb = function() {
        return _.rb("Firefox") || _.rb("FxiOS")
    }
    ;
    _.wb = function() {
        return (_.rb("Chrome") || _.rb("CriOS")) && !_.rb("Edge")
    }
    ;
    _.xb = function(a) {
        if (null !== a && void 0 !== a.tagName) {
            if ("script" === a.tagName.toLowerCase())
                throw Error("l");
            if ("style" === a.tagName.toLowerCase())
                throw Error("m");
        }
    }
    ;
    _.yb = function() {
        return _.rb("iPhone") && !_.rb("iPod") && !_.rb("iPad")
    }
    ;
    _.zb = function() {
        return _.yb() || _.rb("iPad") || _.rb("iPod")
    }
    ;
    _.Bb = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }
    ;
    _.O = function(a, b) {
        a.prototype = (0,
        _.Ca)(b.prototype);
        a.prototype.constructor = a;
        if (_.Ra)
            (0,
            _.Ra)(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else
                        a[c] = b[c];
        a.H = b.prototype
    }
    ;
    _.Cb = function() {}
    ;
    _.Db = function(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }
    ;
    _.Eb = function(a) {
        var b = _.Db(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    }
    ;
    Fb = 0;
    _.Gb = function(a) {
        return Object.prototype.hasOwnProperty.call(a, _.Ya) && a[_.Ya] || (a[_.Ya] = ++Fb)
    }
    ;
    Hb = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }
    ;
    Ib = function(a, b, c) {
        if (!a)
            throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }
    ;
    _.R = function(a, b, c) {
        _.R = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Hb : Ib;
        return _.R.apply(null, arguments)
    }
    ;
    Jb = function(a) {
        return a
    }
    ;
    /*

 SPDX-License-Identifier: Apache-2.0
*/
    _.Kb = {};
    _.Mb = function() {}
    ;
    _.eb = function(a) {
        this.yP = a
    }
    ;
    _.O(_.eb, _.Mb);
    _.eb.prototype.toString = function() {
        return this.yP
    }
    ;
    _.Nb = new _.eb("about:invalid#zTSz",_.Kb);
    _.hb = function(a) {
        this.ii = a
    }
    ;
    _.Pb = [ib("data"), ib("http"), ib("https"), ib("mailto"), ib("ftp"), new _.hb(function(a) {
        return /^[^:]*([/?#]|$)/.test(a)
    }
    )];
    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.$a(_.jb, Error);
    _.jb.prototype.name = "CustomError";
    var Qb;
    _.kb = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    }
    : function(a, b) {
        if ("string" === typeof a)
            return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b)
                return c;
        return -1
    }
    ;
    _.Rb = Array.prototype.lastIndexOf ? function(a, b) {
        return Array.prototype.lastIndexOf.call(a, b, a.length - 1)
    }
    : function(a, b) {
        var c = a.length - 1;
        0 > c && (c = Math.max(0, a.length + c));
        if ("string" === typeof a)
            return "string" !== typeof b || 1 != b.length ? -1 : a.lastIndexOf(b, c);
        for (; 0 <= c; c--)
            if (c in a && a[c] === b)
                return c;
        return -1
    }
    ;
    _.Sb = Array.prototype.forEach ? function(a, b, c) {
        Array.prototype.forEach.call(a, b, c)
    }
    : function(a, b, c) {
        for (var d = a.length, e = "string" === typeof a ? a.split("") : a, f = 0; f < d; f++)
            f in e && b.call(c, e[f], f, a)
    }
    ;
    _.Tb = Array.prototype.map ? function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    }
    : function(a, b) {
        for (var c = a.length, d = Array(c), e = "string" === typeof a ? a.split("") : a, f = 0; f < c; f++)
            f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }
    ;
    _.Ub = Array.prototype.some ? function(a, b, c) {
        return Array.prototype.some.call(a, b, c)
    }
    : function(a, b, c) {
        for (var d = a.length, e = "string" === typeof a ? a.split("") : a, f = 0; f < d; f++)
            if (f in e && b.call(c, e[f], f, a))
                return !0;
        return !1
    }
    ;
    _.Vb = Array.prototype.every ? function(a, b, c) {
        return Array.prototype.every.call(a, b, c)
    }
    : function(a, b, c) {
        for (var d = a.length, e = "string" === typeof a ? a.split("") : a, f = 0; f < d; f++)
            if (f in e && !b.call(c, e[f], f, a))
                return !1;
        return !0
    }
    ;
    var Yb, Zb = function() {
        if (void 0 === Yb) {
            var a = null
              , b = _.D.trustedTypes;
            if (b && b.createPolicy)
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: Jb,
                        createScript: Jb,
                        createScriptURL: Jb
                    })
                } catch (c) {
                    _.D.console && _.D.console.error(c.message)
                }
            Yb = a
        }
        return Yb
    };
    var ac, $b;
    _.dc = function(a, b) {
        this.tR = a === $b && b || "";
        this.aU = ac
    }
    ;
    _.dc.prototype.Yh = !0;
    _.dc.prototype.Hf = function() {
        return this.tR
    }
    ;
    _.ec = function(a) {
        return a instanceof _.dc && a.constructor === _.dc && a.aU === ac ? a.tR : "type_error:Const"
    }
    ;
    _.fc = function(a) {
        return new _.dc($b,a)
    }
    ;
    ac = {};
    $b = {};
    var gc;
    _.hc = function(a, b) {
        this.RE = b === gc ? a : ""
    }
    ;
    _.g = _.hc.prototype;
    _.g.Yh = !0;
    _.g.Hf = function() {
        return this.RE.toString()
    }
    ;
    _.g.rD = !0;
    _.g.tk = function() {
        return 1
    }
    ;
    _.g.toString = function() {
        return this.RE + ""
    }
    ;
    _.jc = function(a) {
        return _.ic(a).toString()
    }
    ;
    _.ic = function(a) {
        if (a instanceof _.hc && a.constructor === _.hc)
            return a.RE;
        _.Db(a);
        return "type_error:TrustedResourceUrl"
    }
    ;
    _.lc = function(a) {
        return _.kc(_.ec(a))
    }
    ;
    gc = {};
    _.kc = function(a) {
        var b = Zb();
        a = b ? b.createScriptURL(a) : a;
        return new _.hc(a,gc)
    }
    ;
    var qc, rc, sc, tc, uc, wc, xc, zc;
    _.mc = function(a, b) {
        return 0 == a.lastIndexOf(b, 0)
    }
    ;
    _.nc = function(a) {
        return /^[\s\xa0]*$/.test(a)
    }
    ;
    _.oc = String.prototype.trim ? function(a) {
        return a.trim()
    }
    : function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }
    ;
    _.yc = function(a, b) {
        if (b)
            a = a.replace(qc, "&amp;").replace(rc, "&lt;").replace(sc, "&gt;").replace(tc, "&quot;").replace(uc, "&#39;").replace(wc, "&#0;");
        else {
            if (!xc.test(a))
                return a;
            -1 != a.indexOf("&") && (a = a.replace(qc, "&amp;"));
            -1 != a.indexOf("<") && (a = a.replace(rc, "&lt;"));
            -1 != a.indexOf(">") && (a = a.replace(sc, "&gt;"));
            -1 != a.indexOf('"') && (a = a.replace(tc, "&quot;"));
            -1 != a.indexOf("'") && (a = a.replace(uc, "&#39;"));
            -1 != a.indexOf("\x00") && (a = a.replace(wc, "&#0;"))
        }
        return a
    }
    ;
    qc = /&/g;
    rc = /</g;
    sc = />/g;
    tc = /"/g;
    uc = /'/g;
    wc = /\x00/g;
    xc = /[\x00&<>"']/;
    _.pb = function(a, b) {
        return -1 != a.indexOf(b)
    }
    ;
    _.Ac = function(a, b) {
        var c = 0;
        a = (0,
        _.oc)(String(a)).split(".");
        b = (0,
        _.oc)(String(b)).split(".");
        for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
            var f = a[e] || ""
              , h = b[e] || "";
            do {
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                h = /(\d*)(\D*)(.*)/.exec(h) || ["", "", "", ""];
                if (0 == f[0].length && 0 == h[0].length)
                    break;
                c = zc(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == h[1].length ? 0 : parseInt(h[1], 10)) || zc(0 == f[2].length, 0 == h[2].length) || zc(f[2], h[2]);
                f = f[3];
                h = h[3]
            } while (0 == c)
        }
        return c
    }
    ;
    zc = function(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    }
    ;
    var Ec, Fc, Gc, Hc;
    _.Cc = function(a, b) {
        this.QE = b === _.Bc ? a : ""
    }
    ;
    _.g = _.Cc.prototype;
    _.g.Yh = !0;
    _.g.Hf = function() {
        return this.QE.toString()
    }
    ;
    _.g.rD = !0;
    _.g.tk = function() {
        return 1
    }
    ;
    _.g.toString = function() {
        return this.QE.toString()
    }
    ;
    _.Dc = function(a) {
        if (a instanceof _.Cc && a.constructor === _.Cc)
            return a.QE;
        _.Db(a);
        return "type_error:SafeUrl"
    }
    ;
    Ec = RegExp('^(?:audio/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-matroska|x-wav|wav|webm)|font/\\w+|image/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon)|video/(?:mpeg|mp4|ogg|webm|quicktime|x-matroska))(?:;\\w+=(?:\\w+|"[\\w;,= ]+"))*$', "i");
    Fc = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;
    Gc = function(a) {
        a = String(a);
        a = a.replace(/(%0A|%0D)/g, "");
        var b = a.match(Fc);
        return b && Ec.test(b[1]) ? new _.Cc(a,_.Bc) : null
    }
    ;
    Hc = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    _.Ic = function(a) {
        if (a instanceof _.Cc)
            return a;
        a = "object" == typeof a && a.Yh ? a.Hf() : String(a);
        return Hc.test(a) ? new _.Cc(a,_.Bc) : Gc(a)
    }
    ;
    _.Kc = function(a, b) {
        if (a instanceof _.Cc)
            return a;
        a = "object" == typeof a && a.Yh ? a.Hf() : String(a);
        if (b && /^data:/i.test(a) && (b = Gc(a) || _.Jc,
        b.Hf() == a))
            return b;
        Hc.test(a) || (a = "about:invalid#zClosurez");
        return new _.Cc(a,_.Bc)
    }
    ;
    _.Bc = {};
    _.Jc = new _.Cc("about:invalid#zClosurez",_.Bc);
    _.Lc = {};
    _.Mc = function(a, b) {
        this.PE = b === _.Lc ? a : "";
        this.Yh = !0
    }
    ;
    _.Mc.prototype.Hf = function() {
        return this.PE
    }
    ;
    _.Mc.prototype.toString = function() {
        return this.PE.toString()
    }
    ;
    _.Nc = new _.Mc("",_.Lc);
    _.Oc = RegExp("^[-,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$");
    _.Pc = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g");
    _.Qc = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g");
    _.Rc = {};
    _.Sc = function(a, b) {
        this.OE = b === _.Rc ? a : "";
        this.Yh = !0
    }
    ;
    _.Uc = function(a) {
        a = _.ec(a);
        return 0 === a.length ? Tc : new _.Sc(a,_.Rc)
    }
    ;
    _.Sc.prototype.Hf = function() {
        return this.OE
    }
    ;
    _.Sc.prototype.toString = function() {
        return this.OE.toString()
    }
    ;
    var Tc = new _.Sc("",_.Rc);
    a: {
        var Vc = _.D.navigator;
        if (Vc) {
            var Wc = Vc.userAgent;
            if (Wc) {
                _.qb = Wc;
                break a
            }
        }
        _.qb = ""
    }
    ;var Xc;
    Xc = {};
    _.Yc = function(a, b, c) {
        this.NE = c === Xc ? a : "";
        this.IV = b;
        this.Yh = this.rD = !0
    }
    ;
    _.Yc.prototype.tk = function() {
        return this.IV
    }
    ;
    _.Yc.prototype.Hf = function() {
        return this.NE.toString()
    }
    ;
    _.Yc.prototype.toString = function() {
        return this.NE.toString()
    }
    ;
    _.Zc = function(a) {
        if (a instanceof _.Yc && a.constructor === _.Yc)
            return a.NE;
        _.Db(a);
        return "type_error:SafeHtml"
    }
    ;
    _.ad = function(a) {
        if (a instanceof _.Yc)
            return a;
        var b = "object" == typeof a
          , c = null;
        b && a.rD && (c = a.tk());
        return _.$c(_.yc(b && a.Yh ? a.Hf() : String(a)), c)
    }
    ;
    _.$c = function(a, b) {
        var c = Zb();
        a = c ? c.createHTML(a) : a;
        return new _.Yc(a,b,Xc)
    }
    ;
    _.bd = new _.Yc(_.D.trustedTypes && _.D.trustedTypes.emptyHTML || "",0,Xc);
    _.cd = _.$c("<br>", 0);
    var dd = function(a) {
        dd[" "](a);
        return a
    };
    dd[" "] = _.Cb;
    _.ed = function(a, b) {
        try {
            return dd(a[b]),
            !0
        } catch (c) {}
        return !1
    }
    ;
    _.fd = function(a, b, c) {
        return Object.prototype.hasOwnProperty.call(a, b) ? a[b] : a[b] = c(b)
    }
    ;
    var wd, xd, Cd, Ed;
    _.gd = _.sb();
    _.hd = _.tb();
    _.id = _.rb("Edge");
    _.jd = _.id || _.hd;
    _.kd = _.rb("Gecko") && !(_.pb(_.qb.toLowerCase(), "webkit") && !_.rb("Edge")) && !(_.rb("Trident") || _.rb("MSIE")) && !_.rb("Edge");
    _.ld = _.pb(_.qb.toLowerCase(), "webkit") && !_.rb("Edge");
    _.md = _.ld && _.rb("Mobile");
    _.nd = _.rb("Macintosh");
    _.od = _.rb("Windows");
    _.pd = _.rb("Linux") || _.rb("CrOS");
    _.rd = _.rb("Android");
    _.sd = _.yb();
    _.td = _.rb("iPad");
    _.ud = _.rb("iPod");
    _.vd = _.zb();
    wd = function() {
        var a = _.D.document;
        return a ? a.documentMode : void 0
    }
    ;
    a: {
        var yd = ""
          , zd = function() {
            var a = _.qb;
            if (_.kd)
                return /rv:([^\);]+)(\)|;)/.exec(a);
            if (_.id)
                return /Edge\/([\d\.]+)/.exec(a);
            if (_.hd)
                return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
            if (_.ld)
                return /WebKit\/(\S+)/.exec(a);
            if (_.gd)
                return /(?:Version)[ \/]?(\S+)/.exec(a)
        }();
        zd && (yd = zd ? zd[1] : "");
        if (_.hd) {
            var Ad = wd();
            if (null != Ad && Ad > parseFloat(yd)) {
                xd = String(Ad);
                break a
            }
        }
        xd = yd
    }
    _.Bd = xd;
    Cd = {};
    _.Dd = function(a) {
        return _.fd(Cd, a, function() {
            return 0 <= _.Ac(_.Bd, a)
        })
    }
    ;
    if (_.D.document && _.hd) {
        var Fd = wd();
        Ed = Fd ? Fd : parseInt(_.Bd, 10) || void 0
    } else
        Ed = void 0;
    _.Gd = Ed;
    try {
        (new self.OffscreenCanvas(0,0)).getContext("2d")
    } catch (a) {}
    _.Hd = _.hd || _.ld;
    _.Id = function(a) {
        var b = !1, c;
        return function() {
            b || (c = a(),
            b = !0);
            return c
        }
    }
    ;
    var Jd, Nd;
    Jd = _.Id(function() {
        var a = document.createElement("div")
          , b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = _.Zc(_.bd);
        return !b.parentElement
    });
    _.Kd = function(a, b) {
        if (Jd())
            for (; a.lastChild; )
                a.removeChild(a.lastChild);
        a.innerHTML = _.Zc(b)
    }
    ;
    _.Ld = function(a, b) {
        b = b instanceof _.Cc ? b : _.Kc(b);
        a.href = _.Dc(b)
    }
    ;
    _.Md = function(a, b, c, d) {
        a = a instanceof _.Cc ? a : _.Kc(a);
        b = b || _.D;
        c = c instanceof _.dc ? _.ec(c) : c || "";
        return void 0 !== d ? b.open(_.Dc(a), c, d) : b.open(_.Dc(a), c)
    }
    ;
    Nd = /^[\w+/_-]+[=]{0,2}$/;
    _.Od = function(a, b) {
        b = (b || _.D).document;
        return b.querySelector ? (a = b.querySelector(a)) && (a = a.nonce || a.getAttribute("nonce")) && Nd.test(a) ? a : "" : ""
    }
    ;
    _.Pd = String.prototype.repeat ? function(a, b) {
        return a.repeat(b)
    }
    : function(a, b) {
        return Array(b + 1).join(a)
    }
    ;
    _.Qd = 2147483648 * Math.random() | 0;
    var Wd, $d;
    _.Td = function(a) {
        return a ? new _.Rd(_.Sd(a)) : Qb || (Qb = new _.Rd)
    }
    ;
    _.Ud = function(a, b, c, d) {
        a = d || a;
        b = b && "*" != b ? String(b).toUpperCase() : "";
        if (a.querySelectorAll && a.querySelector && (b || c))
            return a.querySelectorAll(b + (c ? "." + c : ""));
        if (c && a.getElementsByClassName) {
            a = a.getElementsByClassName(c);
            if (b) {
                d = {};
                for (var e = 0, f = 0, h; h = a[f]; f++)
                    b == h.nodeName && (d[e++] = h);
                d.length = e;
                return d
            }
            return a
        }
        a = a.getElementsByTagName(b || "*");
        if (c) {
            d = {};
            for (f = e = 0; h = a[f]; f++)
                b = h.className,
                "function" == typeof b.split && _.lb(b.split(/\s+/), c) && (d[e++] = h);
            d.length = e;
            return d
        }
        return a
    }
    ;
    _.Xd = function(a, b) {
        _.nb(b, function(c, d) {
            c && "object" == typeof c && c.Yh && (c = c.Hf());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : Wd.hasOwnProperty(d) ? a.setAttribute(Wd[d], c) : _.mc(d, "aria-") || _.mc(d, "data-") ? a.setAttribute(d, c) : a[d] = c
        })
    }
    ;
    Wd = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.Yd = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    }
    ;
    _.ae = function(a, b) {
        var c = b[1]
          , d = _.Zd(a, String(b[0]));
        c && ("string" === typeof c ? d.className = c : Array.isArray(c) ? d.className = c.join(" ") : _.Xd(d, c));
        2 < b.length && $d(a, d, b, 2);
        return d
    }
    ;
    $d = function(a, b, c, d) {
        function e(k) {
            k && b.appendChild("string" === typeof k ? a.createTextNode(k) : k)
        }
        for (; d < c.length; d++) {
            var f = c[d];
            if (!_.Eb(f) || _.Bb(f) && 0 < f.nodeType)
                e(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (_.Bb(f)) {
                            var h = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            h = "function" == typeof f.item;
                            break a
                        }
                    }
                    h = !1
                }
                _.Sb(h ? _.mb(f) : f, e)
            }
        }
    }
    ;
    _.be = function(a) {
        return _.Zd(document, a)
    }
    ;
    _.Zd = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }
    ;
    _.ce = function(a) {
        if (1 != a.nodeType)
            return !1;
        switch (a.tagName) {
        case "APPLET":
        case "AREA":
        case "BASE":
        case "BR":
        case "COL":
        case "COMMAND":
        case "EMBED":
        case "FRAME":
        case "HR":
        case "IMG":
        case "INPUT":
        case "IFRAME":
        case "ISINDEX":
        case "KEYGEN":
        case "LINK":
        case "NOFRAMES":
        case "NOSCRIPT":
        case "META":
        case "OBJECT":
        case "PARAM":
        case "SCRIPT":
        case "SOURCE":
        case "STYLE":
        case "TRACK":
        case "WBR":
            return !1
        }
        return !0
    }
    ;
    _.de = function(a, b) {
        $d(_.Sd(a), a, arguments, 1)
    }
    ;
    _.ee = function(a) {
        for (var b; b = a.firstChild; )
            a.removeChild(b)
    }
    ;
    _.fe = function(a, b) {
        b.parentNode && b.parentNode.insertBefore(a, b)
    }
    ;
    _.ge = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    }
    ;
    _.he = function(a) {
        return void 0 != a.children ? a.children : Array.prototype.filter.call(a.childNodes, function(b) {
            return 1 == b.nodeType
        })
    }
    ;
    _.ie = function(a) {
        return _.Bb(a) && 1 == a.nodeType
    }
    ;
    _.je = function(a, b) {
        if (!a || !b)
            return !1;
        if (a.contains && 1 == b.nodeType)
            return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition)
            return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b; )
            b = b.parentNode;
        return b == a
    }
    ;
    _.Sd = function(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    }
    ;
    _.ke = function(a, b) {
        if ("textContent"in a)
            a.textContent = b;
        else if (3 == a.nodeType)
            a.data = String(b);
        else if (a.firstChild && 3 == a.firstChild.nodeType) {
            for (; a.lastChild != a.firstChild; )
                a.removeChild(a.lastChild);
            a.firstChild.data = String(b)
        } else
            _.ee(a),
            a.appendChild(_.Sd(a).createTextNode(String(b)))
    }
    ;
    _.Rd = function(a) {
        this.nb = a || _.D.document || document
    }
    ;
    _.g = _.Rd.prototype;
    _.g.Ea = _.Td;
    _.g.PF = _.ea(0);
    _.g.Za = function() {
        return this.nb
    }
    ;
    _.g.N = _.ea(1);
    _.g.getElementsByTagName = function(a, b) {
        return (b || this.nb).getElementsByTagName(String(a))
    }
    ;
    _.g.ma = function(a, b, c) {
        return _.ae(this.nb, arguments)
    }
    ;
    _.g.createElement = function(a) {
        return _.Zd(this.nb, a)
    }
    ;
    _.g.createTextNode = function(a) {
        return this.nb.createTextNode(String(a))
    }
    ;
    _.g.getWindow = function() {
        var a = this.nb;
        return a.parentWindow || a.defaultView
    }
    ;
    _.g.appendChild = function(a, b) {
        a.appendChild(b)
    }
    ;
    _.g.append = _.de;
    _.g.canHaveChildren = _.ce;
    _.g.Pd = _.ee;
    _.g.zN = _.fe;
    _.g.removeNode = _.ge;
    _.g.fC = _.he;
    _.g.isElement = _.ie;
    _.g.contains = _.je;
    _.g.ei = _.ea(2);
    /*
 gapi.loader.OBJECT_CREATE_TEST_OVERRIDE &&*/
    _.le = window;
    _.me = document;
    _.ne = _.le.location;
    _.oe = /\[native code\]/;
    _.pe = function(a, b, c) {
        return a[b] = a[b] || c
    }
    ;
    _.re = function() {
        var a;
        if ((a = Object.create) && _.oe.test(a))
            a = a(null);
        else {
            a = {};
            for (var b in a)
                a[b] = void 0
        }
        return a
    }
    ;
    _.se = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
    ;
    _.te = function(a, b) {
        a = a || {};
        for (var c in a)
            _.se(a, c) && (b[c] = a[c])
    }
    ;
    _.ue = _.pe(_.le, "gapi", {});
    _.ve = function(a, b, c) {
        var d = new RegExp("([#].*&|[#])" + b + "=([^&#]*)","g");
        b = new RegExp("([?#].*&|[?#])" + b + "=([^&#]*)","g");
        if (a = a && (d.exec(a) || b.exec(a)))
            try {
                c = decodeURIComponent(a[2])
            } catch (e) {}
        return c
    }
    ;
    _.we = new RegExp(/^/.source + /([a-zA-Z][-+.a-zA-Z0-9]*:)?/.source + /(\/\/[^\/?#]*)?/.source + /([^?#]*)?/.source + /(\?([^#]*))?/.source + /(#((#|[^#])*))?/.source + /$/.source);
    _.xe = new RegExp(/(%([^0-9a-fA-F%]|[0-9a-fA-F]([^0-9a-fA-F%])?)?)*/.source + /%($|[^0-9a-fA-F]|[0-9a-fA-F]($|[^0-9a-fA-F]))/.source,"g");
    _.ye = new RegExp(/\/?\??#?/.source + "(" + /[\/?#]/i.source + "|" + /[\uD800-\uDBFF]/i.source + "|" + /%[c-f][0-9a-f](%[89ab][0-9a-f]){0,2}(%[89ab]?)?/i.source + "|" + /%[0-9a-f]?/i.source + ")$","i");
    _.Ae = function(a, b, c) {
        _.ze(a, b, c, "add", "at")
    }
    ;
    _.ze = function(a, b, c, d, e) {
        if (a[d + "EventListener"])
            a[d + "EventListener"](b, c, !1);
        else if (a[e + "tachEvent"])
            a[e + "tachEvent"]("on" + b, c)
    }
    ;
    _.Be = _.pe(_.le, "___jsl", _.re());
    _.pe(_.Be, "I", 0);
    _.pe(_.Be, "hel", 10);
    var De, Ee, Fe, Ge, He, Ie, Je;
    De = function(a) {
        var b = window.___jsl = window.___jsl || {};
        b[a] = b[a] || [];
        return b[a]
    }
    ;
    Ee = function(a) {
        var b = window.___jsl = window.___jsl || {};
        b.cfg = !a && b.cfg || {};
        return b.cfg
    }
    ;
    Fe = function(a) {
        return "object" === typeof a && /\[native code\]/.test(a.push)
    }
    ;
    Ge = function(a, b, c) {
        if (b && "object" === typeof b)
            for (var d in b)
                !Object.prototype.hasOwnProperty.call(b, d) || c && "___goc" === d && "undefined" === typeof b[d] || (a[d] && b[d] && "object" === typeof a[d] && "object" === typeof b[d] && !Fe(a[d]) && !Fe(b[d]) ? Ge(a[d], b[d]) : b[d] && "object" === typeof b[d] ? (a[d] = Fe(b[d]) ? [] : {},
                Ge(a[d], b[d])) : a[d] = b[d])
    }
    ;
    He = function(a) {
        if (a && !/^\s+$/.test(a)) {
            for (; 0 == a.charCodeAt(a.length - 1); )
                a = a.substring(0, a.length - 1);
            try {
                var b = window.JSON.parse(a)
            } catch (c) {}
            if ("object" === typeof b)
                return b;
            try {
                b = (new Function("return (" + a + "\n)"))()
            } catch (c) {}
            if ("object" === typeof b)
                return b;
            try {
                b = (new Function("return ({" + a + "\n})"))()
            } catch (c) {}
            return "object" === typeof b ? b : {}
        }
    }
    ;
    Ie = function(a, b) {
        var c = {
            ___goc: void 0
        };
        a.length && a[a.length - 1] && Object.hasOwnProperty.call(a[a.length - 1], "___goc") && "undefined" === typeof a[a.length - 1].___goc && (c = a.pop());
        Ge(c, b);
        a.push(c)
    }
    ;
    Je = function(a) {
        Ee(!0);
        var b = window.___gcfg
          , c = De("cu")
          , d = window.___gu;
        b && b !== d && (Ie(c, b),
        window.___gu = b);
        b = De("cu");
        var e = document.scripts || document.getElementsByTagName("script") || [];
        d = [];
        var f = [];
        f.push.apply(f, De("us"));
        for (var h = 0; h < e.length; ++h)
            for (var k = e[h], l = 0; l < f.length; ++l)
                k.src && 0 == k.src.indexOf(f[l]) && d.push(k);
        0 == d.length && 0 < e.length && e[e.length - 1].src && d.push(e[e.length - 1]);
        for (e = 0; e < d.length; ++e)
            d[e].getAttribute("gapi_processed") || (d[e].setAttribute("gapi_processed", !0),
            (f = d[e]) ? (h = f.nodeType,
            f = 3 == h || 4 == h ? f.nodeValue : f.textContent || "") : f = void 0,
            (f = He(f)) && b.push(f));
        a && Ie(c, a);
        d = De("cd");
        a = 0;
        for (b = d.length; a < b; ++a)
            Ge(Ee(), d[a], !0);
        d = De("ci");
        a = 0;
        for (b = d.length; a < b; ++a)
            Ge(Ee(), d[a], !0);
        a = 0;
        for (b = c.length; a < b; ++a)
            Ge(Ee(), c[a], !0)
    }
    ;
    _.Ke = function(a, b) {
        var c = Ee();
        if (!a)
            return c;
        a = a.split("/");
        for (var d = 0, e = a.length; c && "object" === typeof c && d < e; ++d)
            c = c[a[d]];
        return d === a.length && void 0 !== c ? c : b
    }
    ;
    _.Le = function(a, b) {
        var c;
        if ("string" === typeof a) {
            var d = c = {};
            a = a.split("/");
            for (var e = 0, f = a.length; e < f - 1; ++e) {
                var h = {};
                d = d[a[e]] = h
            }
            d[a[e]] = b
        } else
            c = a;
        Je(c)
    }
    ;
    var Me = function() {
        var a = window.__GOOGLEAPIS;
        a && (a.googleapis && !a["googleapis.config"] && (a["googleapis.config"] = a.googleapis),
        _.pe(_.Be, "ci", []).push(a),
        window.__GOOGLEAPIS = void 0)
    };
    Me && Me();
    Je();
    _.I("gapi.config.get", _.Ke);
    _.I("gapi.config.update", _.Le);

    _.zh = function(a) {
        var b = window.___jsl = window.___jsl || {};
        b.cfg = !a && b.cfg || {};
        return b.cfg
    }
    ;
    _.Ah = function(a) {
        var b = _.zh();
        if (!a)
            return b;
        a = a.split("/");
        for (var c = 0, d = a.length; b && "object" === typeof b && c < d; ++c)
            b = b[a[c]];
        return c === a.length && void 0 !== b ? b : void 0
    }
    ;

    var Se, Te, Ue, Ve, We, Xe, Ye, Ze, $e, af, bf, cf, df, ef, ff, gf, hf, jf, kf, lf, mf, nf, of, pf, qf, rf, sf, tf, uf, vf, wf, zf, Af;
    Ue = void 0;
    Ve = function(a) {
        try {
            return _.D.JSON.parse.call(_.D.JSON, a)
        } catch (b) {
            return !1
        }
    }
    ;
    We = function(a) {
        return Object.prototype.toString.call(a)
    }
    ;
    Xe = We(0);
    Ye = We(new Date(0));
    Ze = We(!0);
    $e = We("");
    af = We({});
    bf = We([]);
    cf = function(a, b) {
        if (b)
            for (var c = 0, d = b.length; c < d; ++c)
                if (a === b[c])
                    throw new TypeError("Converting circular structure to JSON");
        d = typeof a;
        if ("undefined" !== d) {
            c = Array.prototype.slice.call(b || [], 0);
            c[c.length] = a;
            b = [];
            var e = We(a);
            if (null != a && "function" === typeof a.toJSON && (Object.prototype.hasOwnProperty.call(a, "toJSON") || (e !== bf || a.constructor !== Array && a.constructor !== Object) && (e !== af || a.constructor !== Array && a.constructor !== Object) && e !== $e && e !== Xe && e !== Ze && e !== Ye))
                return cf(a.toJSON.call(a), c);
            if (null == a)
                b[b.length] = "null";
            else if (e === Xe)
                a = Number(a),
                isNaN(a) || isNaN(a - a) ? a = "null" : -0 === a && 0 > 1 / a && (a = "-0"),
                b[b.length] = String(a);
            else if (e === Ze)
                b[b.length] = String(!!Number(a));
            else {
                if (e === Ye)
                    return cf(a.toISOString.call(a), c);
                if (e === bf && We(a.length) === Xe) {
                    b[b.length] = "[";
                    var f = 0;
                    for (d = Number(a.length) >> 0; f < d; ++f)
                        f && (b[b.length] = ","),
                        b[b.length] = cf(a[f], c) || "null";
                    b[b.length] = "]"
                } else if (e == $e && We(a.length) === Xe) {
                    b[b.length] = '"';
                    f = 0;
                    for (c = Number(a.length) >> 0; f < c; ++f)
                        d = String.prototype.charAt.call(a, f),
                        e = String.prototype.charCodeAt.call(a, f),
                        b[b.length] = "\b" === d ? "\\b" : "\f" === d ? "\\f" : "\n" === d ? "\\n" : "\r" === d ? "\\r" : "\t" === d ? "\\t" : "\\" === d || '"' === d ? "\\" + d : 31 >= e ? "\\u" + (e + 65536).toString(16).substr(1) : 32 <= e && 65535 >= e ? d : "\ufffd";
                    b[b.length] = '"'
                } else if ("object" === d) {
                    b[b.length] = "{";
                    d = 0;
                    for (f in a)
                        Object.prototype.hasOwnProperty.call(a, f) && (e = cf(a[f], c),
                        void 0 !== e && (d++ && (b[b.length] = ","),
                        b[b.length] = cf(f),
                        b[b.length] = ":",
                        b[b.length] = e));
                    b[b.length] = "}"
                } else
                    return
            }
            return b.join("")
        }
    }
    ;
    df = /[\0-\x07\x0b\x0e-\x1f]/;
    ef = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*[\0-\x1f]/;
    ff = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\[^\\\/"bfnrtu]/;
    gf = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\u([0-9a-fA-F]{0,3}[^0-9a-fA-F])/;
    hf = /"([^\0-\x1f\\"]|\\[\\\/"bfnrt]|\\u[0-9a-fA-F]{4})*"/g;
    jf = /-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?/g;
    kf = /[ \t\n\r]+/g;
    lf = /[^"]:/;
    mf = /""/g;
    nf = /true|false|null/g;
    of = /00/;
    pf = /[\{]([^0\}]|0[^:])/;
    qf = /(^|\[)[,:]|[,:](\]|\}|[,:]|$)/;
    rf = /[^\[,:][\[\{]/;
    sf = /^(\{|\}|\[|\]|,|:|0)+/;
    tf = /\u2028/g;
    uf = /\u2029/g;
    vf = function(a) {
        a = String(a);
        if (df.test(a) || ef.test(a) || ff.test(a) || gf.test(a))
            return !1;
        var b = a.replace(hf, '""');
        b = b.replace(jf, "0");
        b = b.replace(kf, "");
        if (lf.test(b))
            return !1;
        b = b.replace(mf, "0");
        b = b.replace(nf, "0");
        if (of.test(b) || pf.test(b) || qf.test(b) || rf.test(b) || !b || (b = b.replace(sf, "")))
            return !1;
        a = a.replace(tf, "\\u2028").replace(uf, "\\u2029");
        b = void 0;
        try {
            b = Ue ? [Ve(a)] : eval("(function (var_args) {\n  return Array.prototype.slice.call(arguments, 0);\n})(\n" + a + "\n)")
        } catch (c) {
            return !1
        }
        return b && 1 === b.length ? b[0] : !1
    }
    ;
    wf = function() {
        var a = ((_.D.document || {}).scripts || []).length;
        if ((void 0 === Se || void 0 === Ue || Te !== a) && -1 !== Te) {
            Se = Ue = !1;
            Te = -1;
            try {
                try {
                    Ue = !!_.D.JSON && '{"a":[3,true,"1970-01-01T00:00:00.000Z"]}' === _.D.JSON.stringify.call(_.D.JSON, {
                        a: [3, !0, new Date(0)],
                        c: function() {}
                    }) && !0 === Ve("true") && 3 === Ve('[{"a":3}]')[0].a
                } catch (b) {}
                Se = Ue && !Ve("[00]") && !Ve('"\u0007"') && !Ve('"\\0"') && !Ve('"\\v"')
            } finally {
                Te = a
            }
        }
    }
    ;
    _.xf = function(a) {
        if (-1 === Te)
            return !1;
        wf();
        return (Se ? Ve : vf)(a)
    }
    ;
    _.yf = function(a) {
        if (-1 !== Te)
            return wf(),
            Ue ? _.D.JSON.stringify.call(_.D.JSON, a) : cf(a)
    }
    ;
    zf = !Date.prototype.toISOString || "function" !== typeof Date.prototype.toISOString || "1970-01-01T00:00:00.000Z" !== (new Date(0)).toISOString();
    Af = function() {
        var a = Date.prototype.getUTCFullYear.call(this);
        return [0 > a ? "-" + String(1E6 - a).substr(1) : 9999 >= a ? String(1E4 + a).substr(1) : "+" + String(1E6 + a).substr(1), "-", String(101 + Date.prototype.getUTCMonth.call(this)).substr(1), "-", String(100 + Date.prototype.getUTCDate.call(this)).substr(1), "T", String(100 + Date.prototype.getUTCHours.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCMinutes.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCSeconds.call(this)).substr(1), ".", String(1E3 + Date.prototype.getUTCMilliseconds.call(this)).substr(1), "Z"].join("")
    }
    ;
    Date.prototype.toISOString = zf ? Af : Date.prototype.toISOString;

    var Cf = function() {
        this.Tf = window.console
    };
    _.g = Cf.prototype;
    _.g.log = function(a) {
        this.Tf && this.Tf.log && this.Tf.log(a)
    }
    ;
    _.g.error = function(a) {
        this.Tf && (this.Tf.error ? this.Tf.error(a) : this.Tf.log && this.Tf.log(a))
    }
    ;
    _.g.warn = function(a) {
        this.Tf && (this.Tf.warn ? this.Tf.warn(a) : this.Tf.log && this.Tf.log(a))
    }
    ;
    _.g.debug = function() {}
    ;
    _.g.YK = function() {
        this.debug = this.log
    }
    ;
    _.Df = new Cf;

    _.pg = function(a) {
        if (!a)
            return "";
        a = a.split("#")[0].split("?")[0];
        a = a.toLowerCase();
        0 == a.indexOf("//") && (a = window.location.protocol + a);
        /^[\w\-]*:\/\//.test(a) || (a = window.location.href);
        var b = a.substring(a.indexOf("://") + 3)
          , c = b.indexOf("/");
        -1 != c && (b = b.substring(0, c));
        c = a.substring(0, a.indexOf("://"));
        if (!c)
            throw Error("u`" + a);
        if ("http" !== c && "https" !== c && "chrome-extension" !== c && "moz-extension" !== c && "file" !== c && "android-app" !== c && "chrome-search" !== c && "chrome-untrusted" !== c && "chrome" !== c && "app" !== c && "devtools" !== c)
            throw Error("v`" + c);
        a = "";
        var d = b.indexOf(":");
        if (-1 != d) {
            var e = b.substring(d + 1);
            b = b.substring(0, d);
            if ("http" === c && "80" !== e || "https" === c && "443" !== e)
                a = ":" + e
        }
        return c + "://" + b + a
    }
    ;

    var rk = function() {
        this.Jt = {
            JP: kk ? "../" + kk : null,
            vB: lk,
            sM: mk,
            qda: nk,
            im: ok,
            cea: pk
        };
        this.uf = _.le;
        this.tP = this.JV;
        this.vW = /MSIE\s*[0-8](\D|$)/.test(window.navigator.userAgent);
        if (this.Jt.JP) {
            this.uf = this.Jt.sM(this.uf, this.Jt.JP);
            var a = this.uf.document
              , b = a.createElement("script");
            b.setAttribute("type", "text/javascript");
            b.text = "window.doPostMsg=function(w,s,o) {window.setTimeout(function(){w.postMessage(s,o);},0);};";
            a.body.appendChild(b);
            this.tP = this.uf.doPostMsg
        }
        this.kH = {};
        this.OH = {};
        a = (0,
        _.R)(this.XC, this);
        _.Ae(this.uf, "message", a);
        _.pe(_.Be, "RPMQ", []).push(a);
        this.uf != this.uf.parent && qk(this, this.uf.parent, this.WD(this.uf.name), "*")
    };
    rk.prototype.WD = function(a) {
        return '{"h":"' + escape(a) + '"}'
    }
    ;
    var sk = function(a) {
        var b = null;
        0 === a.indexOf('{"h":"') && a.indexOf('"}') === a.length - 2 && (b = unescape(a.substring(6, a.length - 2)));
        return b
    }
      , tk = function(a) {
        if (!/^\s*{/.test(a))
            return !1;
        a = _.xf(a);
        return null !== a && "object" === typeof a && !!a.g
    };
    rk.prototype.XC = function(a) {
        var b = String(a.data);
        _.Df.debug("gapix.rpc.receive(" + nk + "): " + (!b || 512 >= b.length ? b : b.substr(0, 512) + "... (" + b.length + " bytes)"));
        var c = 0 !== b.indexOf("!_");
        c || (b = b.substring(2));
        var d = tk(b);
        if (!c && !d) {
            if (!d && (c = sk(b))) {
                if (this.kH[c])
                    this.kH[c]();
                else
                    this.OH[c] = 1;
                return
            }
            var e = a.origin
              , f = this.Jt.vB;
            this.vW ? _.le.setTimeout(function() {
                f(b, e)
            }, 0) : f(b, e)
        }
    }
    ;
    rk.prototype.Cb = function(a, b) {
        ".." === a || this.OH[a] ? (b(),
        delete this.OH[a]) : this.kH[a] = b
    }
    ;
    var qk = function(a, b, c, d) {
        var e = tk(c) ? "" : "!_";
        _.Df.debug("gapix.rpc.send(" + nk + "): " + (!c || 512 >= c.length ? c : c.substr(0, 512) + "... (" + c.length + " bytes)"));
        a.tP(b, e + c, d)
    };
    rk.prototype.JV = function(a, b, c) {
        a.postMessage(b, c)
    }
    ;
    rk.prototype.send = function(a, b, c) {
        (a = this.Jt.sM(this.uf, a)) && !a.closed && qk(this, a, b, c)
    }
    ;
    var uk, vk, wk, xk, yk, zk, Ak, kk, nk, Bk, Ck, Dk, mk, ok, Fk, Gk, Lk, Mk, Ok, pk, Qk, Pk, Hk, Ik, Rk, lk, Sk, Tk;
    uk = 0;
    vk = [];
    wk = {};
    xk = {};
    yk = _.le.location.href;
    zk = _.ve(yk, "rpctoken");
    Ak = _.ve(yk, "parent") || _.me.referrer;
    kk = _.ve(yk, "rly");
    nk = kk || (_.le !== _.le.top || _.le.opener) && _.le.name || "..";
    Bk = null;
    Ck = {};
    Dk = function() {}
    ;
    _.Ek = {
        send: Dk,
        Cb: Dk,
        WD: Dk
    };
    mk = function(a, b) {
        "/" == b.charAt(0) && (b = b.substring(1),
        a = _.le.top);
        if (0 === b.length)
            return a;
        for (b = b.split("/"); b.length; ) {
            var c = b.shift();
            "{" == c.charAt(0) && "}" == c.charAt(c.length - 1) && (c = c.substring(1, c.length - 1));
            if (".." === c)
                a = a == a.parent ? a.opener : a.parent;
            else if (".." !== c && a.frames[c]) {
                if (a = a.frames[c],
                !("postMessage"in a))
                    throw "Not a window";
            } else
                return null
        }
        return a
    }
    ;
    ok = function(a) {
        return (a = wk[a]) && a.Hz
    }
    ;
    Fk = function(a) {
        if (a.f in {})
            return !1;
        var b = a.t
          , c = wk[a.r];
        a = a.origin;
        return c && (c.Hz === b || !c.Hz && !b) && (a === c.origin || "*" === c.origin)
    }
    ;
    Gk = function(a) {
        var b = a.id.split("/")
          , c = b[b.length - 1]
          , d = a.origin;
        return function(e) {
            var f = e.origin;
            return e.f == c && (d == f || "*" == d)
        }
    }
    ;
    _.Jk = function(a, b, c) {
        a = Hk(a);
        xk[a.name] = {
            Vg: b,
            cs: a.cs,
            $p: c || Fk
        };
        Ik()
    }
    ;
    _.Kk = function(a) {
        delete xk[Hk(a).name]
    }
    ;
    Lk = {};
    Mk = function(a, b) {
        (a = Lk["_" + a]) && a[1](this) && a[0].call(this, b)
    }
    ;
    Ok = function(a) {
        var b = a.c;
        if (!b)
            return Dk;
        var c = a.r
          , d = a.g ? "legacy__" : "";
        return function() {
            var e = [].slice.call(arguments, 0);
            e.unshift(c, d + "__cb", null, b);
            _.Nk.apply(null, e)
        }
    }
    ;
    pk = function(a) {
        Bk = a
    }
    ;
    Qk = function(a) {
        Ck[a] || (Ck[a] = _.le.setTimeout(function() {
            Ck[a] = !1;
            Pk(a)
        }, 0))
    }
    ;
    Pk = function(a) {
        var b = wk[a];
        if (b && b.ready) {
            var c = b.TE;
            for (b.TE = []; c.length; )
                _.Ek.send(a, _.yf(c.shift()), b.origin)
        }
    }
    ;
    Hk = function(a) {
        return 0 === a.indexOf("legacy__") ? {
            name: a.substring(8),
            cs: !0
        } : {
            name: a,
            cs: !1
        }
    }
    ;
    Ik = function() {
        for (var a = _.Ah("rpc/residenceSec") || 60, b = (new Date).getTime() / 1E3, c = 0, d; d = vk[c]; ++c) {
            var e = d.Vm;
            if (!e || 0 < a && b - d.timestamp > a)
                vk.splice(c, 1),
                --c;
            else {
                var f = e.s
                  , h = xk[f] || xk["*"];
                if (h)
                    if (vk.splice(c, 1),
                    --c,
                    e.origin = d.origin,
                    d = Ok(e),
                    e.callback = d,
                    h.$p(e)) {
                        if ("__cb" !== f && !!h.cs != !!e.g)
                            break;
                        e = h.Vg.apply(e, e.a);
                        void 0 !== e && d(e)
                    } else
                        _.Df.debug("gapix.rpc.rejected(" + nk + "): " + f)
            }
        }
    }
    ;
    Rk = function(a, b, c) {
        vk.push({
            Vm: a,
            origin: b,
            timestamp: (new Date).getTime() / 1E3
        });
        c || Ik()
    }
    ;
    lk = function(a, b) {
        a = _.xf(a);
        Rk(a, b, !1)
    }
    ;
    Sk = function(a) {
        for (; a.length; )
            Rk(a.shift(), this.origin, !0);
        Ik()
    }
    ;
    Tk = function(a) {
        var b = !1;
        a = a.split("|");
        var c = a[0];
        0 <= c.indexOf("/") && (b = !0);
        return {
            id: c,
            origin: a[1] || "*",
            GD: b
        }
    }
    ;
    _.Uk = function(a, b, c, d) {
        var e = Tk(a);
        d && (_.le.frames[e.id] = _.le.frames[e.id] || d);
        a = e.id;
        if (!wk.hasOwnProperty(a)) {
            c = c || null;
            d = e.origin;
            if (".." === a)
                d = _.pg(Ak),
                c = c || zk;
            else if (!e.GD) {
                var f = _.me.getElementById(a);
                f && (f = f.src,
                d = _.pg(f),
                c = c || _.ve(f, "rpctoken"))
            }
            "*" === e.origin && d || (d = e.origin);
            wk[a] = {
                Hz: c,
                TE: [],
                origin: d,
                Z1: b,
                EP: function() {
                    var h = a;
                    wk[h].ready = 1;
                    Pk(h)
                }
            };
            _.Ek.Cb(a, wk[a].EP)
        }
        return wk[a].EP
    }
    ;
    _.Nk = function(a, b, c, d) {
        a = a || "..";
        _.Uk(a);
        a = a.split("|", 1)[0];
        var e = b
          , f = [].slice.call(arguments, 3)
          , h = c
          , k = nk
          , l = zk
          , m = wk[a]
          , n = k
          , q = Tk(a);
        if (m && ".." !== a) {
            if (q.GD) {
                if (!(l = wk[a].Z1)) {
                    l = Bk ? Bk.substring(1).split("/") : [nk];
                    n = l.length - 1;
                    for (var p = _.le.parent; p !== _.le.top; ) {
                        var t = p.parent;
                        if (!n--) {
                            for (var v = null, u = t.frames.length, w = 0; w < u; ++w)
                                t.frames[w] == p && (v = w);
                            l.unshift("{" + v + "}")
                        }
                        p = t
                    }
                    l = "/" + l.join("/")
                }
                n = l
            } else
                n = k = "..";
            l = m.Hz
        }
        h && q ? (m = Fk,
        q.GD && (m = Gk(q)),
        Lk["_" + ++uk] = [h, m],
        h = uk) : h = null;
        f = {
            s: e,
            f: k,
            r: n,
            t: l,
            c: h,
            a: f
        };
        e = Hk(e);
        f.s = e.name;
        f.g = e.cs;
        wk[a].TE.push(f);
        Qk(a)
    }
    ;
    if ("function" === typeof _.le.postMessage || "object" === typeof _.le.postMessage)
        _.Ek = new rk,
        _.Jk("__cb", Mk, function() {
            return !0
        }),
        _.Jk("_processBatch", Sk, function() {
            return !0
        }),
        _.Uk("..");

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var rg = function() {
        this.blockSize = -1
    };
    var sg = function() {
        this.blockSize = -1;
        this.blockSize = 64;
        this.Bc = [];
        this.PA = [];
        this.lU = [];
        this.$x = [];
        this.$x[0] = 128;
        for (var a = 1; a < this.blockSize; ++a)
            this.$x[a] = 0;
        this.Iz = this.Ho = 0;
        this.reset()
    };
    _.$a(sg, rg);
    sg.prototype.reset = function() {
        this.Bc[0] = 1732584193;
        this.Bc[1] = 4023233417;
        this.Bc[2] = 2562383102;
        this.Bc[3] = 271733878;
        this.Bc[4] = 3285377520;
        this.Iz = this.Ho = 0
    }
    ;
    var tg = function(a, b, c) {
        c || (c = 0);
        var d = a.lU;
        if ("string" === typeof b)
            for (var e = 0; 16 > e; e++)
                d[e] = b.charCodeAt(c) << 24 | b.charCodeAt(c + 1) << 16 | b.charCodeAt(c + 2) << 8 | b.charCodeAt(c + 3),
                c += 4;
        else
            for (e = 0; 16 > e; e++)
                d[e] = b[c] << 24 | b[c + 1] << 16 | b[c + 2] << 8 | b[c + 3],
                c += 4;
        for (e = 16; 80 > e; e++) {
            var f = d[e - 3] ^ d[e - 8] ^ d[e - 14] ^ d[e - 16];
            d[e] = (f << 1 | f >>> 31) & 4294967295
        }
        b = a.Bc[0];
        c = a.Bc[1];
        var h = a.Bc[2]
          , k = a.Bc[3]
          , l = a.Bc[4];
        for (e = 0; 80 > e; e++) {
            if (40 > e)
                if (20 > e) {
                    f = k ^ c & (h ^ k);
                    var m = 1518500249
                } else
                    f = c ^ h ^ k,
                    m = 1859775393;
            else
                60 > e ? (f = c & h | k & (c | h),
                m = 2400959708) : (f = c ^ h ^ k,
                m = 3395469782);
            f = (b << 5 | b >>> 27) + f + l + m + d[e] & 4294967295;
            l = k;
            k = h;
            h = (c << 30 | c >>> 2) & 4294967295;
            c = b;
            b = f
        }
        a.Bc[0] = a.Bc[0] + b & 4294967295;
        a.Bc[1] = a.Bc[1] + c & 4294967295;
        a.Bc[2] = a.Bc[2] + h & 4294967295;
        a.Bc[3] = a.Bc[3] + k & 4294967295;
        a.Bc[4] = a.Bc[4] + l & 4294967295
    };
    sg.prototype.update = function(a, b) {
        if (null != a) {
            void 0 === b && (b = a.length);
            for (var c = b - this.blockSize, d = 0, e = this.PA, f = this.Ho; d < b; ) {
                if (0 == f)
                    for (; d <= c; )
                        tg(this, a, d),
                        d += this.blockSize;
                if ("string" === typeof a)
                    for (; d < b; ) {
                        if (e[f] = a.charCodeAt(d),
                        ++f,
                        ++d,
                        f == this.blockSize) {
                            tg(this, e);
                            f = 0;
                            break
                        }
                    }
                else
                    for (; d < b; )
                        if (e[f] = a[d],
                        ++f,
                        ++d,
                        f == this.blockSize) {
                            tg(this, e);
                            f = 0;
                            break
                        }
            }
            this.Ho = f;
            this.Iz += b
        }
    }
    ;
    sg.prototype.digest = function() {
        var a = []
          , b = 8 * this.Iz;
        56 > this.Ho ? this.update(this.$x, 56 - this.Ho) : this.update(this.$x, this.blockSize - (this.Ho - 56));
        for (var c = this.blockSize - 1; 56 <= c; c--)
            this.PA[c] = b & 255,
            b /= 256;
        tg(this, this.PA);
        for (c = b = 0; 5 > c; c++)
            for (var d = 24; 0 <= d; d -= 8)
                a[b] = this.Bc[c] >> d & 255,
                ++b;
        return a
    }
    ;
    _.ug = function() {
        this.jH = new sg
    }
    ;
    _.g = _.ug.prototype;
    _.g.reset = function() {
        this.jH.reset()
    }
    ;
    _.g.NR = function(a) {
        this.jH.update(a)
    }
    ;
    _.g.FK = function() {
        return this.jH.digest()
    }
    ;
    _.g.Nt = function(a) {
        a = unescape(encodeURIComponent(a));
        for (var b = [], c = 0, d = a.length; c < d; ++c)
            b.push(a.charCodeAt(c));
        this.NR(b)
    }
    ;
    _.g.Ih = function() {
        for (var a = this.FK(), b = "", c = 0; c < a.length; c++)
            b += "0123456789ABCDEF".charAt(Math.floor(a[c] / 16)) + "0123456789ABCDEF".charAt(a[c] % 16);
        return b
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Yg = function() {
        return _.rb("Safari") && !(_.wb() || _.rb("Coast") || _.sb() || _.rb("Edge") || _.rb("Edg/") || _.rb("OPR") || _.vb() || _.rb("Silk") || _.rb("Android"))
    }
    ;
    _.Zg = _.vb();
    _.$g = _.yb() || _.rb("iPod");
    _.ah = _.rb("iPad");
    _.bh = _.rb("Android") && !(_.wb() || _.vb() || _.sb() || _.rb("Silk"));
    _.ch = _.wb();
    _.dh = _.Yg() && !_.zb();

    var Dh;
    _.Bh = function(a, b, c, d, e) {
        for (var f = 0, h = a.length, k; f < h; ) {
            var l = f + (h - f >>> 1);
            var m = c ? b.call(e, a[l], l, a) : b(d, a[l]);
            0 < m ? f = l + 1 : (h = l,
            k = !m)
        }
        return k ? f : -f - 1
    }
    ;
    _.Ch = function(a, b) {
        var c = {}, d;
        for (d in a)
            b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }
    ;
    Dh = /^https?:\/\/(?:\w|[\-\.])+\.google\.(?:\w|[\-:\.])+(?:\/[^\?#]*)?\/u\/(\d)\//;
    _.Eh = function(a) {
        var b = _.Ah("googleapis.config/sessionIndex");
        "string" === typeof b && 254 < b.length && (b = null);
        null == b && (b = window.__X_GOOG_AUTHUSER);
        "string" === typeof b && 254 < b.length && (b = null);
        if (null == b) {
            var c = window.google;
            c && (b = c.authuser)
        }
        "string" === typeof b && 254 < b.length && (b = null);
        null == b && (a = a || window.location.href,
        b = _.ve(a, "authuser") || null,
        null == b && (b = (b = a.match(Dh)) ? b[1] : null));
        if (null == b)
            return null;
        b = String(b);
        254 < b.length && (b = null);
        return b
    }
    ;

    var Wh, Vh, bi, ci, Xh, $h, Yh, di, Zh;
    _.ai = function() {
        if (Vh) {
            var a = new _.le.Uint32Array(1);
            Wh.getRandomValues(a);
            a = Number("0." + a[0])
        } else
            a = Xh,
            a += parseInt(Yh.substr(0, 20), 16),
            Yh = Zh(Yh),
            a /= $h + Math.pow(16, 20);
        return a
    }
    ;
    Wh = _.le.crypto;
    Vh = !1;
    bi = 0;
    ci = 0;
    Xh = 1;
    $h = 0;
    Yh = "";
    di = function(a) {
        a = a || _.le.event;
        var b = a.screenX + a.clientX << 16;
        b += a.screenY + a.clientY;
        b *= (new Date).getTime() % 1E6;
        Xh = Xh * b % $h;
        0 < bi && ++ci == bi && _.ze(_.le, "mousemove", di, "remove", "de")
    }
    ;
    Zh = function(a) {
        var b = new _.ug;
        b.Nt(a);
        return b.Ih()
    }
    ;
    Vh = !!Wh && "function" == typeof Wh.getRandomValues;
    Vh || ($h = 1E6 * (screen.width * screen.width + screen.height),
    Yh = Zh(_.me.cookie + "|" + _.me.location + "|" + (new Date).getTime() + "|" + Math.random()),
    bi = _.Ah("random/maxObserveMousemove") || 0,
    0 != bi && _.Ae(_.le, "mousemove", di));

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var pi;
    _.qi = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d)
                a[c] = d[c];
            for (var f = 0; f < pi.length; f++)
                c = pi[f],
                Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    }
    ;
    _.ri = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }
    ;
    pi = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    _.si = [];
    _.ti = [];
    _.ui = !1;
    _.vi = function(a) {
        _.si[_.si.length] = a;
        if (_.ui)
            for (var b = 0; b < _.ti.length; b++)
                a((0,
                _.R)(_.ti[b].wrap, _.ti[b]))
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.ni = function(a, b) {
        for (var c in a)
            if (a[c] == b)
                return !0;
        return !1
    }
    ;
    _.oi = function(a, b) {
        return "string" === typeof b ? a.getElementById(b) : b
    }
    ;

    var fj = function(a) {
        this.O = a
    };
    _.g = fj.prototype;
    _.g.value = function() {
        return this.O
    }
    ;
    _.g.je = function(a) {
        this.O.width = a;
        return this
    }
    ;
    _.g.Ob = function() {
        return this.O.width
    }
    ;
    _.g.Ad = function(a) {
        this.O.height = a;
        return this
    }
    ;
    _.g.Ac = function() {
        return this.O.height
    }
    ;
    _.g.vg = function(a) {
        this.O.style = a;
        return this
    }
    ;
    _.g.getStyle = function() {
        return this.O.style
    }
    ;
    _.gj = function(a) {
        this.O = a || {}
    }
    ;
    _.g = _.gj.prototype;
    _.g.value = function() {
        return this.O
    }
    ;
    _.g.setUrl = function(a) {
        this.O.url = a;
        return this
    }
    ;
    _.g.getUrl = function() {
        return this.O.url
    }
    ;
    _.g.vg = function(a) {
        this.O.style = a;
        return this
    }
    ;
    _.g.getStyle = function() {
        return this.O.style
    }
    ;
    _.g.Qd = function(a) {
        this.O.id = a;
        return this
    }
    ;
    _.g.getId = function() {
        return this.O.id
    }
    ;
    _.g.ql = function(a) {
        this.O.rpctoken = a;
        return this
    }
    ;
    _.hj = function(a, b) {
        a.O.messageHandlers = b;
        return a
    }
    ;
    _.ij = function(a, b) {
        a.O.messageHandlersFilter = b;
        return a
    }
    ;
    _.gj.prototype.Cp = _.ea(4);
    _.gj.prototype.getContext = function() {
        return this.O.context
    }
    ;
    _.gj.prototype.Lc = function() {
        return this.O.openerIframe
    }
    ;
    _.gj.prototype.Xl = function() {
        this.O.attributes = this.O.attributes || {};
        return new fj(this.O.attributes)
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var rj;
    _.jj = function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (_.Eb(d)) {
                var e = a.length || 0
                  , f = d.length || 0;
                a.length = e + f;
                for (var h = 0; h < f; h++)
                    a[e + h] = d[h]
            } else
                a.push(d)
        }
    }
    ;
    _.kj = function(a, b) {
        b = b || a;
        for (var c = 0, d = 0, e = {}; d < a.length; ) {
            var f = a[d++]
              , h = _.Bb(f) ? "o" + _.Gb(f) : (typeof f).charAt(0) + f;
            Object.prototype.hasOwnProperty.call(e, h) || (e[h] = !0,
            b[c++] = f)
        }
        b.length = c
    }
    ;
    _.lj = function(a, b) {
        for (var c in a)
            if (!(c in b) || a[c] !== b[c])
                return !1;
        for (var d in b)
            if (!(d in a))
                return !1;
        return !0
    }
    ;
    _.mj = function(a) {
        var b = {}, c;
        for (c in a)
            b[c] = a[c];
        return b
    }
    ;
    _.nj = function(a) {
        _.D.setTimeout(function() {
            throw a;
        }, 0)
    }
    ;
    _.oj = function(a) {
        return a
    }
    ;
    _.pj = function(a) {
        a.prototype.$goog_Thenable = !0
    }
    ;
    _.qj = function(a) {
        if (!a)
            return !1;
        try {
            return !!a.$goog_Thenable
        } catch (b) {
            return !1
        }
    }
    ;
    rj = function(a, b) {
        this.EV = a;
        this.O1 = b;
        this.Jx = 0;
        this.Ye = null
    }
    ;
    rj.prototype.get = function() {
        if (0 < this.Jx) {
            this.Jx--;
            var a = this.Ye;
            this.Ye = a.next;
            a.next = null
        } else
            a = this.EV();
        return a
    }
    ;
    rj.prototype.put = function(a) {
        this.O1(a);
        100 > this.Jx && (this.Jx++,
        a.next = this.Ye,
        this.Ye = a)
    }
    ;
    var tj, uj, sj;
    _.vj = function(a) {
        a = sj(a);
        "function" !== typeof _.D.setImmediate || _.D.Window && _.D.Window.prototype && !_.rb("Edge") && _.D.Window.prototype.setImmediate == _.D.setImmediate ? (tj || (tj = uj()),
        tj(a)) : _.D.setImmediate(a)
    }
    ;
    uj = function() {
        var a = _.D.MessageChannel;
        "undefined" === typeof a && "undefined" !== typeof window && window.postMessage && window.addEventListener && !_.rb("Presto") && (a = function() {
            var e = _.be("IFRAME");
            e.style.display = "none";
            document.documentElement.appendChild(e);
            var f = e.contentWindow;
            e = f.document;
            e.open();
            e.close();
            var h = "callImmediate" + Math.random()
              , k = "file:" == f.location.protocol ? "*" : f.location.protocol + "//" + f.location.host;
            e = (0,
            _.R)(function(l) {
                if (("*" == k || l.origin == k) && l.data == h)
                    this.port1.onmessage()
            }, this);
            f.addEventListener("message", e, !1);
            this.port1 = {};
            this.port2 = {
                postMessage: function() {
                    f.postMessage(h, k)
                }
            }
        }
        );
        if ("undefined" !== typeof a && !_.tb()) {
            var b = new a
              , c = {}
              , d = c;
            b.port1.onmessage = function() {
                if (void 0 !== c.next) {
                    c = c.next;
                    var e = c.cb;
                    c.cb = null;
                    e()
                }
            }
            ;
            return function(e) {
                d.next = {
                    cb: e
                };
                d = d.next;
                b.port2.postMessage(0)
            }
        }
        return function(e) {
            _.D.setTimeout(e, 0)
        }
    }
    ;
    sj = _.oj;
    _.vi(function(a) {
        sj = a
    });
    var wj = function() {
        this.Xz = this.gq = null
    };
    wj.prototype.add = function(a, b) {
        var c = xj.get();
        c.set(a, b);
        this.Xz ? this.Xz.next = c : this.gq = c;
        this.Xz = c
    }
    ;
    wj.prototype.remove = function() {
        var a = null;
        this.gq && (a = this.gq,
        this.gq = this.gq.next,
        this.gq || (this.Xz = null),
        a.next = null);
        return a
    }
    ;
    var xj = new rj(function() {
        return new yj
    }
    ,function(a) {
        return a.reset()
    }
    )
      , yj = function() {
        this.next = this.scope = this.Vg = null
    };
    yj.prototype.set = function(a, b) {
        this.Vg = a;
        this.scope = b;
        this.next = null
    }
    ;
    yj.prototype.reset = function() {
        this.next = this.scope = this.Vg = null
    }
    ;
    var zj, Aj, Bj, Cj, Jj;
    _.Ij = function(a, b) {
        zj || Aj();
        Bj || (zj(),
        Bj = !0);
        Cj.add(a, b)
    }
    ;
    Aj = function() {
        if (_.D.Promise && _.D.Promise.resolve) {
            var a = _.D.Promise.resolve(void 0);
            zj = function() {
                a.then(Jj)
            }
        } else
            zj = function() {
                _.vj(Jj)
            }
    }
    ;
    Bj = !1;
    Cj = new wj;
    Jj = function() {
        for (var a; a = Cj.remove(); ) {
            try {
                a.Vg.call(a.scope)
            } catch (b) {
                _.nj(b)
            }
            xj.put(a)
        }
        Bj = !1
    }
    ;
    var Mj, Nj, Yj, Wj;
    _.Lj = function(a, b) {
        this.Da = 0;
        this.xj = void 0;
        this.Ln = this.Zj = this.yb = null;
        this.ow = this.MB = !1;
        if (a != _.Cb)
            try {
                var c = this;
                a.call(b, function(d) {
                    Kj(c, 2, d)
                }, function(d) {
                    Kj(c, 3, d)
                })
            } catch (d) {
                Kj(this, 3, d)
            }
    }
    ;
    Mj = function() {
        this.next = this.context = this.$o = this.ys = this.El = null;
        this.tq = !1
    }
    ;
    Mj.prototype.reset = function() {
        this.context = this.$o = this.ys = this.El = null;
        this.tq = !1
    }
    ;
    Nj = new rj(function() {
        return new Mj
    }
    ,function(a) {
        a.reset()
    }
    );
    _.Oj = function(a, b, c) {
        var d = Nj.get();
        d.ys = a;
        d.$o = b;
        d.context = c;
        return d
    }
    ;
    _.Pj = function(a) {
        if (a instanceof _.Lj)
            return a;
        var b = new _.Lj(_.Cb);
        Kj(b, 2, a);
        return b
    }
    ;
    _.Qj = function(a) {
        return new _.Lj(function(b, c) {
            c(a)
        }
        )
    }
    ;
    _.Sj = function(a, b, c) {
        Rj(a, b, c, null) || _.Ij(_.ri(b, a))
    }
    ;
    _.Tj = function(a) {
        return new _.Lj(function(b, c) {
            var d = a.length
              , e = [];
            if (d)
                for (var f = function(m, n) {
                    d--;
                    e[m] = n;
                    0 == d && b(e)
                }, h = function(m) {
                    c(m)
                }, k = 0, l; k < a.length; k++)
                    l = a[k],
                    _.Sj(l, _.ri(f, k), h);
            else
                b(e)
        }
        )
    }
    ;
    _.Vj = function() {
        var a, b, c = new _.Lj(function(d, e) {
            a = d;
            b = e
        }
        );
        return new Uj(c,a,b)
    }
    ;
    _.Lj.prototype.then = function(a, b, c) {
        return Wj(this, "function" === typeof a ? a : null, "function" === typeof b ? b : null, c)
    }
    ;
    _.pj(_.Lj);
    _.Lj.prototype.Gz = function(a, b) {
        return Wj(this, null, a, b)
    }
    ;
    _.Lj.prototype.cancel = function(a) {
        if (0 == this.Da) {
            var b = new Xj(a);
            _.Ij(function() {
                Yj(this, b)
            }, this)
        }
    }
    ;
    Yj = function(a, b) {
        if (0 == a.Da)
            if (a.yb) {
                var c = a.yb;
                if (c.Zj) {
                    for (var d = 0, e = null, f = null, h = c.Zj; h && (h.tq || (d++,
                    h.El == a && (e = h),
                    !(e && 1 < d))); h = h.next)
                        e || (f = h);
                    e && (0 == c.Da && 1 == d ? Yj(c, b) : (f ? (d = f,
                    d.next == c.Ln && (c.Ln = d),
                    d.next = d.next.next) : Zj(c),
                    ak(c, e, 3, b)))
                }
                a.yb = null
            } else
                Kj(a, 3, b)
    }
    ;
    _.ck = function(a, b) {
        a.Zj || 2 != a.Da && 3 != a.Da || bk(a);
        a.Ln ? a.Ln.next = b : a.Zj = b;
        a.Ln = b
    }
    ;
    Wj = function(a, b, c, d) {
        var e = _.Oj(null, null, null);
        e.El = new _.Lj(function(f, h) {
            e.ys = b ? function(k) {
                try {
                    var l = b.call(d, k);
                    f(l)
                } catch (m) {
                    h(m)
                }
            }
            : f;
            e.$o = c ? function(k) {
                try {
                    var l = c.call(d, k);
                    void 0 === l && k instanceof Xj ? h(k) : f(l)
                } catch (m) {
                    h(m)
                }
            }
            : h
        }
        );
        e.El.yb = a;
        _.ck(a, e);
        return e.El
    }
    ;
    _.Lj.prototype.f4 = function(a) {
        this.Da = 0;
        Kj(this, 2, a)
    }
    ;
    _.Lj.prototype.g4 = function(a) {
        this.Da = 0;
        Kj(this, 3, a)
    }
    ;
    var Kj = function(a, b, c) {
        0 == a.Da && (a === c && (b = 3,
        c = new TypeError("Promise cannot resolve to itself")),
        a.Da = 1,
        Rj(c, a.f4, a.g4, a) || (a.xj = c,
        a.Da = b,
        a.yb = null,
        bk(a),
        3 != b || c instanceof Xj || dk(a, c)))
    }
      , Rj = function(a, b, c, d) {
        if (a instanceof _.Lj)
            return _.ck(a, _.Oj(b || _.Cb, c || null, d)),
            !0;
        if (_.qj(a))
            return a.then(b, c, d),
            !0;
        if (_.Bb(a))
            try {
                var e = a.then;
                if ("function" === typeof e)
                    return ek(a, e, b, c, d),
                    !0
            } catch (f) {
                return c.call(d, f),
                !0
            }
        return !1
    }
      , ek = function(a, b, c, d, e) {
        var f = !1
          , h = function(l) {
            f || (f = !0,
            c.call(e, l))
        }
          , k = function(l) {
            f || (f = !0,
            d.call(e, l))
        };
        try {
            b.call(a, h, k)
        } catch (l) {
            k(l)
        }
    }
      , bk = function(a) {
        a.MB || (a.MB = !0,
        _.Ij(a.rv, a))
    }
      , Zj = function(a) {
        var b = null;
        a.Zj && (b = a.Zj,
        a.Zj = b.next,
        b.next = null);
        a.Zj || (a.Ln = null);
        return b
    };
    _.Lj.prototype.rv = function() {
        for (var a; a = Zj(this); )
            ak(this, a, this.Da, this.xj);
        this.MB = !1
    }
    ;
    var ak = function(a, b, c, d) {
        if (3 == c && b.$o && !b.tq)
            for (; a && a.ow; a = a.yb)
                a.ow = !1;
        if (b.El)
            b.El.yb = null,
            fk(b, c, d);
        else
            try {
                b.tq ? b.ys.call(b.context) : fk(b, c, d)
            } catch (e) {
                gk.call(null, e)
            }
        Nj.put(b)
    }
      , fk = function(a, b, c) {
        2 == b ? a.ys.call(a.context, c) : a.$o && a.$o.call(a.context, c)
    }
      , dk = function(a, b) {
        a.ow = !0;
        _.Ij(function() {
            a.ow && gk.call(null, b)
        })
    }
      , gk = _.nj
      , Xj = function(a) {
        _.jb.call(this, a);
        this.OP = !1
    };
    _.$a(Xj, _.jb);
    Xj.prototype.name = "cancel";
    var Uj = function(a, b, c) {
        this.promise = a;
        this.resolve = b;
        this.reject = c
    };

    _.ik = function() {
        return !0
    }
    ;

    _.jk = function(a) {
        return new _.Lj(a)
    }
    ;

    var Vk;
    Vk = function() {
        function a(k, l) {
            k = window.getComputedStyle(k, "").getPropertyValue(l).match(/^([0-9]+)/);
            return parseInt(k[0], 10)
        }
        for (var b = 0, c = [document.body]; 0 < c.length; ) {
            var d = c.shift()
              , e = d.childNodes;
            if ("undefined" !== typeof d.style) {
                var f = d.style.overflowY;
                f || (f = (f = document.defaultView.getComputedStyle(d, null)) ? f.overflowY : null);
                if ("visible" != f && "inherit" != f && (f = d.style.height,
                f || (f = (f = document.defaultView.getComputedStyle(d, null)) ? f.height : ""),
                0 < f.length && "auto" != f))
                    continue
            }
            for (d = 0; d < e.length; d++) {
                f = e[d];
                if ("undefined" !== typeof f.offsetTop && "undefined" !== typeof f.offsetHeight) {
                    var h = f.offsetTop + f.offsetHeight + a(f, "margin-bottom");
                    b = Math.max(b, h)
                }
                c.push(f)
            }
        }
        return b + a(document.body, "border-bottom") + a(document.body, "margin-bottom") + a(document.body, "padding-bottom")
    }
    ;
    _.Wk = function() {
        var a = 0;
        self.innerHeight ? a = self.innerHeight : document.documentElement && document.documentElement.clientHeight ? a = document.documentElement.clientHeight : document.body && (a = document.body.clientHeight);
        var b = document.body
          , c = document.documentElement;
        if ("CSS1Compat" === document.compatMode && c.scrollHeight)
            return c.scrollHeight !== a ? c.scrollHeight : c.offsetHeight;
        if (0 <= navigator.userAgent.indexOf("AppleWebKit"))
            return Vk();
        if (b && c) {
            var d = c.scrollHeight
              , e = c.offsetHeight;
            c.clientHeight !== e && (d = b.scrollHeight,
            e = b.offsetHeight);
            return d > a ? d > e ? d : e : d < e ? d : e
        }
    }
    ;

    var Yk, Zk, $k, al, bl, cl, dl, el, fl, gl, hl, il, ml, nl, ol, pl, ql, rl, sl, tl;
    _.Xk = function(a, b) {
        if (!a)
            throw Error(b || "");
    }
    ;
    Yk = /&/g;
    Zk = /</g;
    $k = />/g;
    al = /"/g;
    bl = /'/g;
    cl = function(a) {
        return String(a).replace(Yk, "&amp;").replace(Zk, "&lt;").replace($k, "&gt;").replace(al, "&quot;").replace(bl, "&#39;")
    }
    ;
    dl = /[\ud800-\udbff][\udc00-\udfff]|[^!-~]/g;
    el = /%([a-f]|[0-9a-fA-F][a-f])/g;
    fl = /^(https?|ftp|file|chrome-extension):$/i;
    gl = function(a) {
        a = String(a);
        a = a.replace(dl, function(e) {
            try {
                return encodeURIComponent(e)
            } catch (f) {
                return encodeURIComponent(e.replace(/^[^%]+$/g, "\ufffd"))
            }
        }).replace(_.xe, function(e) {
            return e.replace(/%/g, "%25")
        }).replace(el, function(e) {
            return e.toUpperCase()
        });
        a = a.match(_.we) || [];
        var b = _.re()
          , c = function(e) {
            return e.replace(/\\/g, "%5C").replace(/\^/g, "%5E").replace(/`/g, "%60").replace(/\{/g, "%7B").replace(/\|/g, "%7C").replace(/\}/g, "%7D")
        }
          , d = !!(a[1] || "").match(fl);
        b.xq = c((a[1] || "") + (a[2] || "") + (a[3] || (a[2] && d ? "/" : "")));
        d = function(e) {
            return c(e.replace(/\?/g, "%3F").replace(/#/g, "%23"))
        }
        ;
        b.query = a[5] ? [d(a[5])] : [];
        b.Oh = a[7] ? [d(a[7])] : [];
        return b
    }
    ;
    hl = function(a) {
        return a.xq + (0 < a.query.length ? "?" + a.query.join("&") : "") + (0 < a.Oh.length ? "#" + a.Oh.join("&") : "")
    }
    ;
    il = function(a, b) {
        var c = [];
        if (a)
            for (var d in a)
                if (_.se(a, d) && null != a[d]) {
                    var e = b ? b(a[d]) : a[d];
                    c.push(encodeURIComponent(d) + "=" + encodeURIComponent(e))
                }
        return c
    }
    ;
    _.jl = function(a, b, c, d) {
        a = gl(a);
        a.query.push.apply(a.query, il(b, d));
        a.Oh.push.apply(a.Oh, il(c, d));
        return hl(a)
    }
    ;
    _.kl = function(a, b) {
        var c = gl(b);
        b = c.xq;
        c.query.length && (b += "?" + c.query.join(""));
        c.Oh.length && (b += "#" + c.Oh.join(""));
        var d = "";
        2E3 < b.length && (c = b,
        b = b.substr(0, 2E3),
        b = b.replace(_.ye, ""),
        d = c.substr(b.length));
        var e = a.createElement("div");
        a = a.createElement("a");
        c = gl(b);
        b = c.xq;
        c.query.length && (b += "?" + c.query.join(""));
        c.Oh.length && (b += "#" + c.Oh.join(""));
        _.Ld(a, new _.Cc(b,_.Bc));
        e.appendChild(a);
        b = _.$c(e.innerHTML, null);
        _.xb(e);
        e.innerHTML = _.Zc(b);
        b = String(e.firstChild.href);
        e.parentNode && e.parentNode.removeChild(e);
        c = gl(b + d);
        b = c.xq;
        c.query.length && (b += "?" + c.query.join(""));
        c.Oh.length && (b += "#" + c.Oh.join(""));
        return b
    }
    ;
    _.ll = /^https?:\/\/[^\/%\\?#\s]+\/[^\s]*$/i;
    nl = function(a) {
        for (; a.firstChild; )
            a.removeChild(a.firstChild)
    }
    ;
    ol = /^https?:\/\/(?:\w|[\-\.])+\.google\.(?:\w|[\-:\.])+(?:\/[^\?#]*)?\/b\/(\d{10,21})\//;
    pl = function(a) {
        var b = _.Ah("googleapis.config/sessionDelegate");
        "string" === typeof b && 21 < b.length && (b = null);
        null == b && (b = (a = (a || window.location.href).match(ol)) ? a[1] : null);
        if (null == b)
            return null;
        b = String(b);
        21 < b.length && (b = null);
        return b
    }
    ;
    ql = function() {
        var a = _.Be.onl;
        if (!a) {
            a = _.re();
            _.Be.onl = a;
            var b = _.re();
            a.e = function(c) {
                var d = b[c];
                d && (delete b[c],
                d())
            }
            ;
            a.a = function(c, d) {
                b[c] = d
            }
            ;
            a.r = function(c) {
                delete b[c]
            }
        }
        return a
    }
    ;
    rl = function(a, b) {
        b = b.onload;
        return "function" === typeof b ? (ql().a(a, b),
        b) : null
    }
    ;
    sl = function(a) {
        _.Xk(/^\w+$/.test(a), "Unsupported id - " + a);
        return 'onload="window.___jsl.onl.e(&#34;' + a + '&#34;)"'
    }
    ;
    tl = function(a) {
        ql().r(a)
    }
    ;
    var vl, wl, Al;
    _.ul = {
        allowtransparency: "true",
        frameborder: "0",
        hspace: "0",
        marginheight: "0",
        marginwidth: "0",
        scrolling: "no",
        style: "",
        tabindex: "0",
        vspace: "0",
        width: "100%"
    };
    vl = {
        allowtransparency: !0,
        onload: !0
    };
    wl = 0;
    _.xl = function(a, b) {
        var c = 0;
        do
            var d = b.id || ["I", wl++, "_", (new Date).getTime()].join("");
        while (a.getElementById(d) && 5 > ++c);
        _.Xk(5 > c, "Error creating iframe id");
        return d
    }
    ;
    _.yl = function(a, b) {
        return a ? b + "/" + a : ""
    }
    ;
    _.zl = function(a, b, c, d) {
        var e = {}
          , f = {};
        a.documentMode && 9 > a.documentMode && (e.hostiemode = a.documentMode);
        _.te(d.queryParams || {}, e);
        _.te(d.fragmentParams || {}, f);
        var h = d.pfname;
        var k = _.re();
        _.Ah("iframes/dropLegacyIdParam") || (k.id = c);
        k._gfid = c;
        k.parent = a.location.protocol + "//" + a.location.host;
        c = _.ve(a.location.href, "parent");
        h = h || "";
        !h && c && (h = _.ve(a.location.href, "_gfid", "") || _.ve(a.location.href, "id", ""),
        h = _.yl(h, _.ve(a.location.href, "pfname", "")));
        h || (c = _.xf(_.ve(a.location.href, "jcp", ""))) && "object" == typeof c && (h = _.yl(c.id, c.pfname));
        k.pfname = h;
        d.connectWithJsonParam && (h = {},
        h.jcp = _.yf(k),
        k = h);
        h = _.ve(b, "rpctoken") || e.rpctoken || f.rpctoken;
        h || (h = d.rpctoken || String(Math.round(1E8 * _.ai())),
        k.rpctoken = h);
        d.rpctoken = h;
        _.te(k, d.connectWithQueryParams ? e : f);
        k = a.location.href;
        a = _.re();
        (h = _.ve(k, "_bsh", _.Be.bsh)) && (a._bsh = h);
        (k = _.Be.dpo ? _.Be.h : _.ve(k, "jsh", _.Be.h)) && (a.jsh = k);
        d.hintInFragment ? _.te(a, f) : _.te(a, e);
        return _.jl(b, e, f, d.paramsSerializer)
    }
    ;
    Al = function(a) {
        _.Xk(!a || _.ll.test(a), "Illegal url for new iframe - " + a)
    }
    ;
    _.Bl = function(a, b, c, d, e) {
        Al(c.src);
        var f, h = rl(d, c), k = h ? sl(d) : "";
        try {
            document.all && (f = a.createElement('<iframe frameborder="' + cl(String(c.frameborder)) + '" scrolling="' + cl(String(c.scrolling)) + '" ' + k + ' name="' + cl(String(c.name)) + '"/>'))
        } catch (m) {} finally {
            f || (f = _.Td(a).ma("IFRAME"),
            h && (f.onload = function() {
                f.onload = null;
                h.call(this)
            }
            ,
            tl(d)))
        }
        f.setAttribute("ng-non-bindable", "");
        for (var l in c)
            a = c[l],
            "style" === l && "object" === typeof a ? _.te(a, f.style) : vl[l] || f.setAttribute(l, String(a));
        (l = e && e.beforeNode || null) || e && e.dontclear || nl(b);
        b.insertBefore(f, l);
        f = l ? l.previousSibling : b.lastChild;
        c.allowtransparency && (f.allowTransparency = !0);
        return f
    }
    ;
    var Cl, Fl;
    Cl = /^:[\w]+$/;
    _.Dl = /:([a-zA-Z_]+):/g;
    _.El = function() {
        var a = _.Eh() || "0"
          , b = pl();
        var c = _.Eh(void 0) || a;
        var d = pl(void 0)
          , e = "";
        c && (e += "u/" + encodeURIComponent(String(c)) + "/");
        d && (e += "b/" + encodeURIComponent(String(d)) + "/");
        c = e || null;
        (e = (d = !1 === _.Ah("isLoggedIn")) ? "_/im/" : "") && (c = "");
        var f = _.Ah("iframes/:socialhost:")
          , h = _.Ah("iframes/:im_socialhost:");
        return ml = {
            socialhost: f,
            ctx_socialhost: d ? h : f,
            session_index: a,
            session_delegate: b,
            session_prefix: c,
            im_prefix: e
        }
    }
    ;
    Fl = function(a, b) {
        return _.El()[b] || ""
    }
    ;
    _.Gl = function(a) {
        return _.kl(_.me, a.replace(_.Dl, Fl))
    }
    ;
    _.Hl = function(a) {
        var b = a;
        Cl.test(a) && (b = _.Ah("iframes/" + b.substring(1) + "/url"),
        _.Xk(!!b, "Unknown iframe url config for - " + a));
        return _.Gl(b)
    }
    ;
    _.Il = function(a, b, c) {
        c = c || {};
        var d = c.attributes || {};
        _.Xk(!(c.allowPost || c.forcePost) || !d.onload, "onload is not supported by post iframe (allowPost or forcePost)");
        a = _.Hl(a);
        d = b.ownerDocument || _.me;
        var e = _.xl(d, c);
        a = _.zl(d, a, e, c);
        var f = c
          , h = _.re();
        _.te(_.ul, h);
        _.te(f.attributes, h);
        h.name = h.id = e;
        h.src = a;
        c.eurl = a;
        c = (f = c) || {};
        var k = !!c.allowPost;
        if (c.forcePost || k && 2E3 < a.length) {
            c = gl(a);
            h.src = "";
            f.dropDataPostorigin || (h["data-postorigin"] = a);
            a = _.Bl(d, b, h, e);
            if (-1 != navigator.userAgent.indexOf("WebKit")) {
                var l = a.contentWindow.document;
                l.open();
                h = l.createElement("div");
                k = {};
                var m = e + "_inner";
                k.name = m;
                k.src = "";
                k.style = "display:none";
                _.Bl(d, h, k, m, f)
            }
            h = (f = c.query[0]) ? f.split("&") : [];
            f = [];
            for (k = 0; k < h.length; k++)
                m = h[k].split("=", 2),
                f.push([decodeURIComponent(m[0]), decodeURIComponent(m[1])]);
            c.query = [];
            h = hl(c);
            _.Xk(_.ll.test(h), "Invalid URL: " + h);
            c = d.createElement("form");
            c.method = "POST";
            c.target = e;
            c.style.display = "none";
            e = h instanceof _.Cc ? h : _.Kc(h);
            c.action = _.Dc(e);
            for (e = 0; e < f.length; e++)
                h = d.createElement("input"),
                h.type = "hidden",
                h.name = f[e][0],
                h.value = f[e][1],
                c.appendChild(h);
            b.appendChild(c);
            c.submit();
            c.parentNode.removeChild(c);
            l && l.close();
            b = a
        } else
            b = _.Bl(d, b, h, e, f);
        return b
    }
    ;

    var Jl = function(a, b) {
        return _.Bh(a, b, !0, void 0, void 0)
    }, Kl = function(a) {
        var b = function(c) {
            return new (a().Context)(c)
        };
        b.prototype.addOnConnectHandler = function(c, d, e, f) {
            return a().Context.prototype.addOnConnectHandler.apply(this, [c, d, e, f])
        }
        ;
        b.prototype.addOnOpenerHandler = function(c, d, e) {
            return a().Context.prototype.addOnOpenerHandler.apply(this, [c, d, e])
        }
        ;
        b.prototype.closeSelf = function(c, d, e) {
            return a().Context.prototype.closeSelf.apply(this, [c, d, e])
        }
        ;
        b.prototype.connectIframes = function(c, d) {
            a().Context.prototype.connectIframes.apply(this, [c, d])
        }
        ;
        b.prototype.getFrameName = function() {
            return a().Context.prototype.getFrameName.apply(this)
        }
        ;
        b.prototype.getGlobalParam = function(c) {
            a().Context.prototype.getGlobalParam.apply(this, [c])
        }
        ;
        b.prototype.getParentIframe = function() {
            return a().Context.prototype.getParentIframe.apply(this)
        }
        ;
        b.prototype.getWindow = function() {
            return a().Context.prototype.getWindow.apply(this)
        }
        ;
        b.prototype.isDisposed = function() {
            return a().Context.prototype.isDisposed.apply(this)
        }
        ;
        b.prototype.open = function(c, d) {
            return a().Context.prototype.open.apply(this, [c, d])
        }
        ;
        b.prototype.openChild = function(c) {
            return a().Context.prototype.openChild.apply(this, [c])
        }
        ;
        b.prototype.ready = function(c, d, e, f) {
            a().Context.prototype.ready.apply(this, [c, d, e, f])
        }
        ;
        b.prototype.removeOnConnectHandler = function(c) {
            a().Context.prototype.removeOnConnectHandler.apply(this, [c])
        }
        ;
        b.prototype.restyleSelf = function(c, d, e) {
            return a().Context.prototype.restyleSelf.apply(this, [c, d, e])
        }
        ;
        b.prototype.setCloseSelfFilter = function(c) {
            a().Context.prototype.setCloseSelfFilter.apply(this, [c])
        }
        ;
        b.prototype.setGlobalParam = function(c, d) {
            a().Context.prototype.setGlobalParam.apply(this, [c, d])
        }
        ;
        b.prototype.setRestyleSelfFilter = function(c) {
            a().Context.prototype.setRestyleSelfFilter.apply(this, [c])
        }
        ;
        return b
    }, Ll = function(a) {
        var b = function(c, d, e, f) {
            return new (a().Iframe)(c,d,e,f)
        };
        b.prototype.applyIframesApi = function(c) {
            a().Iframe.prototype.applyIframesApi(c)
        }
        ;
        b.prototype.close = function(c, d) {
            return a().Iframe.prototype.close.apply(this, [c, d])
        }
        ;
        b.prototype.getContext = function() {
            return a().Iframe.prototype.getContext.apply(this, [])
        }
        ;
        b.prototype.getFrameName = function() {
            return a().Iframe.prototype.getFrameName.apply(this, [])
        }
        ;
        b.prototype.getId = function() {
            return a().Iframe.prototype.getId.apply(this, [])
        }
        ;
        b.prototype.getIframeEl = function() {
            return a().Iframe.prototype.getIframeEl.apply(this, [])
        }
        ;
        b.prototype.getOrigin = function() {
            return a().Iframe.prototype.getOrigin.apply(this, [])
        }
        ;
        b.prototype.getParam = function(c) {
            a().Iframe.prototype.getParam.apply(this, [c])
        }
        ;
        b.prototype.getSiteEl = function() {
            return a().Iframe.prototype.getSiteEl.apply(this, [])
        }
        ;
        b.prototype.getWindow = function() {
            return a().Iframe.prototype.getWindow.apply(this, [])
        }
        ;
        b.prototype.isDisposed = function() {
            return a().Iframe.prototype.isDisposed.apply(this, [])
        }
        ;
        b.prototype.ping = function(c, d) {
            return a().Iframe.prototype.ping.apply(this, [c, d])
        }
        ;
        b.prototype.register = function(c, d, e) {
            a().Iframe.prototype.register.apply(this, [c, d, e])
        }
        ;
        b.prototype.registerWasClosed = function(c, d) {
            a().Iframe.prototype.registerWasClosed.apply(this, [c, d])
        }
        ;
        b.prototype.registerWasRestyled = function(c, d) {
            a().Iframe.prototype.registerWasRestyled.apply(this, [c, d])
        }
        ;
        b.prototype.restyle = function(c, d) {
            return a().Iframe.prototype.restyle.apply(this, [c, d])
        }
        ;
        b.prototype.send = function(c, d, e, f) {
            return a().Iframe.prototype.send.apply(this, [c, d, e, f])
        }
        ;
        b.prototype.setParam = function(c, d) {
            a().Iframe.prototype.setParam.apply(this, [c, d])
        }
        ;
        b.prototype.setSiteEl = function(c) {
            a().Iframe.prototype.setSiteEl.apply(this, [c])
        }
        ;
        b.prototype.unregister = function(c, d) {
            a().Iframe.prototype.unregister.apply(this, [c, d])
        }
        ;
        return b
    }, Ml, Nl, Ul, Wl, bm, km, lm, mm, pm, qm, tm, um, vm, xm, wm, ym;
    _.gj.prototype.Cp = _.cb(4, function(a) {
        this.O.apis = a;
        return this
    });
    Ml = function(a, b) {
        a.O.onload = b
    }
    ;
    Nl = function(a) {
        return a.O.rpctoken
    }
    ;
    _.Ol = function(a, b) {
        a.O.queryParams = b;
        return a
    }
    ;
    _.Pl = function(a, b) {
        a.O.relayOpen = b;
        return a
    }
    ;
    _.Tl = function(a, b) {
        a.O.onClose = b;
        return a
    }
    ;
    Ul = function(a, b) {
        a.O.controllerData = b
    }
    ;
    _.Vl = function(a) {
        a.O.waitForOnload = !0;
        return a
    }
    ;
    Wl = function(a) {
        return (a = a.O.timeout) ? a : null
    }
    ;
    _.Xl = function() {
        return _.hk
    }
    ;
    _.Yl = function(a) {
        return !!a && "object" === typeof a && _.oe.test(a.push)
    }
    ;
    _.Zl = function(a) {
        for (var b = 0; b < this.length; b++)
            if (this[b] === a)
                return b;
        return -1
    }
    ;
    _.$l = function(a, b, c) {
        if (a) {
            _.Xk(_.Yl(a), "arrayForEach was called with a non array value");
            for (var d = 0; d < a.length; d++)
                b.call(c, a[d], d)
        }
    }
    ;
    _.am = function(a, b, c) {
        if (a)
            if (_.Yl(a))
                _.$l(a, b, c);
            else {
                _.Xk("object" === typeof a, "objectForEach was called with a non object value");
                c = c || a;
                for (var d in a)
                    _.se(a, d) && void 0 !== a[d] && b.call(c, a[d], d)
            }
    }
    ;
    bm = function(a) {
        this.O = a || {}
    }
    ;
    bm.prototype.value = function() {
        return this.O
    }
    ;
    bm.prototype.getIframe = function() {
        return this.O.iframe
    }
    ;
    var cm = function(a, b) {
        a.O.role = b;
        return a
    }
      , dm = function(a, b) {
        a.O.data = b;
        return a
    };
    bm.prototype.Cj = function(a) {
        this.O.setRpcReady = a;
        return this
    }
    ;
    var em = function(a) {
        return a.O.setRpcReady
    };
    bm.prototype.ql = function(a) {
        this.O.rpctoken = a;
        return this
    }
    ;
    var fm = function(a) {
        a.O.selfConnect = !0;
        return a
    }
      , gm = function(a) {
        this.O = a || {}
    };
    gm.prototype.value = function() {
        return this.O
    }
    ;
    var im = function(a) {
        var b = new hm;
        b.O.role = a;
        return b
    };
    gm.prototype.lM = function() {
        return this.O.role
    }
    ;
    gm.prototype.qc = function(a) {
        this.O.handler = a;
        return this
    }
    ;
    gm.prototype.kb = function() {
        return this.O.handler
    }
    ;
    var jm = function(a, b) {
        a.O.filter = b;
        return a
    };
    gm.prototype.Cp = function(a) {
        this.O.apis = a;
        return this
    }
    ;
    mm = /^[\w\.\-]*$/;
    _.nm = function(a) {
        return a.getOrigin() === a.getContext().getOrigin()
    }
    ;
    _.om = function(a) {
        for (var b = _.re(), c = 0; c < a.length; c++)
            b[a[c]] = !0;
        return function(d) {
            return !!b[d.zd]
        }
    }
    ;
    pm = function(a, b, c) {
        a = km[a];
        if (!a)
            return [];
        for (var d = [], e = 0; e < a.length; e++)
            d.push(_.Pj(a[e].call(c, b, c)));
        return d
    }
    ;
    qm = function(a, b, c) {
        return function(d) {
            if (!b.isDisposed()) {
                var e = this.origin
                  , f = b.getOrigin();
                _.Xk(e === f, "Wrong origin " + e + " != " + f);
                e = this.callback;
                d = pm(a, d, b);
                !c && 0 < d.length && _.Tj(d).then(e)
            }
        }
    }
    ;
    _.rm = function(a, b, c) {
        _.Xk("_default" != a, "Cannot update default api");
        lm[a] = {
            map: b,
            filter: c
        }
    }
    ;
    _.sm = function(a, b, c) {
        _.Xk("_default" != a, "Cannot update default api");
        _.pe(lm, a, {
            map: {},
            filter: _.nm
        }).map[b] = c
    }
    ;
    tm = function(a, b) {
        _.pe(lm, "_default", {
            map: {},
            filter: _.ik
        }).map[a] = b;
        _.am(_.hk.zf, function(c) {
            c.register(a, b, _.ik)
        })
    }
    ;
    um = /^https?:\/\/[^\/%\\?#\s]+$/i;
    vm = {
        longdesc: !0,
        name: !0,
        src: !0,
        frameborder: !0,
        marginwidth: !0,
        marginheight: !0,
        scrolling: !0,
        align: !0,
        height: !0,
        width: !0,
        id: !0,
        "class": !0,
        title: !0,
        tabindex: !0,
        hspace: !0,
        vspace: !0,
        allowtransparency: !0
    };
    xm = function(a) {
        this.resolve = this.reject = null;
        this.promise = _.jk((0,
        _.R)(function(b, c) {
            this.resolve = b;
            this.reject = c
        }, this));
        a && (this.promise = wm(this.promise, a))
    }
    ;
    wm = function(a, b) {
        return a.then(function(c) {
            try {
                b(c)
            } catch (d) {}
            return c
        })
    }
    ;
    ym = function(a) {
        this.ve = a;
        this.Context = Kl(a);
        this.Iframe = Ll(a)
    }
    ;
    _.g = ym.prototype;
    _.g.CROSS_ORIGIN_IFRAMES_FILTER = function(a) {
        return this.ve().CROSS_ORIGIN_IFRAMES_FILTER(a)
    }
    ;
    _.g.SAME_ORIGIN_IFRAMES_FILTER = function(a) {
        return this.ve().SAME_ORIGIN_IFRAMES_FILTER(a)
    }
    ;
    _.g.create = function(a, b, c) {
        return this.ve().create(a, b, c)
    }
    ;
    _.g.getBeforeOpenStyle = function(a) {
        return this.ve().getBeforeOpenStyle(a)
    }
    ;
    _.g.getContext = function() {
        return this.ve().getContext()
    }
    ;
    _.g.getStyle = function(a) {
        return this.ve().getStyle(a)
    }
    ;
    _.g.makeWhiteListIframesFilter = function(a) {
        return this.ve().makeWhiteListIframesFilter(a)
    }
    ;
    _.g.registerBeforeOpenStyle = function(a, b) {
        return this.ve().registerBeforeOpenStyle(a, b)
    }
    ;
    _.g.registerIframesApi = function(a, b, c) {
        return this.ve().registerIframesApi(a, b, c)
    }
    ;
    _.g.registerIframesApiHandler = function(a, b, c) {
        return this.ve().registerIframesApiHandler(a, b, c)
    }
    ;
    _.g.registerStyle = function(a, b) {
        return this.ve().registerStyle(a, b)
    }
    ;
    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var zm = function() {
        this.uh = []
    };
    zm.prototype.ve = function(a) {
        return this.uh.length ? Am(this.uh[0], a) : void 0
    }
    ;
    var Am = function(a, b) {
        b = void 0 === b ? function(c) {
            return new c
        }
        : b;
        return a.mB ? b(a.mB) : a.instance
    }
      , Bm = function() {
        zm.apply(this, arguments)
    };
    _.O(Bm, zm);
    var Dm = function(a) {
        var b = Cm.AK
          , c = a.priority
          , d = ~Jl(b.uh, function(e) {
            return e.priority < c ? -1 : 1
        });
        b.uh.splice(d, 0, a)
    };
    var Cm = new function() {
        var a = this;
        this.AK = new Bm;
        this.instance = new ym(function() {
            return a.AK.ve()()
        }
        )
    }
    ;
    Dm({
        instance: function() {
            return window.gapi.iframes
        },
        priority: 1
    });
    _.Em = Cm.instance;
    var Fm, Gm;
    Fm = {
        height: !0,
        width: !0
    };
    Gm = /^(?!-*(?:expression|(?:moz-)?binding))(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[a-z]{1,2}|%)?|!important|)$/i;
    _.Hm = function(a) {
        "number" === typeof a && (a = String(a) + "px");
        return a
    }
    ;
    var Im = function() {
        bm.apply(this, arguments)
    };
    _.O(Im, bm);
    var hm = function() {
        gm.apply(this, arguments)
    };
    _.O(hm, gm);
    var Jm = function() {
        _.gj.apply(this, arguments)
    };
    _.O(Jm, _.gj);
    var Km = function(a) {
        Jm.call(this, a)
    };
    _.O(Km, Jm);
    var Lm = function(a, b) {
        a.O.frameName = b;
        return a
    };
    Km.prototype.getFrameName = function() {
        return this.O.frameName
    }
    ;
    var Mm = function(a, b) {
        a.O.rpcAddr = b;
        return a
    };
    Km.prototype.Gf = function() {
        return this.O.rpcAddr
    }
    ;
    var Nm = function(a, b) {
        a.O.retAddr = b;
        return a
    };
    _.g = Km.prototype;
    _.g.$g = function() {
        return this.O.retAddr
    }
    ;
    _.g.Bi = function(a) {
        this.O.origin = a;
        return this
    }
    ;
    _.g.getOrigin = function() {
        return this.O.origin
    }
    ;
    _.g.Cj = function(a) {
        this.O.setRpcReady = a;
        return this
    }
    ;
    _.g.Fp = function(a) {
        this.O.context = a
    }
    ;
    var Om = function(a, b) {
        a.O._rpcReadyFn = b
    };
    Km.prototype.getIframeEl = function() {
        return this.O.iframeEl
    }
    ;
    var Pm = function(a, b, c) {
        var d = a.Gf()
          , e = b.$g();
        Nm(Mm(c, a.$g() + "/" + b.Gf()), e + "/" + d);
        Lm(c, b.getFrameName()).Bi(b.getOrigin())
    };
    var Rm = function(a, b) {
        if (_.md && _.dh && a) {
            a.focus();
            var c = 0
              , d = null;
            d = a.setInterval(function() {
                b.closed || 5 == c ? (a.clearInterval(d),
                Qm(b)) : (b.close(),
                c++)
            }, 150)
        } else
            b.close(),
            Qm(b)
    }
      , Qm = function(a) {
        a.closed || a.document && a.document.body && _.ke(a.document.body, "Please close this window.")
    };
    _.Sm = function(a, b, c, d) {
        this.dg = !1;
        this.Kl = a;
        this.fF = b;
        this.Yn = c;
        this.Ia = d;
        this.XP = this.Ia.$g();
        this.zd = this.Ia.getOrigin();
        this.GZ = this.Ia.getIframeEl();
        this.lR = this.Ia.O.where;
        this.uh = [];
        this.applyIframesApi("_default");
        a = this.Ia.O.apis || [];
        for (b = 0; b < a.length; b++)
            this.applyIframesApi(a[b]);
        this.Kl.zf[c] = this
    }
    ;
    _.g = _.Sm.prototype;
    _.g.isDisposed = function() {
        return this.dg
    }
    ;
    _.g.Ga = function() {
        if (!this.isDisposed()) {
            for (var a = 0; a < this.uh.length; a++)
                this.unregister(this.uh[a]);
            delete _.hk.zf[this.getFrameName()];
            this.dg = !0
        }
    }
    ;
    _.g.getContext = function() {
        return this.Kl
    }
    ;
    _.g.getOptions = function() {
        return this.Ia
    }
    ;
    _.g.Gf = function() {
        return this.fF
    }
    ;
    _.g.$g = function() {
        return this.XP
    }
    ;
    _.g.getFrameName = function() {
        return this.Yn
    }
    ;
    _.g.getIframeEl = function() {
        return this.GZ
    }
    ;
    _.g.getSiteEl = function() {
        return this.lR
    }
    ;
    _.g.setSiteEl = function(a) {
        this.lR = a
    }
    ;
    _.g.Cj = function() {
        (0,
        this.Ia.O._rpcReadyFn)()
    }
    ;
    _.g.setParam = function(a, b) {
        this.Ia.value()[a] = b
    }
    ;
    _.g.getParam = function(a) {
        return this.Ia.value()[a]
    }
    ;
    _.g.$b = function() {
        return this.Ia.value()
    }
    ;
    _.g.getId = function() {
        return this.Ia.getId()
    }
    ;
    _.g.getOrigin = function() {
        return this.zd
    }
    ;
    var Tm = function(a, b) {
        var c = a.Kl.getFrameName();
        return a.Yn + ":" + c + ":" + b
    };
    _.g = _.Sm.prototype;
    _.g.register = function(a, b, c) {
        _.Xk(!this.isDisposed(), "Cannot register handler on disposed iframe " + a);
        _.Xk((c || _.nm)(this), "Rejecting untrusted message " + a);
        c = Tm(this, a);
        1 == _.pe(km, c, []).push(b) && (this.uh.push(a),
        _.Jk(c, qm(c, this, "_g_wasClosed" === a)))
    }
    ;
    _.g.unregister = function(a, b) {
        var c = Tm(this, a)
          , d = km[c];
        d && (b ? (b = _.Zl.call(d, b),
        0 <= b && d.splice(b, 1)) : d.splice(0, d.length),
        0 == d.length && (b = _.Zl.call(this.uh, a),
        0 <= b && this.uh.splice(b, 1),
        _.Kk(c)))
    }
    ;
    _.g.IX = function() {
        return this.uh
    }
    ;
    _.g.applyIframesApi = function(a) {
        this.CA = this.CA || [];
        if (!(0 <= _.Zl.call(this.CA, a))) {
            this.CA.push(a);
            a = lm[a] || {
                map: {}
            };
            for (var b in a.map)
                _.se(a.map, b) && this.register(b, a.map[b], a.filter)
        }
    }
    ;
    _.g.getWindow = function() {
        if (!_.nm(this))
            return null;
        var a = this.Ia.O._popupWindow;
        if (a)
            return a;
        var b = this.fF.split("/");
        a = this.getContext().getWindow();
        for (var c = 0; c < b.length && a; c++) {
            var d = b[c];
            a = ".." === d ? a == a.parent ? a.opener : a.parent : a.frames[d]
        }
        return a
    }
    ;
    var Um = function(a) {
        var b = {};
        if (a)
            for (var c in a)
                _.se(a, c) && _.se(Fm, c) && Gm.test(a[c]) && (b[c] = a[c]);
        return b
    };
    _.g = _.Sm.prototype;
    _.g.close = function(a, b) {
        return Vm(this, "_g_close", a, b)
    }
    ;
    _.g.restyle = function(a, b) {
        return Vm(this, "_g_restyle", a, b)
    }
    ;
    _.g.qp = function(a, b) {
        return Vm(this, "_g_restyleDone", a, b)
    }
    ;
    _.g.vV = function(a) {
        return this.getContext().closeSelf(a, void 0, this)
    }
    ;
    _.g.V1 = function(a) {
        if (a && "object" === typeof a)
            return this.getContext().restyleSelf(a, void 0, this)
    }
    ;
    _.g.W1 = function(a) {
        var b = this.Ia.O.onRestyle;
        b && b.call(this, a, this);
        a = a && "object" === typeof a ? Um(a) : {};
        (b = this.getIframeEl()) && a && "object" === typeof a && (_.se(a, "height") && (a.height = _.Hm(a.height)),
        _.se(a, "width") && (a.width = _.Hm(a.width)),
        _.te(a, b.style))
    }
    ;
    _.g.wV = function(a) {
        var b = this.Ia.O.onClose;
        b && b.call(this, a, this);
        if (b = this.getOptions().O._popupWindow) {
            var c = this.getContext().getWindow().document.getElementById(this.getId());
            c && c.parentNode && c.parentNode.removeChild(c);
            Rm(this.getContext().getWindow(), b)
        }
        b || (b = this.getIframeEl()) && b.parentNode && b.parentNode.removeChild(b);
        if (b = this.Ia.O.controller)
            c = {},
            c.frameName = this.getFrameName(),
            Vm(b, "_g_disposeControl", c);
        b = Tm(this, "_g_wasClosed");
        pm(b, a, this)
    }
    ;
    _.g.registerWasRestyled = function(a, b) {
        this.register("_g_wasRestyled", a, b)
    }
    ;
    _.g.registerWasClosed = function(a, b) {
        this.register("_g_wasClosed", a, b)
    }
    ;
    _.g.x4 = function() {
        delete this.getContext().zf[this.getFrameName()];
        this.getContext().getWindow().setTimeout((0,
        _.R)(function() {
            this.Ga()
        }, this), 0)
    }
    ;
    _.g.send = function(a, b, c, d) {
        _.Xk(!this.isDisposed(), "Cannot send message to disposed iframe - " + a);
        _.Xk((d || _.nm)(this), "Wrong target for message " + a);
        c = new xm(c);
        a = this.Kl.getFrameName() + ":" + this.Yn + ":" + a;
        _.Nk(this.fF, a, c.resolve, b);
        return c.promise
    }
    ;
    var Vm = function(a, b, c, d) {
        return a.send(b, c, d, _.ik)
    };
    _.g = _.Sm.prototype;
    _.g.X0 = function(a) {
        return a
    }
    ;
    _.g.ping = function(a, b) {
        return Vm(this, "_g_ping", b, a)
    }
    ;
    _.g.AV = function(a) {
        a = a && "object" === typeof a ? a : {};
        for (var b = a.rpcAddr, c = (this.Gf() + "/" + b).split("/"), d = this.getContext().getWindow(), e; (e = c.shift()) && d; )
            d = ".." == e ? d.parent : d.frames[e];
        _.Xk(!!d, "Bad rpc address " + b);
        a._window = d;
        a._parentRpcAddr = this.Gf();
        a._parentRetAddr = this.$g();
        this.getContext();
        b = new _.Wm(a);
        this.m0 && this.m0(b, a.controllerData);
        this.gB = this.gB || [];
        this.gB.push(b, a.controllerData)
    }
    ;
    _.g.OV = function(a) {
        a = (a || {}).frameName;
        for (var b = this.gB || [], c = 0; c < b.length; c++)
            if (b[c].getFrameName() === a) {
                a = b.splice(c, 1)[0];
                a.Ga();
                this.q0 && this.q0(a);
                return
            }
        _.Xk(!1, "Unknown contolled iframe to dispose - " + a)
    }
    ;
    _.g.yV = function(a) {
        var b = new Km(a);
        a = new Im(b.value());
        if (a.O.selfConnect)
            var c = this;
        else
            (_.Xk(um.test(b.getOrigin()), "Illegal origin for connected iframe - " + b.getOrigin()),
            c = this.getContext().zf[b.getFrameName()],
            c) ? em(b) && (c.Cj(),
            Vm(c, "_g_rpcReady")) : (b = Lm(Nm(Mm(new Km, b.Gf()), b.$g()).Bi(b.getOrigin()), b.getFrameName()).Cj(em(b)).ql(Nl(b)),
            c = this.getContext().Wj(b.value()));
        b = this.getContext();
        var d = a.O.role;
        a = a.O.data;
        Xm(b);
        d = d || "";
        _.pe(b.dB, d, []).push({
            Xh: c,
            data: a
        });
        Ym(c, a, b.qE[d])
    }
    ;
    _.g.xG = function(a, b) {
        (new Km(b)).O._relayedDepth || (b = {},
        fm(cm(new Im(b), "_opener")),
        Vm(a, "_g_connect", b))
    }
    ;
    _.g.eP = function(a) {
        var b = this
          , c = a.O.messageHandlers
          , d = a.O.messageHandlersFilter
          , e = a.O.onClose;
        _.Tl(_.ij(_.hj(a, null), null), null);
        return Vm(this, "_g_open", a.value()).then(function(f) {
            var h = new Km(f[0])
              , k = h.getFrameName();
            f = new Km;
            var l = b.$g()
              , m = h.$g();
            Nm(Mm(f, b.Gf() + "/" + h.Gf()), m + "/" + l);
            Lm(f, k);
            f.Bi(h.getOrigin());
            f.Cp(h.O.apis);
            f.ql(Nl(a));
            _.hj(f, c);
            _.ij(f, d);
            _.Tl(f, e);
            (h = b.getContext().zf[k]) || (h = b.getContext().Wj(f.value()));
            return h
        })
    }
    ;
    _.g.gF = function(a) {
        var b = a.getUrl();
        _.Xk(!b || _.ll.test(b), "Illegal url for new iframe - " + b);
        var c = a.Xl().value();
        b = {};
        for (var d in c)
            _.se(c, d) && _.se(vm, d) && (b[d] = c[d]);
        _.se(c, "style") && (d = c.style,
        "object" === typeof d && (b.style = Um(d)));
        a.value().attributes = b
    }
    ;
    _.g.K0 = function(a) {
        a = new Km(a);
        this.gF(a);
        var b = a.O._relayedDepth || 0;
        a.O._relayedDepth = b + 1;
        a.O.openerIframe = this;
        var c = Nl(a);
        a.ql(null);
        var d = this;
        return this.getContext().open(a.value()).then(function(e) {
            var f = (new Km(e.$b())).O.apis
              , h = new Km;
            Pm(e, d, h);
            0 == b && cm(new Im(h.value()), "_opener");
            h.Cj(!0);
            h.ql(c);
            Vm(e, "_g_connect", h.value());
            h = new Km;
            Lm(Nm(Mm(h, e.Gf()), e.XP), e.getFrameName()).Bi(e.getOrigin()).Cp(f);
            return h.value()
        })
    }
    ;
    _.g.U1 = function(a) {
        this.getContext().addOnOpenerHandler(function(b) {
            b.send("_g_wasRestyled", a, void 0, _.ik)
        }, null, _.ik)
    }
    ;
    var cn;
    _.Zm = _.re();
    _.$m = _.re();
    _.an = function(a, b) {
        _.Zm[a] = b
    }
    ;
    _.bn = function(a) {
        return _.Zm[a]
    }
    ;
    cn = function(a, b) {
        _.ue.load("gapi.iframes.style." + a, b)
    }
    ;
    _.dn = function(a, b) {
        _.$m[a] = b
    }
    ;
    _.en = function(a) {
        return _.$m[a]
    }
    ;
    _.Wm = function(a) {
        a = a || {};
        this.dg = !1;
        this.kP = _.re();
        this.zf = _.re();
        this.uf = a._window || _.le;
        this.$c = this.uf.location.href;
        this.lP = (this.EE = fn(this.$c, "parent")) ? fn(this.$c, "pfname") : "";
        this.Ba = this.EE ? fn(this.$c, "_gfid") || fn(this.$c, "id") : "";
        this.Yn = _.yl(this.Ba, this.lP);
        this.zd = _.pg(this.$c);
        if (this.Ba) {
            var b = new Km;
            Mm(b, a._parentRpcAddr || "..");
            Nm(b, a._parentRetAddr || this.Ba);
            b.Bi(_.pg(this.EE || this.$c));
            Lm(b, this.lP);
            this.yb = this.Wj(b.value())
        } else
            this.yb = null
    }
    ;
    _.g = _.Wm.prototype;
    _.g.isDisposed = function() {
        return this.dg
    }
    ;
    _.g.Ga = function() {
        if (!this.isDisposed()) {
            for (var a = _.Ba(Object.values(this.zf)), b = a.next(); !b.done; b = a.next())
                b.value.Ga();
            this.dg = !0
        }
    }
    ;
    _.g.getFrameName = function() {
        return this.Yn
    }
    ;
    _.g.getOrigin = function() {
        return this.zd
    }
    ;
    _.g.getWindow = function() {
        return this.uf
    }
    ;
    _.g.Za = function() {
        return this.uf.document
    }
    ;
    _.g.setGlobalParam = function(a, b) {
        this.kP[a] = b
    }
    ;
    _.g.getGlobalParam = function(a) {
        return this.kP[a]
    }
    ;
    _.g.Wj = function(a) {
        _.Xk(!this.isDisposed(), "Cannot attach iframe in disposed context");
        a = new Km(a);
        a.Gf() || Mm(a, a.getId());
        a.$g() || Nm(a, "..");
        a.getOrigin() || a.Bi(_.pg(a.getUrl()));
        a.getFrameName() || Lm(a, _.yl(a.getId(), this.Yn));
        var b = a.getFrameName();
        if (this.zf[b])
            return this.zf[b];
        var c = a.Gf()
          , d = c;
        a.getOrigin() && (d = c + "|" + a.getOrigin());
        var e = a.$g()
          , f = Nl(a);
        f || (f = (f = a.getIframeEl()) && (f.getAttribute("data-postorigin") || f.src) || a.getUrl(),
        f = _.ve(f, "rpctoken"));
        Om(a, _.Uk(d, e, f, a.O._popupWindow));
        d = ((window.gadgets || {}).rpc || {}).setAuthToken;
        f && d && d(c, f);
        var h = new _.Sm(this,c,b,a)
          , k = a.O.messageHandlersFilter;
        _.am(a.O.messageHandlers, function(l, m) {
            h.register(m, l, k)
        });
        em(a) && h.Cj();
        Vm(h, "_g_rpcReady");
        return h
    }
    ;
    _.g.gF = function(a) {
        Lm(a, null);
        var b = a.getId();
        !b || mm.test(b) && !this.getWindow().document.getElementById(b) || (_.Df.log("Ignoring requested iframe ID - " + b),
        a.Qd(null))
    }
    ;
    var fn = function(a, b) {
        var c = _.ve(a, b);
        c || (c = _.xf(_.ve(a, "jcp", ""))[b]);
        return c || ""
    };
    _.Wm.prototype.openChild = function(a) {
        _.Xk(!this.isDisposed(), "Cannot open iframe in disposed context");
        var b = new Km(a);
        gn(this, b);
        var c = b.getFrameName();
        if (c && this.zf[c])
            return this.zf[c];
        this.gF(b);
        c = b.getUrl();
        _.Xk(c, "No url for new iframe");
        var d = b.O.queryParams || {};
        d.usegapi = "1";
        _.Ol(b, d);
        d = this.LM && this.LM(c, b);
        d || (d = b.O.where,
        _.Xk(!!d, "No location for new iframe"),
        c = _.Il(c, d, a),
        b.O.iframeEl = c,
        d = c.getAttribute("id"));
        Mm(b, d).Qd(d);
        b.Bi(_.pg(b.O.eurl || ""));
        this.lO && this.lO(b, b.getIframeEl());
        c = this.Wj(a);
        c.xG && c.xG(c, a);
        (a = b.O.onCreate) && a(c);
        b.O.disableRelayOpen || c.applyIframesApi("_open");
        return c
    }
    ;
    var hn = function(a, b, c) {
        var d = b.O.canvasUrl;
        if (!d)
            return c;
        _.Xk(!b.O.allowPost && !b.O.forcePost, "Post is not supported when using canvas url");
        var e = b.getUrl();
        _.Xk(e && _.pg(e) === a.zd && _.pg(d) === a.zd, "Wrong origin for canvas or hidden url " + d);
        b.setUrl(d);
        _.Vl(b);
        b.O.canvasUrl = null;
        return function(f) {
            var h = f.getWindow()
              , k = h.location.hash;
            k = _.Hl(e) + (/#/.test(e) ? k.replace(/^#/, "&") : k);
            h.location.replace(k);
            c && c(f)
        }
    }
      , jn = function(a, b, c) {
        var d = b.O.relayOpen;
        if (d) {
            var e = a.getParentIframe();
            d instanceof _.Sm ? (e = d,
            _.Pl(b, 0)) : 0 < Number(d) && _.Pl(b, Number(d) - 1);
            if (e) {
                _.Xk(!!e.eP, "Relaying iframe open is disabled");
                if (d = b.getStyle())
                    if (d = _.$m[d])
                        b.Fp(a),
                        d(b.value()),
                        b.Fp(null);
                b.O.openerIframe = null;
                c.resolve(e.eP(b));
                return !0
            }
        }
        return !1
    }
      , kn = function(a, b, c) {
        var d = b.getStyle();
        if (d)
            if (_.Xk(!!_.bn, "Defer style is disabled, when requesting style " + d),
            _.Zm[d])
                gn(a, b);
            else
                return cn(d, function() {
                    _.Xk(!!_.Zm[d], "Fail to load style - " + d);
                    c.resolve(a.open(b.value()))
                }),
                !0;
        return !1
    };
    _.Wm.prototype.open = function(a, b) {
        _.Xk(!this.isDisposed(), "Cannot open iframe in disposed context");
        var c = new Km(a);
        b = hn(this, c, b);
        var d = new xm(b);
        (b = c.getUrl()) && c.setUrl(_.Hl(b));
        if (jn(this, c, d) || kn(this, c, d) || jn(this, c, d))
            return d.promise;
        if (null != Wl(c)) {
            var e = setTimeout(function() {
                h.getIframeEl().src = "about:blank";
                d.reject({
                    timeout: "Exceeded time limit of :" + Wl(c) + "milliseconds"
                })
            }, Wl(c))
              , f = d.resolve;
            d.resolve = function(k) {
                clearTimeout(e);
                f(k)
            }
        }
        c.O.waitForOnload && Ml(c.Xl(), function() {
            d.resolve(h)
        });
        var h = this.openChild(a);
        c.O.waitForOnload || d.resolve(h);
        return d.promise
    }
    ;
    _.Wm.prototype.getParentIframe = function() {
        return this.yb
    }
    ;
    var ln = function(a, b) {
        var c = a.getParentIframe()
          , d = !0;
        b.filter && (d = b.filter.call(b.Xh, b.params));
        return _.Pj(d).then(function(e) {
            return e && c ? (b.jP && b.jP.call(a, b.params),
            e = b.sender ? b.sender(b.params) : Vm(c, b.message, b.params),
            b.w4 ? e.then(function() {
                return !0
            }) : !0) : !1
        })
    };
    _.g = _.Wm.prototype;
    _.g.closeSelf = function(a, b, c) {
        a = ln(this, {
            sender: function(d) {
                var e = _.hk.getParentIframe();
                _.am(_.hk.zf, function(f) {
                    f !== e && Vm(f, "_g_wasClosed", d)
                });
                return Vm(e, "_g_closeMe", d)
            },
            message: "_g_closeMe",
            params: a,
            Xh: c,
            filter: this.getGlobalParam("onCloseSelfFilter")
        });
        b = new xm(b);
        b.resolve(a);
        return b.promise
    }
    ;
    _.g.restyleSelf = function(a, b, c) {
        a = a || {};
        b = new xm(b);
        b.resolve(ln(this, {
            message: "_g_restyleMe",
            params: a,
            Xh: c,
            filter: this.getGlobalParam("onRestyleSelfFilter"),
            w4: !0,
            jP: this.MR
        }));
        return b.promise
    }
    ;
    _.g.MR = function(a) {
        "auto" === a.height && (a.height = _.Wk())
    }
    ;
    _.g.setCloseSelfFilter = function(a) {
        this.setGlobalParam("onCloseSelfFilter", a)
    }
    ;
    _.g.setRestyleSelfFilter = function(a) {
        this.setGlobalParam("onRestyleSelfFilter", a)
    }
    ;
    var gn = function(a, b) {
        var c = b.getStyle();
        if (c) {
            b.vg(null);
            var d = _.Zm[c];
            _.Xk(d, "No such style: " + c);
            b.Fp(a);
            d(b.value());
            b.Fp(null)
        }
    };
    _.Wm.prototype.ready = function(a, b, c, d) {
        var e = b || {}
          , f = this.getParentIframe();
        this.addOnOpenerHandler(function(k) {
            _.am(e, function(l, m) {
                k.register(m, l, d)
            }, this);
            k !== f && k.send("_ready", h, void 0, d)
        }, void 0, d);
        var h = a || {};
        h.height = h.height || "auto";
        this.MR(h);
        f && f.send("_ready", h, c, _.ik)
    }
    ;
    _.Wm.prototype.connectIframes = function(a, b) {
        a = new Im(a);
        var c = new Im(b)
          , d = em(a);
        b = a.getIframe();
        var e = c.getIframe();
        if (e) {
            var f = Nl(a)
              , h = new Km;
            Pm(b, e, h);
            dm(cm((new Im(h.value())).ql(f), a.O.role), a.O.data).Cj(d);
            var k = new Km;
            Pm(e, b, k);
            dm(cm((new Im(k.value())).ql(f), c.O.role), c.O.data).Cj(!0);
            Vm(b, "_g_connect", h.value(), function() {
                d || Vm(e, "_g_connect", k.value())
            });
            d && Vm(e, "_g_connect", k.value())
        } else
            c = {},
            dm(cm(fm(new Im(c)), a.O.role), a.O.data),
            Vm(b, "_g_connect", c)
    }
    ;
    var Xm = function(a) {
        a.dB || (a.dB = _.re(),
        a.qE = _.re())
    };
    _.Wm.prototype.addOnConnectHandler = function(a, b, c, d) {
        Xm(this);
        "object" === typeof a ? (b = new hm(a),
        c = b.lM() || "") : (b = jm(im(a).qc(b).Cp(c), d),
        c = a);
        d = this.dB[c] || [];
        a = !1;
        for (var e = 0; e < d.length && !a; e++)
            Ym(this.zf[d[e].Xh.getFrameName()], d[e].data, [b]),
            a = b.O.runOnce;
        c = _.pe(this.qE, c, []);
        a || b.O.dontWait || c.push(b)
    }
    ;
    _.Wm.prototype.removeOnConnectHandler = function(a, b) {
        a = _.pe(this.qE, a, []);
        if (b)
            for (var c = 0, d = !1; !d && c < a.length; c++)
                a[c].kb() === b && (d = !0,
                a.splice(c, 1));
        else
            a.splice(0, a.length)
    }
    ;
    var Ym = function(a, b, c) {
        c = c || [];
        for (var d = 0; d < c.length; d++) {
            var e = c[d];
            if (e && a) {
                var f = e.O.filter || _.nm;
                if (a && f(a)) {
                    f = e.O.apis || [];
                    for (var h = 0; h < f.length; h++)
                        a.applyIframesApi(f[h]);
                    e.kb() && e.kb()(a, b);
                    e.O.runOnce && (c.splice(d, 1),
                    --d)
                }
            }
        }
    };
    _.Wm.prototype.addOnOpenerHandler = function(a, b, c) {
        var d = this.addOnConnectHandler;
        a = jm(im("_opener").qc(a).Cp(b), c);
        a.O.runOnce = !0;
        d.call(this, a.value())
    }
    ;
    _.Wm.prototype.lO = function(a, b) {
        var c = a.O.controller;
        if (c) {
            _.Xk(c.zd === a.getOrigin(), "Wrong controller origin " + this.zd + " !== " + a.getOrigin());
            var d = a.Gf();
            Mm(a, c.Gf());
            Nm(a, c.$g());
            var e = new Km;
            Ul(Mm(e, d), a.O.controllerData);
            _.Ae(b, "load", function() {
                c.send("_g_control", e.value())
            })
        }
    }
    ;
    var mn = function(a, b, c) {
        a = a.getWindow();
        var d = a.document
          , e = c.O.reuseWindow;
        if (e) {
            var f = c.getId();
            if (!f)
                throw Error("G");
        } else
            f = _.xl(d, c);
        var h = f
          , k = c.O.rpcRelayUrl;
        if (k) {
            k = _.Gl(k);
            h = c.O.fragmentParams || {};
            h.rly = f;
            c.O.fragmentParams = h;
            h = c.O.where || d.body;
            _.Xk(!!h, "Cannot open window in a page with no body");
            var l = {};
            l.src = k;
            l.style = "display:none;";
            l.id = f;
            l.name = f;
            _.Bl(d, h, l, f);
            h = f + "_relay"
        }
        b = _.Hl(b);
        var m = _.zl(d, b, f, c.value());
        c.O.eurl = m;
        b = c.O.openAsWindow;
        "string" !== typeof b && (b = void 0);
        c = window.navigator.userAgent || "";
        /Trident|MSIE/i.test(c) && /#/.test(c) && (m = "javascript:window.location.replace(" + _.le.JSON.stringify(m).replace(/#/g, "\\x23") + ")");
        if (e) {
            var n = e;
            setTimeout(function() {
                n.location.replace(m)
            })
        } else
            n = _.Md(m, a, h, b);
        return {
            id: f,
            cS: n
        }
    };
    _.Wm.prototype.LM = function(a, b) {
        if (b.O.openAsWindow) {
            a = mn(this, a, b);
            var c = a.id;
            _.Xk(!!a.cS, "Open popup window failed");
            b.O._popupWindow = a.cS
        }
        return c
    }
    ;
    km = _.re();
    lm = _.re();
    _.hk = new _.Wm;
    tm("_g_rpcReady", _.Sm.prototype.Cj);
    tm("_g_discover", _.Sm.prototype.IX);
    tm("_g_ping", _.Sm.prototype.X0);
    tm("_g_close", _.Sm.prototype.vV);
    tm("_g_closeMe", _.Sm.prototype.wV);
    tm("_g_restyle", _.Sm.prototype.V1);
    tm("_g_restyleMe", _.Sm.prototype.W1);
    tm("_g_wasClosed", _.Sm.prototype.x4);
    _.sm("control", "_g_control", _.Sm.prototype.AV);
    _.sm("control", "_g_disposeControl", _.Sm.prototype.OV);
    var nn = _.hk.getParentIframe();
    nn && nn.register("_g_restyleDone", _.Sm.prototype.U1, _.ik);
    tm("_g_connect", _.Sm.prototype.yV);
    var on = {};
    on._g_open = _.Sm.prototype.K0;
    _.rm("_open", on, _.ik);
    var pn = {
        Context: _.Wm,
        Iframe: _.Sm,
        SAME_ORIGIN_IFRAMES_FILTER: _.nm,
        CROSS_ORIGIN_IFRAMES_FILTER: _.ik,
        makeWhiteListIframesFilter: _.om,
        getContext: _.Xl,
        registerIframesApi: _.rm,
        registerIframesApiHandler: _.sm,
        registerStyle: _.an,
        registerBeforeOpenStyle: _.dn,
        getStyle: _.bn,
        getBeforeOpenStyle: _.en,
        create: _.Il
    };
    Dm({
        instance: function() {
            return pn
        },
        priority: 2
    });
    _.sm("gapi.load", "_g_gapi.load", function(a) {
        return new _.Lj(function(b) {
            _.ue.load(a && "object" === typeof a && a.features || "", b)
        }
        )
    });

    _.mg = (window.gapi || {}).load;

    _.qn = _.pe(_.Be, "rw", _.re());

    var rn = function(a, b) {
        (a = _.qn[a]) && a.state < b && (a.state = b)
    };
    var sn = function(a) {
        a = (a = _.qn[a]) ? a.oid : void 0;
        if (a) {
            var b = _.me.getElementById(a);
            b && b.parentNode.removeChild(b);
            delete _.qn[a];
            sn(a)
        }
    };
    _.tn = function(a) {
        a = a.container;
        "string" === typeof a && (a = document.getElementById(a));
        return a
    }
    ;
    _.un = function(a) {
        var b = a.clientWidth;
        return "position:absolute;top:-10000px;width:" + (b ? b + "px" : a.style.width || "300px") + ";margin:0px;border-style:none;"
    }
    ;
    _.vn = function(a, b) {
        var c = {}
          , d = a.$b()
          , e = b && b.width
          , f = b && b.height
          , h = b && b.verticalAlign;
        h && (c.verticalAlign = h);
        e || (e = d.width || a.width);
        f || (f = d.height || a.height);
        d.width = c.width = e;
        d.height = c.height = f;
        d = a.getIframeEl();
        e = a.getId();
        rn(e, 2);
        a: {
            e = a.getSiteEl();
            c = c || {};
            if (_.Be.oa) {
                var k = d.id;
                if (k) {
                    f = (f = _.qn[k]) ? f.state : void 0;
                    if (1 === f || 4 === f)
                        break a;
                    sn(k)
                }
            }
            (f = e.nextSibling) && f.getAttribute && f.getAttribute("data-gapistub") && (e.parentNode.removeChild(f),
            e.style.cssText = "");
            f = c.width;
            h = c.height;
            var l = e.style;
            l.textIndent = "0";
            l.margin = "0";
            l.padding = "0";
            l.background = "transparent";
            l.borderStyle = "none";
            l.cssFloat = "none";
            l.styleFloat = "none";
            l.lineHeight = "normal";
            l.fontSize = "1px";
            l.verticalAlign = "baseline";
            e = e.style;
            e.display = "inline-block";
            d = d.style;
            d.position = "static";
            d.left = "0";
            d.top = "0";
            d.visibility = "visible";
            f && (e.width = d.width = f + "px");
            h && (e.height = d.height = h + "px");
            c.verticalAlign && (e.verticalAlign = c.verticalAlign);
            k && rn(k, 3)
        }
        (k = b ? b.title : null) && a.getIframeEl().setAttribute("title", k);
        (b = b ? b.ariaLabel : null) && a.getIframeEl().setAttribute("aria-label", b)
    }
    ;
    _.wn = function(a) {
        var b = a.getSiteEl();
        b && b.removeChild(a.getIframeEl())
    }
    ;
    _.xn = function(a) {
        a.where = _.tn(a);
        var b = a.messageHandlers = a.messageHandlers || {}
          , c = function(e) {
            _.vn(this, e)
        };
        b._ready = c;
        b._renderstart = c;
        var d = a.onClose;
        a.onClose = function(e) {
            d && d.call(this, e);
            _.wn(this)
        }
        ;
        a.onCreate = function(e) {
            e = e.getIframeEl();
            e.style.cssText = _.un(e)
        }
    }
    ;

    _.Re = function() {
        var a = window.gadgets && window.gadgets.config && window.gadgets.config.get;
        a && _.Le(a());
        return {
            register: function(b, c, d) {
                d && d(_.Ke())
            },
            get: function(b) {
                return _.Ke(b)
            },
            update: function(b, c) {
                if (c)
                    throw "Config replacement is not supported";
                _.Le(b)
            },
            wd: function() {}
        }
    }();
    _.I("gadgets.config.register", _.Re.register);
    _.I("gadgets.config.get", _.Re.get);
    _.I("gadgets.config.init", _.Re.wd);
    _.I("gadgets.config.update", _.Re.update);

    _.I("gadgets.json.stringify", _.yf);
    _.I("gadgets.json.parse", _.xf);

    (function() {
        function a(e, f) {
            if (!(e < c) && d)
                if (2 === e && d.warn)
                    d.warn(f);
                else if (3 === e && d.error)
                    try {
                        d.error(f)
                    } catch (h) {}
                else
                    d.log && d.log(f)
        }
        var b = function(e) {
            a(1, e)
        };
        _.Oe = function(e) {
            a(2, e)
        }
        ;
        _.Pe = function(e) {
            a(3, e)
        }
        ;
        _.Qe = function() {}
        ;
        b.INFO = 1;
        b.WARNING = 2;
        b.NONE = 4;
        var c = 1
          , d = window.console ? window.console : window.opera ? window.opera.postError : void 0;
        return b
    }
    )();

    _.Ne = _.Ne || {};

    _.Ne = _.Ne || {};
    (function() {
        var a = [];
        _.Ne.Cda = function(b) {
            a.push(b)
        }
        ;
        _.Ne.Oda = function() {
            for (var b = 0, c = a.length; b < c; ++b)
                a[b]()
        }
    }
    )();

    _.Ne = _.Ne || {};
    (function() {
        function a(c) {
            var d = "undefined" === typeof c;
            if (null !== b && d)
                return b;
            var e = {};
            c = c || window.location.href;
            var f = c.indexOf("?")
              , h = c.indexOf("#");
            c = (-1 === h ? c.substr(f + 1) : [c.substr(f + 1, h - f - 1), "&", c.substr(h + 1)].join("")).split("&");
            f = window.decodeURIComponent ? decodeURIComponent : unescape;
            h = 0;
            for (var k = c.length; h < k; ++h) {
                var l = c[h].indexOf("=");
                if (-1 !== l) {
                    var m = c[h].substring(0, l);
                    l = c[h].substring(l + 1);
                    l = l.replace(/\+/g, " ");
                    try {
                        e[m] = f(l)
                    } catch (n) {}
                }
            }
            d && (b = e);
            return e
        }
        var b = null;
        _.Ne.jg = a;
        a()
    }
    )();
    _.I("gadgets.util.getUrlParameters", _.Ne.jg);

    _.I("gapi.logutil.enableDebugLogging", _.Df.YK);

    _.Ef = function() {
        var a = _.me.readyState;
        return "complete" === a || "interactive" === a && -1 == navigator.userAgent.indexOf("MSIE")
    }
    ;
    _.Ff = function(a) {
        if (_.Ef())
            a();
        else {
            var b = !1
              , c = function() {
                if (!b)
                    return b = !0,
                    a.apply(this, arguments)
            };
            _.le.addEventListener ? (_.le.addEventListener("load", c, !1),
            _.le.addEventListener("DOMContentLoaded", c, !1)) : _.le.attachEvent && (_.le.attachEvent("onreadystatechange", function() {
                _.Ef() && c.apply(this, arguments)
            }),
            _.le.attachEvent("onload", c))
        }
    }
    ;
    _.Gf = function(a, b) {
        var c = _.pe(_.Be, "watt", _.re());
        _.pe(c, a, b)
    }
    ;
    _.ve(_.le.location.href, "rpctoken") && _.Ae(_.me, "unload", function() {});
    var Hf = Hf || {};
    Hf.ZP = null;
    Hf.CO = null;
    Hf.Gw = null;
    Hf.frameElement = null;
    Hf = Hf || {};
    Hf.hI || (Hf.hI = function() {
        function a(f, h, k) {
            "undefined" != typeof window.addEventListener ? window.addEventListener(f, h, k) : "undefined" != typeof window.attachEvent && window.attachEvent("on" + f, h);
            "message" === f && (window.___jsl = window.___jsl || {},
            f = window.___jsl,
            f.RPMQ = f.RPMQ || [],
            f.RPMQ.push(h))
        }
        function b(f) {
            var h = _.xf(f.data);
            if (h && h.f) {
                _.Qe();
                var k = _.If.hm(h.f);
                e && ("undefined" !== typeof f.origin ? f.origin !== k : f.domain !== /^.+:\/\/([^:]+).*/.exec(k)[1]) ? _.Pe("Invalid rpc message origin. " + k + " vs " + (f.origin || "")) : c(h, f.origin)
            }
        }
        var c, d, e = !0;
        return {
            ML: function() {
                return "wpm"
            },
            j_: function() {
                return !0
            },
            wd: function(f, h) {
                _.Re.register("rpc", null, function(k) {
                    "true" === String((k && k.rpc || {}).disableForceSecure) && (e = !1)
                });
                c = f;
                d = h;
                a("message", b, !1);
                d("..", !0);
                return !0
            },
            Cb: function(f) {
                d(f, !0);
                return !0
            },
            call: function(f, h, k) {
                var l = _.If.hm(f)
                  , m = _.If.iJ(f);
                l ? window.setTimeout(function() {
                    var n = _.yf(k);
                    _.Qe();
                    m.postMessage(n, l)
                }, 0) : ".." != f && _.Pe("No relay set (used as window.postMessage targetOrigin), cannot send cross-domain message");
                return !0
            }
        }
    }());
    if (window.gadgets && window.gadgets.rpc)
        "undefined" != typeof _.If && _.If || (_.If = window.gadgets.rpc,
        _.If.config = _.If.config,
        _.If.register = _.If.register,
        _.If.unregister = _.If.unregister,
        _.If.HP = _.If.registerDefault,
        _.If.LR = _.If.unregisterDefault,
        _.If.zL = _.If.forceParentVerifiable,
        _.If.call = _.If.call,
        _.If.Cr = _.If.getRelayUrl,
        _.If.Di = _.If.setRelayUrl,
        _.If.Xy = _.If.setAuthToken,
        _.If.lt = _.If.setupReceiver,
        _.If.Ul = _.If.getAuthToken,
        _.If.XE = _.If.removeReceiver,
        _.If.iM = _.If.getRelayChannel,
        _.If.FP = _.If.receive,
        _.If.GP = _.If.receiveSameDomain,
        _.If.getOrigin = _.If.getOrigin,
        _.If.hm = _.If.getTargetOrigin,
        _.If.iJ = _.If._getTargetWin,
        _.If.uU = _.If._parseSiblingId);
    else {
        _.If = function() {
            function a(H, X) {
                if (!T[H]) {
                    var Aa = sa;
                    X || (Aa = db);
                    T[H] = Aa;
                    X = M[H] || [];
                    for (var Ia = 0; Ia < X.length; ++Ia) {
                        var ua = X[Ia];
                        ua.t = E[H];
                        Aa.call(H, ua.f, ua)
                    }
                    M[H] = []
                }
            }
            function b() {
                function H() {
                    ma = !0
                }
                da || ("undefined" != typeof window.addEventListener ? window.addEventListener("unload", H, !1) : "undefined" != typeof window.attachEvent && window.attachEvent("onunload", H),
                da = !0)
            }
            function c(H, X, Aa, Ia, ua) {
                E[X] && E[X] === Aa || (_.Pe("Invalid gadgets.rpc token. " + E[X] + " vs " + Aa),
                ra(X, 2));
                ua.onunload = function() {
                    J[X] && !ma && (ra(X, 1),
                    _.If.XE(X))
                }
                ;
                b();
                Ia = _.xf(decodeURIComponent(Ia))
            }
            function d(H, X) {
                if (H && "string" === typeof H.s && "string" === typeof H.f && H.a instanceof Array)
                    if (E[H.f] && E[H.f] !== H.t && (_.Pe("Invalid gadgets.rpc token. " + E[H.f] + " vs " + H.t),
                    ra(H.f, 2)),
                    "__ack" === H.s)
                        window.setTimeout(function() {
                            a(H.f, !0)
                        }, 0);
                    else {
                        H.c && (H.callback = function(wa) {
                            _.If.call(H.f, (H.g ? "legacy__" : "") + "__cb", null, H.c, wa)
                        }
                        );
                        if (X) {
                            var Aa = e(X);
                            H.origin = X;
                            var Ia = H.r;
                            try {
                                var ua = e(Ia)
                            } catch (wa) {}
                            Ia && ua == Aa || (Ia = X);
                            H.referer = Ia
                        }
                        X = (u[H.s] || u[""]).apply(H, H.a);
                        H.c && "undefined" !== typeof X && _.If.call(H.f, "__cb", null, H.c, X)
                    }
            }
            function e(H) {
                if (!H)
                    return "";
                H = H.split("#")[0].split("?")[0];
                H = H.toLowerCase();
                0 == H.indexOf("//") && (H = window.location.protocol + H);
                -1 == H.indexOf("://") && (H = window.location.protocol + "//" + H);
                var X = H.substring(H.indexOf("://") + 3)
                  , Aa = X.indexOf("/");
                -1 != Aa && (X = X.substring(0, Aa));
                H = H.substring(0, H.indexOf("://"));
                if ("http" !== H && "https" !== H && "chrome-extension" !== H && "file" !== H && "android-app" !== H && "chrome-search" !== H && "chrome-untrusted" !== H && "chrome" !== H && "devtools" !== H)
                    throw Error("n");
                Aa = "";
                var Ia = X.indexOf(":");
                if (-1 != Ia) {
                    var ua = X.substring(Ia + 1);
                    X = X.substring(0, Ia);
                    if ("http" === H && "80" !== ua || "https" === H && "443" !== ua)
                        Aa = ":" + ua
                }
                return H + "://" + X + Aa
            }
            function f(H) {
                if ("/" == H.charAt(0)) {
                    var X = H.indexOf("|");
                    return {
                        id: 0 < X ? H.substring(1, X) : H.substring(1),
                        origin: 0 < X ? H.substring(X + 1) : null
                    }
                }
                return null
            }
            function h(H) {
                if ("undefined" === typeof H || ".." === H)
                    return window.parent;
                var X = f(H);
                if (X)
                    return window.top.frames[X.id];
                H = String(H);
                return (X = window.frames[H]) ? X : (X = document.getElementById(H)) && X.contentWindow ? X.contentWindow : null
            }
            function k(H, X) {
                if (!0 !== J[H]) {
                    "undefined" === typeof J[H] && (J[H] = 0);
                    var Aa = h(H);
                    ".." !== H && null == Aa || !0 !== sa.Cb(H, X) ? !0 !== J[H] && 10 > J[H]++ ? window.setTimeout(function() {
                        k(H, X)
                    }, 500) : (T[H] = db,
                    J[H] = !0) : J[H] = !0
                }
            }
            function l(H) {
                (H = w[H]) && "/" === H.substring(0, 1) && (H = "/" === H.substring(1, 2) ? document.location.protocol + H : document.location.protocol + "//" + document.location.host + H);
                return H
            }
            function m(H, X, Aa) {
                X && !/http(s)?:\/\/.+/.test(X) && (0 == X.indexOf("//") ? X = window.location.protocol + X : "/" == X.charAt(0) ? X = window.location.protocol + "//" + window.location.host + X : -1 == X.indexOf("://") && (X = window.location.protocol + "//" + X));
                w[H] = X;
                "undefined" !== typeof Aa && (z[H] = !!Aa)
            }
            function n(H, X) {
                X = X || "";
                E[H] = String(X);
                k(H, X)
            }
            function q(H) {
                H = (H.passReferrer || "").split(":", 2);
                L = H[0] || "none";
                V = H[1] || "origin"
            }
            function p(H) {
                "true" === String(H.useLegacyProtocol) && (sa = Hf.Gw || db,
                sa.wd(d, a))
            }
            function t(H, X) {
                function Aa(Ia) {
                    Ia = Ia && Ia.rpc || {};
                    q(Ia);
                    var ua = Ia.parentRelayUrl || "";
                    ua = e(Q.parent || X) + ua;
                    m("..", ua, "true" === String(Ia.useLegacyProtocol));
                    p(Ia);
                    n("..", H)
                }
                !Q.parent && X ? Aa({}) : _.Re.register("rpc", null, Aa)
            }
            function v(H, X, Aa) {
                if (".." === H)
                    t(Aa || Q.rpctoken || Q.ifpctok || "", X);
                else
                    a: {
                        var Ia = null;
                        if ("/" != H.charAt(0)) {
                            if (!_.Ne)
                                break a;
                            Ia = document.getElementById(H);
                            if (!Ia)
                                throw Error("o`" + H);
                        }
                        Ia = Ia && Ia.src;
                        X = X || e(Ia);
                        m(H, X);
                        X = _.Ne.jg(Ia);
                        n(H, Aa || X.rpctoken)
                    }
            }
            var u = {}
              , w = {}
              , z = {}
              , E = {}
              , A = 0
              , y = {}
              , J = {}
              , Q = {}
              , T = {}
              , M = {}
              , L = null
              , V = null
              , oa = window.top !== window.self
              , ia = window.name
              , ra = function() {}
              , Ka = window.console
              , Ga = Ka && Ka.log && function(H) {
                Ka.log(H)
            }
            || function() {}
              , db = function() {
                function H(X) {
                    return function() {
                        Ga(X + ": call ignored")
                    }
                }
                return {
                    ML: function() {
                        return "noop"
                    },
                    j_: function() {
                        return !0
                    },
                    wd: H("init"),
                    Cb: H("setup"),
                    call: H("call")
                }
            }();
            _.Ne && (Q = _.Ne.jg());
            var ma = !1
              , da = !1
              , sa = function() {
                if ("rmr" == Q.rpctx)
                    return Hf.ZP;
                var H = "function" === typeof window.postMessage ? Hf.hI : "object" === typeof window.postMessage ? Hf.hI : window.ActiveXObject ? Hf.CO ? Hf.CO : Hf.Gw : 0 < navigator.userAgent.indexOf("WebKit") ? Hf.ZP : "Gecko" === navigator.product ? Hf.frameElement : Hf.Gw;
                H || (H = db);
                return H
            }();
            u[""] = function() {
                Ga("Unknown RPC service: " + this.s)
            }
            ;
            u.__cb = function(H, X) {
                var Aa = y[H];
                Aa && (delete y[H],
                Aa.call(this, X))
            }
            ;
            return {
                config: function(H) {
                    "function" === typeof H.fQ && (ra = H.fQ)
                },
                register: function(H, X) {
                    if ("__cb" === H || "__ack" === H)
                        throw Error("p");
                    if ("" === H)
                        throw Error("q");
                    u[H] = X
                },
                unregister: function(H) {
                    if ("__cb" === H || "__ack" === H)
                        throw Error("r");
                    if ("" === H)
                        throw Error("s");
                    delete u[H]
                },
                HP: function(H) {
                    u[""] = H
                },
                LR: function() {
                    delete u[""]
                },
                zL: function() {},
                call: function(H, X, Aa, Ia) {
                    H = H || "..";
                    var ua = "..";
                    ".." === H ? ua = ia : "/" == H.charAt(0) && (ua = e(window.location.href),
                    ua = "/" + ia + (ua ? "|" + ua : ""));
                    ++A;
                    Aa && (y[A] = Aa);
                    var wa = {
                        s: X,
                        f: ua,
                        c: Aa ? A : 0,
                        a: Array.prototype.slice.call(arguments, 3),
                        t: E[H],
                        l: !!z[H]
                    };
                    a: if ("bidir" === L || "c2p" === L && ".." === H || "p2c" === L && ".." !== H) {
                        var Pa = window.location.href;
                        var P = "?";
                        if ("query" === V)
                            P = "#";
                        else if ("hash" === V)
                            break a;
                        P = Pa.lastIndexOf(P);
                        P = -1 === P ? Pa.length : P;
                        Pa = Pa.substring(0, P)
                    } else
                        Pa = null;
                    Pa && (wa.r = Pa);
                    if (".." === H || null != f(H) || document.getElementById(H))
                        (Pa = T[H]) || null === f(H) || (Pa = sa),
                        0 === X.indexOf("legacy__") && (Pa = sa,
                        wa.s = X.substring(8),
                        wa.c = wa.c ? wa.c : A),
                        wa.g = !0,
                        wa.r = ua,
                        Pa ? (z[H] && (Pa = Hf.Gw),
                        !1 === Pa.call(H, ua, wa) && (T[H] = db,
                        sa.call(H, ua, wa))) : M[H] ? M[H].push(wa) : M[H] = [wa]
                },
                Cr: l,
                Di: m,
                Xy: n,
                lt: v,
                Ul: function(H) {
                    return E[H]
                },
                XE: function(H) {
                    delete w[H];
                    delete z[H];
                    delete E[H];
                    delete J[H];
                    delete T[H]
                },
                iM: function() {
                    return sa.ML()
                },
                FP: function(H, X) {
                    4 < H.length ? sa.hba(H, d) : c.apply(null, H.concat(X))
                },
                GP: function(H) {
                    H.a = Array.prototype.slice.call(H.a);
                    window.setTimeout(function() {
                        d(H)
                    }, 0)
                },
                getOrigin: e,
                hm: function(H) {
                    var X = null
                      , Aa = l(H);
                    Aa ? X = Aa : (Aa = f(H)) ? X = Aa.origin : ".." == H ? X = Q.parent : (H = document.getElementById(H)) && "iframe" === H.tagName.toLowerCase() && (X = H.src);
                    return e(X)
                },
                wd: function() {
                    !1 === sa.wd(d, a) && (sa = db);
                    oa ? v("..") : _.Re.register("rpc", null, function(H) {
                        H = H.rpc || {};
                        q(H);
                        p(H)
                    })
                },
                iJ: h,
                uU: f,
                K4: "__ack",
                Q9: ia || "..",
                a$: 0,
                Z9: 1,
                Y9: 2
            }
        }();
        _.If.wd()
    }
    ;_.If.config({
        fQ: function(a) {
            throw Error("t`" + a);
        }
    });
    _.I("gadgets.rpc.config", _.If.config);
    _.I("gadgets.rpc.register", _.If.register);
    _.I("gadgets.rpc.unregister", _.If.unregister);
    _.I("gadgets.rpc.registerDefault", _.If.HP);
    _.I("gadgets.rpc.unregisterDefault", _.If.LR);
    _.I("gadgets.rpc.forceParentVerifiable", _.If.zL);
    _.I("gadgets.rpc.call", _.If.call);
    _.I("gadgets.rpc.getRelayUrl", _.If.Cr);
    _.I("gadgets.rpc.setRelayUrl", _.If.Di);
    _.I("gadgets.rpc.setAuthToken", _.If.Xy);
    _.I("gadgets.rpc.setupReceiver", _.If.lt);
    _.I("gadgets.rpc.getAuthToken", _.If.Ul);
    _.I("gadgets.rpc.removeReceiver", _.If.XE);
    _.I("gadgets.rpc.getRelayChannel", _.If.iM);
    _.I("gadgets.rpc.receive", _.If.FP);
    _.I("gadgets.rpc.receiveSameDomain", _.If.GP);
    _.I("gadgets.rpc.getOrigin", _.If.getOrigin);
    _.I("gadgets.rpc.getTargetOrigin", _.If.hm);

    _.mi = function(a) {
        var b = window;
        a = (a || b.location.href).match(RegExp(".*(\\?|#|&)usegapi=([^&#]+)")) || [];
        return "1" === decodeURIComponent(a[a.length - 1] || "")
    }
    ;

    _.yn = _.re();

    _.zn = {};
    window.iframer = _.zn;

    var An, Bn, Cn, Dn, En, Fn, Gn, Kn, Ln;
    An = function(a) {
        return this.hb.WB(a)
    }
    ;
    Bn = function(a) {
        if (_.oe.test(Object.keys))
            return Object.keys(a);
        var b = [], c;
        for (c in a)
            _.se(a, c) && b.push(c);
        return b
    }
    ;
    Cn = function(a, b) {
        if (!_.Ef())
            try {
                a()
            } catch (c) {}
        _.Ff(b)
    }
    ;
    Dn = {
        button: !0,
        div: !0,
        span: !0
    };
    En = function(a) {
        var b = _.pe(_.Be, "sws", []);
        return 0 <= _.Zl.call(b, a)
    }
    ;
    Fn = function(a) {
        return _.pe(_.Be, "watt", _.re())[a]
    }
    ;
    Gn = function(a) {
        return function(b, c) {
            return a ? _.El()[c] || a[c] || "" : _.El()[c] || ""
        }
    }
    ;
    _.Hn = {
        callback: 1,
        clientid: 1,
        cookiepolicy: 1,
        openidrealm: -1,
        includegrantedscopes: -1,
        requestvisibleactions: 1,
        scope: 1
    };
    _.In = !1;
    _.Jn = function() {
        if (!_.In) {
            for (var a = document.getElementsByTagName("meta"), b = 0; b < a.length; ++b) {
                var c = a[b].name.toLowerCase();
                if (_.mc(c, "google-signin-")) {
                    c = c.substring(14);
                    var d = a[b].content;
                    _.Hn[c] && d && (_.yn[c] = d)
                }
            }
            if (window.self !== window.top) {
                a = document.location.toString();
                for (var e in _.Hn)
                    0 < _.Hn[e] && (b = _.ve(a, e, "")) && (_.yn[e] = b)
            }
            _.In = !0
        }
        e = _.re();
        _.te(_.yn, e);
        return e
    }
    ;
    Kn = function(a) {
        var b;
        a.match(/^https?%3A/i) && (b = decodeURIComponent(a));
        return _.kl(document, b ? b : a)
    }
    ;
    Ln = function(a) {
        a = a || "canonical";
        for (var b = document.getElementsByTagName("link"), c = 0, d = b.length; c < d; c++) {
            var e = b[c]
              , f = e.getAttribute("rel");
            if (f && f.toLowerCase() == a && (e = e.getAttribute("href")) && (e = Kn(e)) && null != e.match(/^https?:\/\/[\w\-_\.]+/i))
                return e
        }
        return window.location.href
    }
    ;
    _.Mn = function() {
        return window.location.origin || window.location.protocol + "//" + window.location.host
    }
    ;
    _.Nn = function(a, b, c, d) {
        return (a = "string" == typeof a ? a : void 0) ? Kn(a) : Ln(d)
    }
    ;
    _.On = function(a, b, c) {
        null == a && c && (a = c.db,
        null == a && (a = c.gwidget && c.gwidget.db));
        return a || void 0
    }
    ;
    _.Pn = function(a, b, c) {
        null == a && c && (a = c.ecp,
        null == a && (a = c.gwidget && c.gwidget.ecp));
        return a || void 0
    }
    ;
    _.Qn = function(a, b, c) {
        return _.Nn(a, b, c, b.action ? void 0 : "publisher")
    }
    ;
    var Rn, Sn, Tn, Un, Vn, Wn, Yn, Xn;
    Rn = {
        se: "0"
    };
    Sn = {
        post: !0
    };
    Tn = {
        style: "position:absolute;top:-10000px;width:450px;margin:0px;border-style:none"
    };
    Un = "onPlusOne _ready _close _open _resizeMe _renderstart oncircled drefresh erefresh".split(" ");
    Vn = _.pe(_.Be, "WI", _.re());
    Wn = ["style", "data-gapiscan"];
    Yn = function(a) {
        for (var b = _.re(), c = 0 != a.nodeName.toLowerCase().indexOf("g:"), d = 0, e = a.attributes.length; d < e; d++) {
            var f = a.attributes[d]
              , h = f.name
              , k = f.value;
            0 <= _.Zl.call(Wn, h) || c && 0 != h.indexOf("data-") || "null" === k || "specified"in f && !f.specified || (c && (h = h.substr(5)),
            b[h.toLowerCase()] = k)
        }
        a = a.style;
        (c = Xn(a && a.height)) && (b.height = String(c));
        (a = Xn(a && a.width)) && (b.width = String(a));
        return b
    }
    ;
    _.$n = function(a, b, c, d, e, f) {
        if (c.rd)
            var h = b;
        else
            h = document.createElement("div"),
            b.setAttribute("data-gapistub", !0),
            h.style.cssText = "position:absolute;width:450px;left:-10000px;",
            b.parentNode.insertBefore(h, b);
        f.siteElement = h;
        h.id || (h.id = _.Zn(a));
        b = _.re();
        b[">type"] = a;
        _.te(c, b);
        a = _.Il(d, h, e);
        f.iframeNode = a;
        f.id = a.getAttribute("id")
    }
    ;
    _.Zn = function(a) {
        _.pe(Vn, a, 0);
        return "___" + a + "_" + Vn[a]++
    }
    ;
    Xn = function(a) {
        var b = void 0;
        "number" === typeof a ? b = a : "string" === typeof a && (b = parseInt(a, 10));
        return b
    }
    ;
    var ao = function() {}
      , fo = function(a) {
        var b = a.Qn
          , c = function(l) {
            c.H.constructor.call(this, l);
            var m = this.Hh.length;
            this.Qg = [];
            for (var n = 0; n < m; ++n)
                this.Hh[n].Jba || (this.Qg[n] = new this.Hh[n](l))
        };
        _.$a(c, b);
        for (var d = []; a && a !== Object; ) {
            if (b = a.Qn) {
                b.Hh && (_.jj(d, b.Hh),
                _.kj(d));
                var e = b.prototype, f;
                for (f in e)
                    if (e.hasOwnProperty(f) && "function" === typeof e[f] && e[f] !== b) {
                        var h = !!e[f].sba
                          , k = bo(f, e, d, h);
                        (h = co(f, e, k, h)) && (c.prototype[f] = h)
                    }
            }
            a = eo(a)
        }
        c.prototype.Hh = d;
        return c
    }
      , eo = function(a) {
        return a === Object ? Object : Object.getPrototypeOf ? Object.getPrototypeOf(a.prototype).constructor || Object : a.H && a.H.constructor || Object
    }
      , bo = function(a, b, c, d) {
        for (var e = [], f = 0; f < c.length && (c[f].prototype[a] === b[a] || (e.push(f),
        !d)); ++f)
            ;
        return e
    }
      , co = function(a, b, c, d) {
        return c.length ? d ? function(e) {
            var f = this.Qg[c[0]];
            return f ? f[a].apply(this.Qg[c[0]], arguments) : this.Hh[c[0]].prototype[a].apply(this, arguments)
        }
        : b[a].$U ? function(e) {
            a: {
                var f = Array.prototype.slice.call(arguments, 0);
                for (var h = 0; h < c.length; ++h) {
                    var k = this.Qg[c[h]];
                    if (k = k ? k[a].apply(k, f) : this.Hh[c[h]].prototype[a].apply(this, f)) {
                        f = k;
                        break a
                    }
                }
                f = !1
            }
            return f
        }
        : b[a].ZU ? function(e) {
            a: {
                var f = Array.prototype.slice.call(arguments, 0);
                for (var h = 0; h < c.length; ++h) {
                    var k = this.Qg[c[h]];
                    k = k ? k[a].apply(k, f) : this.Hh[c[h]].prototype[a].apply(this, f);
                    if (null != k) {
                        f = k;
                        break a
                    }
                }
                f = void 0
            }
            return f
        }
        : b[a].EO ? function(e) {
            for (var f = Array.prototype.slice.call(arguments, 0), h = 0; h < c.length; ++h) {
                var k = this.Qg[c[h]];
                k ? k[a].apply(k, f) : this.Hh[c[h]].prototype[a].apply(this, f)
            }
        }
        : function(e) {
            return this.ve(a, c, Array.prototype.slice.call(arguments, 0))
        }
        : d || b[a].$U || b[a].ZU || b[a].EO ? null : go
    }
      , go = function() {
        return []
    };
    ao.prototype.ve = function(a, b, c) {
        for (var d = [], e = 0; e < b.length; ++e) {
            var f = this.Qg[b[e]];
            d.push(f ? f[a].apply(f, c) : this.Hh[b[e]].prototype[a].apply(this, c))
        }
        return d
    }
    ;
    ao.prototype.WB = function(a) {
        if (this.Qg)
            for (var b = 0; b < this.Qg.length; ++b)
                if (this.Qg[b]instanceof a)
                    return this.Qg[b];
        return null
    }
    ;
    var ho, io, jo, ko, lo = /(?:^|\s)g-((\S)*)(?:$|\s)/, mo = {
        plusone: !0,
        autocomplete: !0,
        profile: !0,
        signin: !0,
        signin2: !0
    };
    ho = _.pe(_.Be, "SW", _.re());
    io = _.pe(_.Be, "SA", _.re());
    jo = _.pe(_.Be, "SM", _.re());
    ko = _.pe(_.Be, "FW", []);
    var no = function(a, b) {
        return ("string" === typeof a ? document.getElementById(a) : a) || b
    }
      , ro = function(a, b) {
        var c;
        oo.ps0 = (new Date).getTime();
        po("ps0");
        a = no(a, _.me);
        var d = _.me.documentMode;
        if (a.querySelectorAll && (!d || 8 < d)) {
            d = b ? [b] : Bn(ho).concat(Bn(io)).concat(Bn(jo));
            for (var e = [], f = 0; f < d.length; f++) {
                var h = d[f];
                e.push(".g-" + h, "g\\:" + h)
            }
            d = a.querySelectorAll(e.join(","))
        } else
            d = a.getElementsByTagName("*");
        a = _.re();
        for (e = 0; e < d.length; e++) {
            f = d[e];
            var k = f;
            h = b;
            var l = k.nodeName.toLowerCase()
              , m = void 0;
            if (k.getAttribute("data-gapiscan"))
                h = null;
            else {
                var n = l.indexOf("g:");
                0 == n ? m = l.substr(2) : (n = (n = String(k.className || k.getAttribute("class"))) && lo.exec(n)) && (m = n[1]);
                h = !m || !(ho[m] || io[m] || jo[m]) || h && m !== h ? null : m
            }
            h && (mo[h] || 0 == f.nodeName.toLowerCase().indexOf("g:") || 0 != Bn(Yn(f)).length) && (f.setAttribute("data-gapiscan", !0),
            _.pe(a, h, []).push(f))
        }
        for (q in a)
            ko.push(q);
        oo.ps1 = (new Date).getTime();
        po("ps1");
        if (b = ko.join(":"))
            try {
                _.ue.load(b, void 0)
            } catch (p) {
                _.Df.log(p);
                return
            }
        e = [];
        for (c in a) {
            d = a[c];
            var q = 0;
            for (b = d.length; q < b; q++)
                f = d[q],
                qo(c, f, Yn(f), e, b)
        }
    };
    var so = function(a, b) {
        var c = Fn(a);
        b && c ? (c(b),
        (c = b.iframeNode) && c.setAttribute("data-gapiattached", !0)) : _.ue.load(a, function() {
            var d = Fn(a)
              , e = b && b.iframeNode
              , f = b && b.userParams;
            e && d ? (d(b),
            e.setAttribute("data-gapiattached", !0)) : (d = _.ue[a].go,
            "signin2" == a ? d(e, f) : d(e && e.parentNode, f))
        })
    }
      , qo = function(a, b, c, d, e, f, h) {
        switch (to(b, a, f)) {
        case 0:
            a = jo[a] ? a + "_annotation" : a;
            d = {};
            d.iframeNode = b;
            d.userParams = c;
            so(a, d);
            break;
        case 1:
            if (b.parentNode) {
                for (var k in c) {
                    if (f = _.se(c, k))
                        f = c[k],
                        f = !!f && "object" === typeof f && (!f.toString || f.toString === Object.prototype.toString || f.toString === Array.prototype.toString);
                    if (f)
                        try {
                            c[k] = _.yf(c[k])
                        } catch (w) {
                            delete c[k]
                        }
                }
                k = !0;
                c.dontclear && (k = !1);
                delete c.dontclear;
                var l;
                f = {};
                var m = l = a;
                "plus" == a && c.action && (l = a + "_" + c.action,
                m = a + "/" + c.action);
                (l = _.Ke("iframes/" + l + "/url")) || (l = ":im_socialhost:/:session_prefix::im_prefix:_/widget/render/" + m + "?usegapi=1");
                for (n in Rn)
                    f[n] = n + "/" + (c[n] || Rn[n]) + "/";
                var n = _.kl(_.me, l.replace(_.Dl, Gn(f)));
                m = "iframes/" + a + "/params/";
                f = {};
                _.te(c, f);
                (l = _.Ke("lang") || _.Ke("gwidget/lang")) && (f.hl = l);
                Sn[a] || (f.origin = _.Mn());
                f.exp = _.Ke(m + "exp");
                if (m = _.Ke(m + "location"))
                    for (l = 0; l < m.length; l++) {
                        var q = m[l];
                        f[q] = _.le.location[q]
                    }
                switch (a) {
                case "plus":
                case "follow":
                    f.url = _.Qn(f.href, c, null);
                    delete f.href;
                    break;
                case "plusone":
                    m = (m = c.href) ? Kn(m) : Ln();
                    f.url = m;
                    f.db = _.On(c.db, void 0, _.Ke());
                    f.ecp = _.Pn(c.ecp, void 0, _.Ke());
                    delete f.href;
                    break;
                case "signin":
                    f.url = Ln()
                }
                _.Be.ILI && (f.iloader = "1");
                delete f["data-onload"];
                delete f.rd;
                for (var p in Rn)
                    f[p] && delete f[p];
                f.gsrc = _.Ke("iframes/:source:");
                p = _.Ke("inline/css");
                "undefined" !== typeof p && 0 < e && p >= e && (f.ic = "1");
                p = /^#|^fr-/;
                e = {};
                for (var t in f)
                    _.se(f, t) && p.test(t) && (e[t.replace(p, "")] = f[t],
                    delete f[t]);
                t = "q" == _.Ke("iframes/" + a + "/params/si") ? f : e;
                p = _.Jn();
                for (var v in p)
                    !_.se(p, v) || _.se(f, v) || _.se(e, v) || (t[v] = p[v]);
                v = [].concat(Un);
                t = _.Ke("iframes/" + a + "/methods");
                _.Yl(t) && (v = v.concat(t));
                for (u in c)
                    _.se(c, u) && /^on/.test(u) && ("plus" != a || "onconnect" != u) && (v.push(u),
                    delete f[u]);
                delete f.callback;
                e._methods = v.join(",");
                var u = _.jl(n, f, e);
                v = h || {};
                v.allowPost = 1;
                v.attributes = Tn;
                v.dontclear = !k;
                h = {};
                h.userParams = c;
                h.url = u;
                h.type = a;
                _.$n(a, b, c, u, v, h);
                b = h.id;
                c = _.re();
                c.id = b;
                c.userParams = h.userParams;
                c.url = h.url;
                c.type = h.type;
                c.state = 1;
                _.qn[b] = c;
                b = h
            } else
                b = null;
            b && ((c = b.id) && d.push(c),
            so(a, b))
        }
    }
      , to = function(a, b, c) {
        if (a && 1 === a.nodeType && b) {
            if (c)
                return 1;
            if (jo[b]) {
                if (Dn[a.nodeName.toLowerCase()])
                    return (a = a.innerHTML) && a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") ? 0 : 1
            } else {
                if (io[b])
                    return 0;
                if (ho[b])
                    return 1
            }
        }
        return null
    };
    _.pe(_.ue, "platform", {}).go = function(a, b) {
        ro(a, b)
    }
    ;
    var uo = _.pe(_.Be, "perf", _.re()), oo = _.pe(uo, "g", _.re()), vo = _.pe(uo, "i", _.re()), wo, xo, yo, po, Ao, Bo, Co;
    _.pe(uo, "r", []);
    wo = _.re();
    xo = _.re();
    yo = function(a, b, c, d) {
        wo[c] = wo[c] || !!d;
        _.pe(xo, c, []);
        xo[c].push([a, b])
    }
    ;
    po = function(a, b, c) {
        var d = uo.r;
        "function" === typeof d ? d(a, b, c) : d.push([a, b, c])
    }
    ;
    Ao = function(a, b, c, d) {
        if ("_p" == b)
            throw Error("H");
        _.zo(a, b, c, d)
    }
    ;
    _.zo = function(a, b, c, d) {
        Bo(b, c)[a] = d || (new Date).getTime();
        po(a, b, c)
    }
    ;
    Bo = function(a, b) {
        a = _.pe(vo, a, _.re());
        return _.pe(a, b, _.re())
    }
    ;
    Co = function(a, b, c) {
        var d = null;
        b && c && (d = Bo(b, c)[a]);
        return d || oo[a]
    }
    ;
    (function() {
        function a(h) {
            this.t = {};
            this.tick = function(k, l, m) {
                this.t[k] = [void 0 != m ? m : (new Date).getTime(), l];
                if (void 0 == m)
                    try {
                        window.console.timeStamp("CSI/" + k)
                    } catch (n) {}
            }
            ;
            this.getStartTickTime = function() {
                return this.t.start[0]
            }
            ;
            this.tick("start", null, h)
        }
        var b;
        if (window.performance)
            var c = (b = window.performance.timing) && b.responseStart;
        var d = 0 < c ? new a(c) : new a;
        window.__gapi_jstiming__ = {
            Timer: a,
            load: d
        };
        if (b) {
            var e = b.navigationStart;
            0 < e && c >= e && (window.__gapi_jstiming__.srt = c - e)
        }
        if (b) {
            var f = window.__gapi_jstiming__.load;
            0 < e && c >= e && (f.tick("_wtsrt", void 0, e),
            f.tick("wtsrt_", "_wtsrt", c),
            f.tick("tbsd_", "wtsrt_"))
        }
        try {
            b = null,
            window.chrome && window.chrome.csi && (b = Math.floor(window.chrome.csi().pageT),
            f && 0 < e && (f.tick("_tbnd", void 0, window.chrome.csi().startE),
            f.tick("tbnd_", "_tbnd", e))),
            null == b && window.gtbExternal && (b = window.gtbExternal.pageT()),
            null == b && window.external && (b = window.external.pageT,
            f && 0 < e && (f.tick("_tbnd", void 0, window.external.startE),
            f.tick("tbnd_", "_tbnd", e))),
            b && (window.__gapi_jstiming__.pt = b)
        } catch (h) {}
    }
    )();
    if (window.__gapi_jstiming__) {
        window.__gapi_jstiming__.JJ = {};
        window.__gapi_jstiming__.E1 = 1;
        var Do = function(a, b, c) {
            var d = a.t[b]
              , e = a.t.start;
            if (d && (e || c))
                return d = a.t[b][0],
                e = void 0 != c ? c : e[0],
                Math.round(d - e)
        }
          , Eo = function(a, b, c) {
            var d = "";
            window.__gapi_jstiming__.srt && (d += "&srt=" + window.__gapi_jstiming__.srt,
            delete window.__gapi_jstiming__.srt);
            window.__gapi_jstiming__.pt && (d += "&tbsrt=" + window.__gapi_jstiming__.pt,
            delete window.__gapi_jstiming__.pt);
            try {
                window.external && window.external.tran ? d += "&tran=" + window.external.tran : window.gtbExternal && window.gtbExternal.tran ? d += "&tran=" + window.gtbExternal.tran() : window.chrome && window.chrome.csi && (d += "&tran=" + window.chrome.csi().tran)
            } catch (q) {}
            var e = window.chrome;
            if (e && (e = e.loadTimes)) {
                e().wasFetchedViaSpdy && (d += "&p=s");
                if (e().wasNpnNegotiated) {
                    d += "&npn=1";
                    var f = e().npnNegotiatedProtocol;
                    f && (d += "&npnv=" + (encodeURIComponent || escape)(f))
                }
                e().wasAlternateProtocolAvailable && (d += "&apa=1")
            }
            var h = a.t
              , k = h.start;
            e = [];
            f = [];
            for (var l in h)
                if ("start" != l && 0 != l.indexOf("_")) {
                    var m = h[l][1];
                    m ? h[m] && f.push(l + "." + Do(a, l, h[m][0])) : k && e.push(l + "." + Do(a, l))
                }
            delete h.start;
            if (b)
                for (var n in b)
                    d += "&" + n + "=" + b[n];
            (b = c) || (b = "https:" == document.location.protocol ? "https://csi.gstatic.com/csi" : "http://csi.gstatic.com/csi");
            return [b, "?v=3", "&s=" + (window.__gapi_jstiming__.sn || "gwidget") + "&action=", a.name, f.length ? "&it=" + f.join(",") : "", d, "&rt=", e.join(",")].join("")
        }
          , Fo = function(a, b, c) {
            a = Eo(a, b, c);
            if (!a)
                return "";
            b = new Image;
            var d = window.__gapi_jstiming__.E1++;
            window.__gapi_jstiming__.JJ[d] = b;
            b.onload = b.onerror = function() {
                window.__gapi_jstiming__ && delete window.__gapi_jstiming__.JJ[d]
            }
            ;
            b.src = a;
            b = null;
            return a
        };
        window.__gapi_jstiming__.report = function(a, b, c) {
            var d = document.visibilityState
              , e = "visibilitychange";
            d || (d = document.webkitVisibilityState,
            e = "webkitvisibilitychange");
            if ("prerender" == d) {
                var f = !1
                  , h = function() {
                    if (!f) {
                        b ? b.prerender = "1" : b = {
                            prerender: "1"
                        };
                        if ("prerender" == (document.visibilityState || document.webkitVisibilityState))
                            var k = !1;
                        else
                            Fo(a, b, c),
                            k = !0;
                        k && (f = !0,
                        document.removeEventListener(e, h, !1))
                    }
                };
                document.addEventListener(e, h, !1);
                return ""
            }
            return Fo(a, b, c)
        }
    }
    ;var Go = {
        g: "gapi_global",
        m: "gapi_module",
        w: "gwidget"
    }
      , Ho = function(a, b) {
        this.type = a ? "_p" == a ? "m" : "w" : "g";
        this.name = a;
        this.Sp = b
    };
    Ho.prototype.key = function() {
        switch (this.type) {
        case "g":
            return this.type;
        case "m":
            return this.type + "." + this.Sp;
        case "w":
            return this.type + "." + this.name + this.Sp
        }
    }
    ;
    var Io = new Ho
      , Jo = navigator.userAgent.match(/iPhone|iPad|Android|PalmWebOS|Maemo|Bada/)
      , Ko = _.pe(uo, "_c", _.re())
      , Lo = Math.random() < (_.Ke("csi/rate") || 0)
      , No = function(a, b, c) {
        for (var d = new Ho(b,c), e = _.pe(Ko, d.key(), _.re()), f = xo[a] || [], h = 0; h < f.length; ++h) {
            var k = f[h]
              , l = k[0]
              , m = a
              , n = b
              , q = c;
            k = Co(k[1], n, q);
            m = Co(m, n, q);
            e[l] = k && m ? m - k : null
        }
        wo[a] && Lo && (Mo(Io),
        Mo(d))
    }
      , Oo = function(a, b) {
        b = b || [];
        for (var c = [], d = 0; d < b.length; d++)
            c.push(a + b[d]);
        return c
    }
      , Mo = function(a) {
        var b = _.le.__gapi_jstiming__;
        b.sn = Go[a.type];
        var c = new b.Timer(0);
        a: {
            switch (a.type) {
            case "g":
                var d = "global";
                break a;
            case "m":
                d = a.Sp;
                break a;
            case "w":
                d = a.name;
                break a
            }
            d = void 0
        }
        c.name = d;
        d = !1;
        var e = a.key()
          , f = Ko[e];
        c.tick("_start", null, 0);
        for (var h in f)
            c.tick(h, "_start", f[h]),
            d = !0;
        Ko[e] = _.re();
        d && (h = [],
        h.push("l" + (_.Ke("isPlusUser") ? "1" : "0")),
        d = "m" + (Jo ? "1" : "0"),
        h.push(d),
        "m" == a.type ? h.push("p" + a.Sp) : "w" == a.type && (e = "n" + a.Sp,
        h.push(e),
        "0" == a.Sp && h.push(d + e)),
        h.push("u" + (_.Ke("isLoggedIn") ? "1" : "0")),
        a = Oo("", h),
        a = Oo("abc_", a).join(","),
        b.report(c, {
            e: a
        }))
    };
    yo("blt", "bs0", "bs1");
    yo("psi", "ps0", "ps1");
    yo("rpcqi", "rqe", "rqd");
    yo("bsprt", "bsrt0", "bsrt1");
    yo("bsrqt", "bsrt1", "bsrt2");
    yo("bsrst", "bsrt2", "bsrt3");
    yo("mli", "ml0", "ml1");
    yo("mei", "me0", "me1", !0);
    yo("wcdi", "wrs", "wcdi");
    yo("wci", "wrs", "wdc");
    yo("wdi", "wrs", "wrdi");
    yo("wdt", "bs0", "wrdt");
    yo("wri", "wrs", "wrri", !0);
    yo("wrt", "bs0", "wrrt");
    yo("wji", "wje0", "wje1", !0);
    yo("wjli", "wjl0", "wjl1");
    yo("whi", "wh0", "wh1", !0);
    yo("wai", "waaf0", "waaf1", !0);
    yo("wadi", "wrs", "waaf1", !0);
    yo("wadt", "bs0", "waaf1", !0);
    yo("wprt", "wrt0", "wrt1");
    yo("wrqt", "wrt1", "wrt2");
    yo("wrst", "wrt2", "wrt3", !0);
    yo("fbprt", "fsrt0", "fsrt1");
    yo("fbrqt", "fsrt1", "fsrt2");
    yo("fbrst", "fsrt2", "fsrt3", !0);
    yo("fdns", "fdns0", "fdns1");
    yo("fcon", "fcon0", "fcon1");
    yo("freq", "freq0", "freq1");
    yo("frsp", "frsp0", "frsp1");
    yo("fttfb", "fttfb0", "fttfb1");
    yo("ftot", "ftot0", "ftot1", !0);
    var Po = uo.r;
    if ("function" !== typeof Po) {
        for (var Qo; Qo = Po.shift(); )
            No.apply(null, Qo);
        uo.r = No
    }
    ;var Ro = ["div"], So = "onload", Uo = !0, Vo = !0, Wo = function(a) {
        return a
    }, Xo = null, Yo = function(a) {
        var b = _.Ke(a);
        return "undefined" !== typeof b ? b : _.Ke("gwidget/" + a)
    }, vp, wp, xp, yp, op, qp, zp, pp, Ap, Bp, Cp, Dp, Ep, Fp;
    Xo = _.Ke();
    _.Ke("gwidget");
    var Zo = Yo("parsetags");
    So = "explicit" === Zo || "onload" === Zo ? Zo : So;
    var $o = Yo("google_analytics");
    "undefined" !== typeof $o && (Uo = !!$o);
    var cp = Yo("data_layer");
    "undefined" !== typeof cp && (Vo = !!cp);
    var dp = function() {
        var a = this && this.getId();
        a && (_.Be.drw = a)
    }
      , ep = function() {
        _.Be.drw = null
    }
      , fp = function(a) {
        return function(b) {
            var c = a;
            "number" === typeof b ? c = b : "string" === typeof b && (c = b.indexOf("px"),
            -1 != c && (b = b.substring(0, c)),
            c = parseInt(b, 10));
            return c
        }
    }
      , gp = function(a) {
        "string" === typeof a && (a = window[a]);
        return "function" === typeof a ? a : null
    }
      , hp = function() {
        return Yo("lang") || "en-US"
    }
      , ip = function(a) {
        if (!_.r.kb("attach")) {
            var b = {}, c = _.r.kb("inline"), d;
            for (d in c)
                c.hasOwnProperty(d) && (b[d] = c[d]);
            b.open = function(e) {
                var f = e.$b().renderData.id;
                f = document.getElementById(f);
                if (!f)
                    throw Error("I");
                return c.attach(e, f)
            }
            ;
            _.r.qc("attach", b)
        }
        a.style = "attach"
    }
      , jp = function() {
        var a = {};
        a.width = [fp(450)];
        a.height = [fp(24)];
        a.onready = [gp];
        a.lang = [hp, "hl"];
        a.iloader = [function() {
            return _.Be.ILI
        }
        , "iloader"];
        return a
    }()
      , mp = function(a) {
        var b = {};
        b.Pe = a[0];
        b.fq = -1;
        b.Iea = "___" + b.Pe + "_";
        b.y4 = "g:" + b.Pe;
        b.Xca = "g-" + b.Pe;
        b.NP = [];
        b.config = {};
        b.Iu = [];
        b.SR = {};
        b.Jz = {};
        var c = function(e) {
            for (var f in e)
                if (_.se(e, f)) {
                    b.config[f] = [gp];
                    b.Iu.push(f);
                    var h = e[f]
                      , k = null
                      , l = null
                      , m = null;
                    "function" === typeof h ? k = h : h && "object" === typeof h && (k = h.Lca,
                    l = h.Kz,
                    m = h.aI);
                    m && (b.Iu.push(m),
                    b.config[m] = [gp],
                    b.SR[f] = m);
                    k && (b.config[f] = [k]);
                    l && (b.Jz[f] = l)
                }
        }
          , d = function(e) {
            for (var f = {}, h = 0; h < e.length; ++h)
                f[e[h].toLowerCase()] = 1;
            f[b.y4] = 1;
            b.N_ = f
        };
        a[1] && (b.parameters = a[1]);
        (function(e) {
            b.config = e;
            for (var f in jp)
                jp.hasOwnProperty(f) && !b.config.hasOwnProperty(f) && (b.config[f] = jp[f])
        }
        )(a[2] || {});
        a[3] && c(a[3]);
        a[4] && d(a[4]);
        a[5] && (b.bl = a[5]);
        b.zea = !0 === a[6];
        b.d1 = a[7];
        b.o4 = a[8];
        b.N_ || d(Ro);
        b.uE = function(e) {
            b.fq++;
            Ao("wrs", b.Pe, String(b.fq));
            var f = []
              , h = e.element
              , k = e.config
              , l = ":" + b.Pe;
            ":plus" == l && e.Yk && e.Yk.action && (l += "_" + e.Yk.action);
            var m = kp(b, k)
              , n = {};
            _.te(_.Jn(), n);
            for (var q in e.Yk)
                null != e.Yk[q] && (n[q] = e.Yk[q]);
            q = {
                container: h.id,
                renderData: e.z1,
                style: "inline",
                height: k.height,
                width: k.width
            };
            ip(q);
            b.bl && (f[2] = q,
            f[3] = n,
            f[4] = m,
            b.bl("i", f));
            l = _.r.open(l, q, n, m);
            lp(b, l, k, h, e.FV);
            f[5] = l;
            b.bl && b.bl("e", f)
        }
        ;
        return b
    }
      , kp = function(a, b) {
        for (var c = {}, d = a.Iu.length - 1; 0 <= d; --d) {
            var e = a.Iu[d]
              , f = b[a.SR[e] || e] || b[e]
              , h = b[e];
            h && f !== h && (f = function(l, m) {
                return function(n) {
                    m.apply(this, arguments);
                    l.apply(this, arguments)
                }
            }(f, h));
            f && (c[e] = f)
        }
        for (var k in a.Jz)
            a.Jz.hasOwnProperty(k) && (c[k] = np(c[k] || function() {}
            , a.Jz[k]));
        c.drefresh = dp;
        c.erefresh = ep;
        return c
    }
      , np = function(a, b) {
        return function(c) {
            var d = b(c);
            if (d) {
                var e = c.href || null;
                if (Uo) {
                    if (window._gat)
                        try {
                            var f = window._gat._getTrackerByName("~0");
                            f && "UA-XXXXX-X" != f._getAccount() ? f._trackSocial("Google", d, e) : window._gaq && window._gaq.push(["_trackSocial", "Google", d, e])
                        } catch (k) {}
                    if (window.ga && window.ga.getAll)
                        try {
                            var h = window.ga.getAll();
                            for (f = 0; f < h.length; f++)
                                h[f].send("social", "Google", d, e)
                        } catch (k) {}
                }
                if (Vo && window.dataLayer)
                    try {
                        window.dataLayer.push({
                            event: "social",
                            socialNetwork: "Google",
                            socialAction: d,
                            socialTarget: e
                        })
                    } catch (k) {}
            }
            a.call(this, c)
        }
    }
      , lp = function(a, b, c, d, e) {
        op(b, c);
        pp(b, d);
        qp(a, b, e);
        rp(a.Pe, a.fq.toString(), b);
        (new sp).hb.Rj(a, b, c, d, e)
    }
      , sp = function() {
        if (!this.hb) {
            for (var a = this.constructor; a && !a.Qn; )
                a = a.H && a.H.constructor;
            a.Qn.zK || (a.Qn.zK = fo(a));
            this.hb = new a.Qn.zK(this);
            this.WB || (this.WB = An)
        }
    }
      , tp = function() {}
      , up = sp;
    tp.H || _.$a(tp, ao);
    up.Qn = tp;
    tp.prototype.Rj = function(a) {
        a = a ? a : function() {}
        ;
        a.EO = !0;
        return a
    }();
    vp = function(a) {
        return _.Sm && a instanceof _.Sm
    }
    ;
    wp = function(a) {
        return vp(a) ? "_renderstart" : "renderstart"
    }
    ;
    xp = function(a) {
        return vp(a) ? "_ready" : "ready"
    }
    ;
    yp = function() {
        return !0
    }
    ;
    op = function(a, b) {
        if (b.onready) {
            var c = !1
              , d = function() {
                c || (c = !0,
                b.onready.call(null))
            };
            a.register(xp(a), d, yp);
            a.register(wp(a), d, yp)
        }
    }
    ;
    qp = function(a, b, c) {
        var d = a.Pe
          , e = String(a.fq)
          , f = !1
          , h = function() {
            f || (f = !0,
            b.getIframeEl(),
            c && Ao("wrdt", d, e),
            Ao("wrdi", d, e))
        };
        b.register(wp(b), h, yp);
        var k = !1;
        a = function() {
            k || (k = !0,
            h(),
            c && Ao("wrrt", d, e),
            Ao("wrri", d, e))
        }
        ;
        b.register(xp(b), a, yp);
        vp(b) ? b.register("widget-interactive-" + b.id, a, yp) : _.If.register("widget-interactive-" + b.id, a);
        _.If.register("widget-csi-tick-" + b.id, function(l, m, n) {
            "wdc" === l ? Ao("wdc", d, e, n) : "wje0" === l ? Ao("wje0", d, e, n) : "wje1" === l ? Ao("wje1", d, e, n) : "wh0" == l ? _.zo("wh0", d, e, n) : "wh1" == l ? _.zo("wh1", d, e, n) : "wcdi" == l && _.zo("wcdi", d, e, n)
        })
    }
    ;
    zp = function(a) {
        return "number" == typeof a ? a + "px" : "100%" == a ? a : null
    }
    ;
    pp = function(a, b) {
        var c = function(d) {
            d = d || a;
            var e = zp(d.width);
            e && b.style.width != e && (b.style.width = e);
            (d = zp(d.height)) && b.style.height != d && (b.style.height = d)
        };
        vp(a) ? a.setParam("onRestyle", c) : (a.register("ready", c, yp),
        a.register("renderstart", c, yp),
        a.register("resize", c, yp))
    }
    ;
    Ap = function(a, b) {
        for (var c in jp)
            if (jp.hasOwnProperty(c)) {
                var d = jp[c][1];
                d && !b.hasOwnProperty(d) && (b[d] = a[d])
            }
        return b
    }
    ;
    Bp = function(a, b) {
        var c = {}, d;
        for (d in a)
            a.hasOwnProperty(d) && (c[a[d][1] || d] = (a[d] && a[d][0] || Wo)(b[d.toLowerCase()], b, Xo));
        return c
    }
    ;
    Cp = function(a) {
        if (a = a.d1)
            for (var b = 0; b < a.length; b++)
                (new Image).src = a[b]
    }
    ;
    Dp = function(a, b) {
        var c = b.userParams
          , d = b.siteElement;
        d || (d = (d = b.iframeNode) && d.parentNode);
        if (d && 1 === d.nodeType) {
            var e = Bp(a.config, c);
            a.NP.push({
                element: d,
                config: e,
                Yk: Ap(e, Bp(a.parameters, c)),
                Jda: 3,
                FV: !!c["data-onload"],
                z1: b
            })
        }
        b = a.NP;
        for (a = a.uE; 0 < b.length; )
            a(b.shift())
    }
    ;
    Ep = function(a, b) {
        a.fq++;
        Ao("wrs", a.Pe, String(a.fq));
        var c = b.userParams
          , d = Bp(a.config, c)
          , e = []
          , f = b.iframeNode
          , h = b.siteElement
          , k = kp(a, d)
          , l = Bp(a.parameters, c);
        _.te(_.Jn(), l);
        l = Ap(d, l);
        c = !!c["data-onload"];
        var m = _.hk
          , n = _.re();
        n.renderData = b;
        n.height = d.height;
        n.width = d.width;
        n.id = b.id;
        n.url = b.url;
        n.iframeEl = f;
        n.where = n.container = h;
        n.apis = ["_open"];
        n.messageHandlers = k;
        n.messageHandlersFilter = _.ik;
        _.xn(n);
        f = l;
        a.bl && (e[2] = n,
        e[3] = f,
        e[4] = k,
        a.bl("i", e));
        k = m.Wj(n);
        k.id = b.id;
        k.xG(k, n);
        lp(a, k, d, h, c);
        e[5] = k;
        a.bl && a.bl("e", e)
    }
    ;
    Fp = function(a, b) {
        var c = b.url;
        a.o4 || _.mi(c) ? Ep(a, b) : _.r.open ? Dp(a, b) : (0,
        _.mg)("iframes", function() {
            Dp(a, b)
        })
    }
    ;
    _.Gp = function(a) {
        var b = mp(a);
        Cp(b);
        _.Gf(b.Pe, function(d) {
            Fp(b, d)
        });
        ho[b.Pe] = !0;
        var c = {
            ua: function(d, e, f) {
                var h = e || {};
                h.type = b.Pe;
                e = h.type;
                delete h.type;
                var k = no(d);
                if (k) {
                    d = {};
                    for (var l in h)
                        _.se(h, l) && (d[l.toLowerCase()] = h[l]);
                    d.rd = 1;
                    (l = !!d.ri) && delete d.ri;
                    qo(e, k, d, [], 0, l, f)
                } else
                    _.Df.log("string" === "gapi." + e + ".render: missing element " + typeof d ? d : "")
            },
            go: function(d) {
                ro(d, b.Pe)
            },
            Kda: function() {
                var d = _.pe(_.Be, "WI", _.re()), e;
                for (e in d)
                    delete d[e]
            }
        };
        a = function() {
            "onload" === So && c.go()
        }
        ;
        En(b.Pe) || Cn(a, a);
        _.I("gapi." + b.Pe + ".go", c.go);
        _.I("gapi." + b.Pe + ".render", c.ua);
        return c
    }
    ;
    var Hp = function() {
        var a = window;
        return !!a.performance && !!a.performance.getEntries
    }
      , rp = function(a, b, c) {
        if (Hp()) {
            var d = function() {
                var f = !1;
                return function() {
                    if (f)
                        return !0;
                    f = !0;
                    return !1
                }
            }()
              , e = function() {
                d() || window.setTimeout(function() {
                    var f = c.getIframeEl().src;
                    var h = f.indexOf("#");
                    -1 != h && (f = f.substring(0, h));
                    f = window.performance.getEntriesByName(f);
                    1 > f.length ? f = null : (f = f[0],
                    f = 0 == f.responseStart ? null : f);
                    if (f) {
                        h = Math.round(f.requestStart);
                        var k = Math.round(f.responseStart)
                          , l = Math.round(f.responseEnd);
                        Ao("wrt0", a, b, Math.round(f.startTime));
                        Ao("wrt1", a, b, h);
                        Ao("wrt2", a, b, k);
                        Ao("wrt3", a, b, l)
                    }
                }, 1E3)
            };
            c.register(wp(c), e, yp);
            c.register(xp(c), e, yp)
        }
    };
    _.I("gapi.widget.make", _.Gp);

    _.Ne = _.Ne || {};
    _.Ne.ms = function(a, b, c) {
        for (var d = [], e = 2, f = arguments.length; e < f; ++e)
            d.push(arguments[e]);
        return function() {
            for (var h = d.slice(), k = 0, l = arguments.length; k < l; ++k)
                h.push(arguments[k]);
            return b.apply(a, h)
        }
    }
    ;
    _.Ne.wx = function(a) {
        var b, c, d = {};
        for (b = 0; c = a[b]; ++b)
            d[c] = c;
        return d
    }
    ;

    _.Ne = _.Ne || {};
    _.Ne.KU = function(a) {
        var b = window;
        "undefined" != typeof b.addEventListener ? b.addEventListener("mousemove", a, !1) : "undefined" != typeof b.attachEvent ? b.attachEvent("onmousemove", a) : _.Oe("cannot attachBrowserEvent: mousemove")
    }
    ;
    _.Ne.u1 = function(a) {
        var b = window;
        b.removeEventListener ? b.removeEventListener("mousemove", a, !1) : b.detachEvent ? b.detachEvent("onmousemove", a) : _.Oe("cannot removeBrowserEvent: mousemove")
    }
    ;

    _.Ne = _.Ne || {};
    (function() {
        function a(c, d) {
            return String.fromCharCode(d)
        }
        var b = {
            0: !1,
            10: !0,
            13: !0,
            34: !0,
            39: !0,
            60: !0,
            62: !0,
            92: !0,
            8232: !0,
            8233: !0,
            65282: !0,
            65287: !0,
            65308: !0,
            65310: !0,
            65340: !0
        };
        _.Ne.escape = function(c, d) {
            if (c) {
                if ("string" === typeof c)
                    return _.Ne.HB(c);
                if ("Array" === typeof c) {
                    var e = 0;
                    for (d = c.length; e < d; ++e)
                        c[e] = _.Ne.escape(c[e])
                } else if ("object" === typeof c && d) {
                    d = {};
                    for (e in c)
                        c.hasOwnProperty(e) && (d[_.Ne.HB(e)] = _.Ne.escape(c[e], !0));
                    return d
                }
            }
            return c
        }
        ;
        _.Ne.HB = function(c) {
            if (!c)
                return c;
            for (var d = [], e, f, h = 0, k = c.length; h < k; ++h)
                e = c.charCodeAt(h),
                f = b[e],
                !0 === f ? d.push("&#", e, ";") : !1 !== f && d.push(c.charAt(h));
            return d.join("")
        }
        ;
        _.Ne.Dea = function(c) {
            return c ? c.replace(/&#([0-9]+);/g, a) : c
        }
    }
    )();

    _.Op = _.Op || {};
    _.Op.UX = function() {
        var a = 0
          , b = 0;
        self.innerHeight ? (a = self.innerWidth,
        b = self.innerHeight) : document.documentElement && document.documentElement.clientHeight ? (a = document.documentElement.clientWidth,
        b = document.documentElement.clientHeight) : document.body && (a = document.body.clientWidth,
        b = document.body.clientHeight);
        return {
            width: a,
            height: b
        }
    }
    ;

    _.Op = _.Op || {};
    (function() {
        function a() {
            function b(l, m) {
                l = window.getComputedStyle(l, "").getPropertyValue(m).match(/^([0-9]+)/);
                return parseInt(l[0], 10)
            }
            for (var c = 0, d = [document.body]; 0 < d.length; ) {
                var e = d.shift()
                  , f = e.childNodes;
                if ("undefined" !== typeof e.style) {
                    var h = e.style.overflowY;
                    h || (h = (h = document.defaultView.getComputedStyle(e, null)) ? h.overflowY : null);
                    if ("visible" != h && "inherit" != h && (h = e.style.height,
                    h || (h = (h = document.defaultView.getComputedStyle(e, null)) ? h.height : ""),
                    0 < h.length && "auto" != h))
                        continue
                }
                for (e = 0; e < f.length; e++) {
                    h = f[e];
                    if ("undefined" !== typeof h.offsetTop && "undefined" !== typeof h.offsetHeight) {
                        var k = h.offsetTop + h.offsetHeight + b(h, "margin-bottom");
                        c = Math.max(c, k)
                    }
                    d.push(h)
                }
            }
            return c + b(document.body, "border-bottom") + b(document.body, "margin-bottom") + b(document.body, "padding-bottom")
        }
        _.Op.Ac = function() {
            var b = _.Op.UX().height
              , c = document.body
              , d = document.documentElement;
            if ("CSS1Compat" === document.compatMode && d.scrollHeight)
                return d.scrollHeight !== b ? d.scrollHeight : d.offsetHeight;
            if (0 <= navigator.userAgent.indexOf("AppleWebKit"))
                return a();
            if (c && d) {
                var e = d.scrollHeight
                  , f = d.offsetHeight;
                d.clientHeight !== f && (e = c.scrollHeight,
                f = c.offsetHeight);
                return e > b ? e > f ? e : f : e < f ? e : f
            }
        }
    }
    )();

    _.vg = function() {
        function a(m) {
            var n = new _.ug;
            n.Nt(m);
            return n.Ih()
        }
        var b = window.crypto;
        if (b && "function" == typeof b.getRandomValues)
            return function() {
                var m = new window.Uint32Array(1);
                b.getRandomValues(m);
                return Number("0." + m[0])
            }
            ;
        var c = _.Ke("random/maxObserveMousemove");
        null == c && (c = -1);
        var d = 0
          , e = Math.random()
          , f = 1
          , h = 1E6 * (screen.width * screen.width + screen.height)
          , k = function(m) {
            m = m || window.event;
            var n = m.screenX + m.clientX << 16;
            n += m.screenY + m.clientY;
            n *= (new Date).getTime() % 1E6;
            f = f * n % h;
            0 < c && ++d == c && _.Ne.u1(k)
        };
        0 != c && _.Ne.KU(k);
        var l = a(document.cookie + "|" + document.location + "|" + (new Date).getTime() + "|" + e);
        return function() {
            var m = f;
            m += parseInt(l.substr(0, 20), 16);
            l = a(l);
            return m / (h + Math.pow(16, 20))
        }
    }();
    _.I("shindig.random", _.vg);

    _.r.Ja = {};
    _.r.Ja.Eh = {};
    _.r.Ja.Eh.aV = function(a) {
        try {
            return !!a.document
        } catch (b) {}
        return !1
    }
    ;
    _.r.Ja.Eh.rM = function(a) {
        var b = a.parent;
        return a != b && _.r.Ja.Eh.aV(b) ? _.r.Ja.Eh.rM(b) : a
    }
    ;
    _.r.Ja.Eh.Mca = function(a) {
        var b = a.userAgent || "";
        a = a.product || "";
        return 0 != b.indexOf("Opera") && -1 == b.indexOf("WebKit") && "Gecko" == a && 0 < b.indexOf("rv:1.")
    }
    ;
    _.r.Ja.Eh.ms = function(a, b, c) {
        for (var d = [], e = 2, f = arguments.length; e < f; ++e)
            d.push(arguments[e]);
        return function() {
            for (var h = d.slice(), k = 0, l = arguments.length; k < l; ++k)
                h.push(arguments[k]);
            return b.apply(a, h)
        }
    }
    ;

    var Pp, Qp, Rp, Sp, Vp, Wp, Xp, Yp, Zp, $p, aq;
    Pp = function() {
        _.If.register("_noop_echo", function() {
            this.callback(_.r.EX(_.r.Hk[this.f]))
        })
    }
    ;
    Qp = function() {
        window.setTimeout(function() {
            _.If.call("..", "_noop_echo", _.r.S0)
        }, 0)
    }
    ;
    Rp = function(a, b, c) {
        var d = function(e) {
            var f = Array.prototype.slice.call(arguments, 0)
              , h = f[f.length - 1];
            if ("function" === typeof h) {
                var k = h;
                f.pop()
            }
            f.unshift(b, a, k, c);
            _.If.call.apply(_.If, f)
        };
        d._iframe_wrapped_rpc_ = !0;
        return d
    }
    ;
    Sp = function(a) {
        _.r.ui[a] || (_.r.ui[a] = {},
        _.If.register(a, function(b, c) {
            var d = this.f;
            if (!("string" != typeof b || b in {} || d in {})) {
                var e = this.callback, f = _.r.ui[a][d], h;
                f && Object.hasOwnProperty.call(f, b) ? h = f[b] : Object.hasOwnProperty.call(_.r.zo, a) && (h = _.r.zo[a]);
                if (h)
                    return d = Array.prototype.slice.call(arguments, 1),
                    h._iframe_wrapped_rpc_ && e && d.push(e),
                    h.apply({}, d)
            }
            _.Df.error(['Unregistered call in window "', window.name, '" for method "', a, '", via proxyId "', b, '" from frame "', d, '".'].join(""));
            return null
        }));
        return _.r.ui[a]
    }
    ;
    _.Tp = function() {
        var a = {};
        var b = window.location.href;
        var c = b.indexOf("?")
          , d = b.indexOf("#");
        b = (-1 === d ? b.substr(c + 1) : [b.substr(c + 1, d - c - 1), "&", b.substr(d + 1)].join("")).split("&");
        c = window.decodeURIComponent ? decodeURIComponent : unescape;
        d = 0;
        for (var e = b.length; d < e; ++d) {
            var f = b[d].indexOf("=");
            if (-1 !== f) {
                var h = b[d].substring(0, f);
                f = b[d].substring(f + 1);
                f = f.replace(/\+/g, " ");
                try {
                    a[h] = c(f)
                } catch (k) {}
            }
        }
        return a
    }
    ;
    _.Up = function() {
        return _.le.location.origin || _.le.location.protocol + "//" + _.le.location.host
    }
    ;
    Vp = function(a) {
        _.Be.h = a
    }
    ;
    Wp = function(a) {
        _.Be.bsh = a
    }
    ;
    Xp = function(a) {
        var b = window.___jsl = window.___jsl || {};
        b[a] = b[a] || [];
        return b[a]
    }
    ;
    Yp = function(a) {
        return "object" === typeof a && /\[native code\]/.test(a.push)
    }
    ;
    Zp = function(a, b, c) {
        if (b && "object" === typeof b)
            for (var d in b)
                !Object.prototype.hasOwnProperty.call(b, d) || c && "___goc" === d && "undefined" === typeof b[d] || (a[d] && b[d] && "object" === typeof a[d] && "object" === typeof b[d] && !Yp(a[d]) && !Yp(b[d]) ? Zp(a[d], b[d]) : b[d] && "object" === typeof b[d] ? (a[d] = Yp(b[d]) ? [] : {},
                Zp(a[d], b[d])) : a[d] = b[d])
    }
    ;
    $p = function(a) {
        if (a && !/^\s+$/.test(a)) {
            for (; 0 == a.charCodeAt(a.length - 1); )
                a = a.substring(0, a.length - 1);
            try {
                var b = window.JSON.parse(a)
            } catch (c) {}
            if ("object" === typeof b)
                return b;
            try {
                b = (new Function("return (" + a + "\n)"))()
            } catch (c) {}
            if ("object" === typeof b)
                return b;
            try {
                b = (new Function("return ({" + a + "\n})"))()
            } catch (c) {}
            return "object" === typeof b ? b : {}
        }
    }
    ;
    aq = function(a, b) {
        var c = {
            ___goc: void 0
        };
        a.length && a[a.length - 1] && Object.hasOwnProperty.call(a[a.length - 1], "___goc") && "undefined" === typeof a[a.length - 1].___goc && (c = a.pop());
        Zp(c, b);
        a.push(c)
    }
    ;
    _.bq = function(a, b) {
        var c;
        if ("string" === typeof a) {
            var d = c = {};
            a = a.split("/");
            for (var e = 0, f = a.length; e < f - 1; ++e) {
                var h = {};
                d = d[a[e]] = h
            }
            d[a[e]] = b
        } else
            c = a;
        _.zh(!0);
        d = window.___gcfg;
        b = Xp("cu");
        a = window.___gu;
        d && d !== a && (aq(b, d),
        window.___gu = d);
        d = Xp("cu");
        e = document.scripts || document.getElementsByTagName("script") || [];
        a = [];
        f = [];
        f.push.apply(f, Xp("us"));
        for (h = 0; h < e.length; ++h)
            for (var k = e[h], l = 0; l < f.length; ++l)
                k.src && 0 == k.src.indexOf(f[l]) && a.push(k);
        0 == a.length && 0 < e.length && e[e.length - 1].src && a.push(e[e.length - 1]);
        for (e = 0; e < a.length; ++e)
            a[e].getAttribute("gapi_processed") || (a[e].setAttribute("gapi_processed", !0),
            (f = a[e]) ? (h = f.nodeType,
            f = 3 == h || 4 == h ? f.nodeValue : f.textContent || "") : f = void 0,
            (f = $p(f)) && d.push(f));
        c && aq(b, c);
        a = Xp("cd");
        c = 0;
        for (d = a.length; c < d; ++c)
            Zp(_.zh(), a[c], !0);
        a = Xp("ci");
        c = 0;
        for (d = a.length; c < d; ++c)
            Zp(_.zh(), a[c], !0);
        c = 0;
        for (d = b.length; c < d; ++c)
            Zp(_.zh(), b[c], !0)
    }
    ;
    var cq, dq = window.location.href, eq = dq.indexOf("?"), fq = dq.indexOf("#");
    cq = (-1 === fq ? dq.substr(eq + 1) : [dq.substr(eq + 1, fq - eq - 1), "&", dq.substr(fq + 1)].join("")).split("&");
    for (var gq = window.decodeURIComponent ? decodeURIComponent : unescape, hq = 0, iq = cq.length; hq < iq; ++hq) {
        var jq = cq[hq].indexOf("=");
        if (-1 !== jq) {
            var kq = cq[hq].substring(jq + 1);
            kq = kq.replace(/\+/g, " ");
            try {
                gq(kq)
            } catch (a) {}
        }
    }
    ;if (window.ToolbarApi)
        lq = window.ToolbarApi,
        lq.Oa = window.ToolbarApi.getInstance,
        lq.prototype = window.ToolbarApi.prototype,
        _.g = lq.prototype,
        _.g.openWindow = lq.prototype.openWindow,
        _.g.hK = lq.prototype.closeWindow,
        _.g.JQ = lq.prototype.setOnCloseHandler,
        _.g.TJ = lq.prototype.canClosePopup,
        _.g.UP = lq.prototype.resizeWindow;
    else {
        var lq = function() {};
        lq.Oa = function() {
            !mq && window.external && window.external.GTB_IsToolbar && (mq = new lq);
            return mq
        }
        ;
        _.g = lq.prototype;
        _.g.openWindow = function(a) {
            return window.external.GTB_OpenPopup && window.external.GTB_OpenPopup(a)
        }
        ;
        _.g.hK = function(a) {
            window.external.GTB_ClosePopupWindow && window.external.GTB_ClosePopupWindow(a)
        }
        ;
        _.g.JQ = function(a, b) {
            window.external.GTB_SetOnCloseHandler && window.external.GTB_SetOnCloseHandler(a, b)
        }
        ;
        _.g.TJ = function(a) {
            return window.external.GTB_CanClosePopup && window.external.GTB_CanClosePopup(a)
        }
        ;
        _.g.UP = function(a, b) {
            return window.external.GTB_ResizeWindow && window.external.GTB_ResizeWindow(a, b)
        }
        ;
        var mq = null;
        window.ToolbarApi = lq;
        window.ToolbarApi.getInstance = lq.Oa
    }
    ;var nq = /^[-_.0-9A-Za-z]+$/, oq = {
        open: "open",
        onready: "ready",
        close: "close",
        onresize: "resize",
        onOpen: "open",
        onReady: "ready",
        onClose: "close",
        onResize: "resize",
        onRenderStart: "renderstart"
    }, pq = {
        onBeforeParentOpen: "beforeparentopen"
    }, qq = {
        onOpen: function(a) {
            var b = a.$b();
            a.qg(b.container || b.element);
            return a
        },
        onClose: function(a) {
            a.remove()
        }
    }, rq = function() {
        _.r.jN++;
        return ["I", _.r.jN, "_", (new Date).getTime()].join("")
    }, sq, tq, uq, xq, yq, zq, Aq, Cq, Bq;
    _.r.Xl = function(a) {
        var b = _.re();
        _.te(_.ul, b);
        _.te(a, b);
        return b
    }
    ;
    sq = function(a) {
        return a instanceof Array ? a.join(",") : a instanceof Object ? _.yf(a) : a
    }
    ;
    tq = function(a) {
        var b = _.Ah("googleapis.config/elog");
        if (b)
            try {
                b(a)
            } catch (c) {}
    }
    ;
    uq = function(a) {
        a && a.match(nq) && _.bq("googleapis.config/gcv", a)
    }
    ;
    _.vq = function(a, b) {
        b = b || {};
        for (var c in a)
            a.hasOwnProperty(c) && (b[c] = a[c]);
        return b
    }
    ;
    _.wq = function(a, b, c, d, e) {
        var f = [], h;
        for (h in a)
            if (a.hasOwnProperty(h)) {
                var k = b
                  , l = c
                  , m = a[h]
                  , n = d
                  , q = Sp(h);
                q[k] = q[k] || {};
                n = _.r.Ja.Eh.ms(n, m);
                m._iframe_wrapped_rpc_ && (n._iframe_wrapped_rpc_ = !0);
                q[k][l] = n;
                f.push(h)
            }
        if (e)
            for (h in _.r.zo)
                _.r.zo.hasOwnProperty(h) && f.push(h);
        return f.join(",")
    }
    ;
    xq = function(a, b, c) {
        var d = {};
        if (a && a._methods) {
            a = a._methods.split(",");
            for (var e = 0; e < a.length; e++) {
                var f = a[e];
                d[f] = Rp(f, b, c)
            }
        }
        return d
    }
    ;
    yq = function(a) {
        if (a && a.disableMultiLevelParentRelay)
            a = !1;
        else {
            var b;
            if (b = _.zn && _.zn._open && "inline" != a.style && !0 !== a.inline)
                a = a.container,
                b = !(a && ("string" == typeof a && document.getElementById(a) || document == (a.ownerDocument || a.document)));
            a = b
        }
        return a
    }
    ;
    zq = function(a, b) {
        var c = {};
        b = b.params || {};
        for (var d in a)
            "#" == d.charAt(0) && (c[d.substring(1)] = a[d]),
            0 == d.indexOf("fr-") && (c[d.substring(3)] = a[d]),
            "#" == b[d] && (c[d] = a[d]);
        for (var e in c)
            delete a["fr-" + e],
            delete a["#" + e],
            delete a[e];
        return c
    }
    ;
    Aq = function(a) {
        if (":" == a.charAt(0)) {
            var b = _.Ah("iframes/" + a.substring(1));
            a = {};
            _.te(b, a);
            (b = a.url) && (a.url = _.Gl(b));
            a.params || (a.params = {});
            return a
        }
        return {
            url: _.Gl(a)
        }
    }
    ;
    Cq = function(a) {
        function b() {}
        b.prototype = Bq.prototype;
        a.prototype = new b
    }
    ;
    Bq = function(a, b, c, d, e, f, h, k) {
        this.config = Aq(a);
        this.openParams = this.Sx = b || {};
        this.params = c || {};
        this.methods = d;
        this.Bz = !1;
        Dq(this, b.style);
        this.Bq = {};
        Eq(this, function() {
            var l;
            (l = this.Sx.style) && _.r.xt[l] ? l = _.r.xt[l] : l ? (_.Df.warn(['Missing handler for style "', l, '". Continuing with default handler.'].join("")),
            l = null) : l = qq;
            if (l) {
                if ("function" === typeof l)
                    var m = l(this);
                else {
                    var n = {};
                    for (m in l) {
                        var q = l[m];
                        n[m] = "function" === typeof q ? _.r.Ja.Eh.ms(l, q, this) : q
                    }
                    m = n
                }
                for (var p in e)
                    l = m[p],
                    "function" === typeof l && Fq(this, e[p], _.r.Ja.Eh.ms(m, l))
            }
            f && Fq(this, "close", f)
        });
        this.qj = this.ac = h;
        this.yE = (k || []).slice();
        h && this.yE.unshift(h.getId())
    }
    ;
    Bq.prototype.$b = function() {
        return this.Sx
    }
    ;
    Bq.prototype.vC = function() {
        return this.params
    }
    ;
    Bq.prototype.Wv = function() {
        return this.methods
    }
    ;
    Bq.prototype.Lc = function() {
        return this.qj
    }
    ;
    var Dq = function(a, b) {
        a.Bz || ((b = b && !_.r.xt[b] && _.r.sB[b]) ? (a.rB = [],
        b(function() {
            a.Bz = !0;
            for (var c = 0, d = a.rB.length; c < d; ++c)
                a.rB[c].call(a)
        })) : a.Bz = !0)
    }
      , Eq = function(a, b) {
        a.Bz ? b.call(a) : a.rB.push(b)
    };
    Bq.prototype.kd = function(a, b) {
        Eq(this, function() {
            Fq(this, a, b)
        })
    }
    ;
    var Fq = function(a, b, c) {
        a.Bq[b] = a.Bq[b] || [];
        a.Bq[b].push(c)
    };
    Bq.prototype.Sm = function(a, b) {
        Eq(this, function() {
            var c = this.Bq[a];
            if (c)
                for (var d = 0, e = c.length; d < e; ++d)
                    if (c[d] === b) {
                        c.splice(d, 1);
                        break
                    }
        })
    }
    ;
    Bq.prototype.eh = function(a, b) {
        var c = this.Bq[a];
        if (c)
            for (var d = Array.prototype.slice.call(arguments, 1), e = 0, f = c.length; e < f; ++e)
                try {
                    var h = c[e].apply({}, d)
                } catch (k) {
                    _.Df.error(['Exception when calling callback "', a, '" with exception "', k.name, ": ", k.message, '".'].join("")),
                    tq(k)
                }
        return h
    }
    ;
    var Gq = function(a) {
        return "number" == typeof a ? {
            value: a,
            ZB: a + "px"
        } : "100%" == a ? {
            value: 100,
            ZB: "100%",
            ON: !0
        } : null
    };
    Bq.prototype.send = function(a, b, c) {
        _.r.hQ(this, a, b, c)
    }
    ;
    Bq.prototype.register = function(a, b) {
        var c = this;
        c.kd(a, function(d) {
            b.call(c, d)
        })
    }
    ;
    var Hq = function(a, b, c, d, e, f, h) {
        var k = this;
        Bq.call(this, a, b, c, d, oq, e, f, h);
        this.id = b.id || rq();
        this.Rs = b.rpctoken && String(b.rpctoken) || Math.round(1E9 * _.ai());
        this.tZ = zq(this.params, this.config);
        this.OB = {};
        Eq(this, function() {
            k.eh("open");
            _.vq(k.OB, k)
        })
    };
    Cq(Hq);
    _.g = Hq.prototype;
    _.g.qg = function(a, b) {
        if (!this.config.url)
            return _.Df.error("Cannot open iframe, empty URL."),
            this;
        var c = this.id;
        _.r.Hk[c] = this;
        var d = _.vq(this.methods);
        d._ready = this.Rx;
        d._close = this.close;
        d._open = this.fP;
        d._resizeMe = this.VP;
        d._renderstart = this.XO;
        var e = this.tZ;
        this.Rs && (e.rpctoken = this.Rs);
        e._methods = _.wq(d, c, "", this, !0);
        this.el = a = "string" === typeof a ? document.getElementById(a) : a;
        d = {
            id: c
        };
        if (b) {
            d.attributes = b;
            var f = b.style;
            if ("string" === typeof f) {
                if (f) {
                    var h = [];
                    f = f.split(";");
                    for (var k = 0, l = f.length; k < l; ++k) {
                        var m = f[k];
                        if (0 != m.length || k + 1 != l)
                            m = m.split(":"),
                            2 == m.length && m[0].match(/^[ a-zA-Z_-]+$/) && m[1].match(/^[ +.%0-9a-zA-Z_-]+$/) ? h.push(m.join(":")) : _.Df.error(['Iframe style "', f[k], '" not allowed.'].join(""))
                    }
                    h = h.join(";")
                } else
                    h = "";
                b.style = h
            }
        }
        this.$b().allowPost && (d.allowPost = !0);
        this.$b().forcePost && (d.forcePost = !0);
        d.queryParams = this.params;
        d.fragmentParams = e;
        d.paramsSerializer = sq;
        this.jh = _.Il(this.config.url, a, d);
        a = this.jh.getAttribute("data-postorigin") || this.jh.src;
        _.r.Hk[c] = this;
        _.If.Xy(this.id, this.Rs);
        _.If.Di(this.id, a);
        return this
    }
    ;
    _.g.Ug = function(a, b) {
        this.OB[a] = b
    }
    ;
    _.g.getId = function() {
        return this.id
    }
    ;
    _.g.getIframeEl = function() {
        return this.jh
    }
    ;
    _.g.getSiteEl = function() {
        return this.el
    }
    ;
    _.g.setSiteEl = function(a) {
        this.el = a
    }
    ;
    _.g.Rx = function(a) {
        var b = xq(a, this.id, "");
        this.qj && "function" == typeof this.methods._ready && (a._methods = _.wq(b, this.qj.getId(), this.id, this, !1),
        this.methods._ready(a));
        _.vq(a, this);
        _.vq(b, this);
        this.eh("ready", a)
    }
    ;
    _.g.XO = function(a) {
        this.eh("renderstart", a)
    }
    ;
    _.g.close = function(a) {
        a = this.eh("close", a);
        delete _.r.Hk[this.id];
        return a
    }
    ;
    _.g.remove = function() {
        var a = document.getElementById(this.id);
        a && a.parentNode && a.parentNode.removeChild(a)
    }
    ;
    _.g.fP = function(a) {
        var b = xq(a.params, this.id, a.proxyId);
        delete a.params._methods;
        "_parent" == a.openParams.anchor && (a.openParams.anchor = this.el);
        if (yq(a.openParams))
            new Iq(a.url,a.openParams,a.params,b,b._onclose,this,a.openedByProxyChain);
        else {
            var c = new Hq(a.url,a.openParams,a.params,b,b._onclose,this,a.openedByProxyChain)
              , d = this;
            Eq(c, function() {
                var e = {
                    childId: c.getId()
                }
                  , f = c.OB;
                f._toclose = c.close;
                e._methods = _.wq(f, d.id, c.id, c, !1);
                b._onopen(e)
            })
        }
    }
    ;
    _.g.VP = function(a) {
        if (void 0 === this.eh("resize", a) && this.jh) {
            var b = Gq(a.width);
            null != b && (this.jh.style.width = b.ZB);
            a = Gq(a.height);
            null != a && (this.jh.style.height = a.ZB);
            this.jh.parentElement && (null != b && b.ON || null != a && a.ON) && (this.jh.parentElement.style.display = "block")
        }
    }
    ;
    var Iq = function(a, b, c, d, e, f, h) {
        var k = this;
        Bq.call(this, a, b, c, d, pq, e, f, h);
        this.url = a;
        this.qn = null;
        this.SE = rq();
        Eq(this, function() {
            k.eh("beforeparentopen");
            var l = _.vq(k.methods);
            l._onopen = k.J0;
            l._ready = k.Rx;
            l._onclose = k.H0;
            k.params._methods = _.wq(l, "..", k.SE, k, !0);
            l = {};
            for (var m in k.params)
                l[m] = sq(k.params[m]);
            _.zn._open({
                url: k.config.url,
                openParams: k.Sx,
                params: l,
                proxyId: k.SE,
                openedByProxyChain: k.yE
            })
        })
    };
    Cq(Iq);
    Iq.prototype.PX = function() {
        return this.qn
    }
    ;
    Iq.prototype.J0 = function(a) {
        this.qn = a.childId;
        var b = xq(a, "..", this.qn);
        _.vq(b, this);
        this.close = b._toclose;
        _.r.Hk[this.qn] = this;
        this.qj && this.methods._onopen && (a._methods = _.wq(b, this.qj.getId(), this.qn, this, !1),
        this.methods._onopen(a))
    }
    ;
    Iq.prototype.Rx = function(a) {
        var b = String(this.qn)
          , c = xq(a, "..", b);
        _.vq(a, this);
        _.vq(c, this);
        this.eh("ready", a);
        this.qj && this.methods._ready && (a._methods = _.wq(c, this.qj.getId(), b, this, !1),
        this.methods._ready(a))
    }
    ;
    Iq.prototype.H0 = function(a) {
        if (this.qj && this.methods._onclose)
            this.methods._onclose(a);
        else
            return a = this.eh("close", a),
            delete _.r.Hk[this.qn],
            a
    }
    ;
    var Jq = function(a, b, c, d, e, f, h) {
        Bq.call(this, a, b, c, d, pq, f, h);
        this.id = b.id || rq();
        this.c4 = e;
        d._close = this.close;
        this.onClosed = this.PO;
        this.dS = 0;
        Eq(this, function() {
            this.eh("beforeparentopen");
            var k = _.vq(this.methods);
            this.params._methods = _.wq(k, "..", this.SE, this, !0);
            k = {};
            k.queryParams = this.params;
            a = _.zl(_.me, this.config.url, this.id, k);
            var l = e.openWindow(a);
            this.canAutoClose = function(m) {
                m(e.TJ(l))
            }
            ;
            e.JQ(l, this);
            this.dS = l
        })
    };
    Cq(Jq);
    Jq.prototype.close = function(a) {
        a = this.eh("close", a);
        this.c4.hK(this.dS);
        return a
    }
    ;
    Jq.prototype.PO = function() {
        this.eh("close")
    }
    ;
    _.zn.send = function(a, b, c) {
        _.r.hQ(_.zn, a, b, c)
    }
    ;
    (function() {
        function a(h) {
            return _.r.xt[h]
        }
        function b(h, k) {
            _.r.xt[h] = k
        }
        function c(h) {
            h = h || {};
            "auto" === h.height && (h.height = _.Wk());
            var k = window && lq && lq.Oa();
            k ? k.UP(h.width || 0, h.height || 0) : _.zn && _.zn._resizeMe && _.zn._resizeMe(h)
        }
        function d(h) {
            uq(h)
        }
        _.r.Hk = {};
        _.r.xt = {};
        _.r.sB = {};
        _.r.jN = 0;
        _.r.ui = {};
        _.r.zo = {};
        _.r.ey = null;
        _.r.by = [];
        _.r.S0 = function(h) {
            var k = !1;
            try {
                if (null != h) {
                    var l = window.parent.frames[h.id];
                    k = l.iframer.id == h.id && l.iframes.openedId_(_.zn.id)
                }
            } catch (m) {}
            try {
                _.r.ey = {
                    origin: this.origin,
                    referer: this.referer,
                    claimedOpenerId: h && h.id,
                    claimedOpenerProxyChain: h && h.proxyChain || [],
                    sameOrigin: k
                };
                for (h = 0; h < _.r.by.length; ++h)
                    _.r.by[h](_.r.ey);
                _.r.by = []
            } catch (m) {
                tq(m)
            }
        }
        ;
        _.r.EX = function(h) {
            var k = h && h.qj
              , l = null;
            k && (l = {},
            l.id = k.getId(),
            l.proxyChain = h.yE);
            return l
        }
        ;
        Pp();
        if (window.parent != window) {
            var e = _.Tp();
            e.gcv && uq(e.gcv);
            var f = e.jsh;
            f && Vp(f);
            _.vq(xq(e, "..", ""), _.zn);
            _.vq(e, _.zn);
            Qp()
        }
        _.r.kb = a;
        _.r.qc = b;
        _.r.X2 = d;
        _.r.resize = c;
        _.r.ZW = function(h) {
            return _.r.sB[h]
        }
        ;
        _.r.KF = function(h, k) {
            _.r.sB[h] = k
        }
        ;
        _.r.TP = c;
        _.r.s3 = d;
        _.r.yw = {};
        _.r.yw.get = a;
        _.r.yw.set = b;
        _.r.allow = function(h, k) {
            Sp(h);
            _.r.zo[h] = k || window[h]
        }
        ;
        _.r.Nba = function(h) {
            delete _.r.zo[h]
        }
        ;
        _.r.open = function(h, k, l, m, n, q) {
            3 == arguments.length ? m = {} : 4 == arguments.length && "function" === typeof m && (n = m,
            m = {});
            var p = "bubble" === k.style && lq ? lq.Oa() : null;
            return p ? new Jq(h,k,l,m,p,n,q) : yq(k) ? new Iq(h,k,l,m,n,q) : new Hq(h,k,l,m,n,q)
        }
        ;
        _.r.close = function(h, k) {
            _.zn && _.zn._close && _.zn._close(h, k)
        }
        ;
        _.r.ready = function(h, k, l) {
            2 == arguments.length && "function" === typeof k && (l = k,
            k = {});
            var m = h || {};
            "height"in m || (m.height = _.Wk());
            m._methods = _.wq(k || {}, "..", "", _.zn, !0);
            _.zn && _.zn._ready && _.zn._ready(m, l)
        }
        ;
        _.r.fM = function(h) {
            _.r.ey ? h(_.r.ey) : _.r.by.push(h)
        }
        ;
        _.r.L0 = function(h) {
            return !!_.r.Hk[h]
        }
        ;
        _.r.iX = function() {
            return ["https://ssl.gstatic.com/gb/js/", _.Ah("googleapis.config/gcv")].join("")
        }
        ;
        _.r.zP = function(h) {
            var k = {
                mouseover: 1,
                mouseout: 1
            };
            if (_.zn._event)
                for (var l = 0; l < h.length; l++) {
                    var m = h[l];
                    m in k && document.addEventListener(m, function(n) {
                        _.zn._event({
                            event: n.type,
                            timestamp: (new Date).getTime()
                        })
                    }, !0)
                }
        }
        ;
        _.r.hQ = function(h, k, l, m) {
            var n = this
              , q = [];
            void 0 !== l && q.push(l);
            m && q.push(function(p) {
                m.call(n, [p])
            });
            h[k] && h[k].apply(h, q)
        }
        ;
        _.r.CROSS_ORIGIN_IFRAMES_FILTER = function() {
            return !0
        }
        ;
        _.r.YU = function(h, k, l) {
            var m = Array.prototype.slice.call(arguments);
            _.r.fM(function(n) {
                n.sameOrigin && (m.unshift("/" + n.claimedOpenerId + "|" + window.location.protocol + "//" + window.location.host),
                _.If.call.apply(_.If, m))
            })
        }
        ;
        _.r.p1 = function(h, k) {
            _.If.register(h, k)
        }
        ;
        _.r.d3 = Vp;
        _.r.mQ = Wp;
        _.r.jO = tq;
        _.r.lN = _.zn
    }
    )();
    _.I("iframes.allow", _.r.allow);
    _.I("iframes.callSiblingOpener", _.r.YU);
    _.I("iframes.registerForOpenedSibling", _.r.p1);
    _.I("iframes.close", _.r.close);
    _.I("iframes.getGoogleConnectJsUri", _.r.iX);
    _.I("iframes.getHandler", _.r.kb);
    _.I("iframes.getDeferredHandler", _.r.ZW);
    _.I("iframes.getParentInfo", _.r.fM);
    _.I("iframes.iframer", _.r.lN);
    _.I("iframes.open", _.r.open);
    _.I("iframes.openedId_", _.r.L0);
    _.I("iframes.propagate", _.r.zP);
    _.I("iframes.ready", _.r.ready);
    _.I("iframes.resize", _.r.resize);
    _.I("iframes.setGoogleConnectJsVersion", _.r.X2);
    _.I("iframes.setBootstrapHint", _.r.mQ);
    _.I("iframes.setJsHint", _.r.d3);
    _.I("iframes.setHandler", _.r.qc);
    _.I("iframes.setDeferredHandler", _.r.KF);
    _.I("IframeBase", Bq);
    _.I("IframeBase.prototype.addCallback", Bq.prototype.kd);
    _.I("IframeBase.prototype.getMethods", Bq.prototype.Wv);
    _.I("IframeBase.prototype.getOpenerIframe", Bq.prototype.Lc);
    _.I("IframeBase.prototype.getOpenParams", Bq.prototype.$b);
    _.I("IframeBase.prototype.getParams", Bq.prototype.vC);
    _.I("IframeBase.prototype.removeCallback", Bq.prototype.Sm);
    _.I("Iframe", Hq);
    _.I("Iframe.prototype.close", Hq.prototype.close);
    _.I("Iframe.prototype.exposeMethod", Hq.prototype.Ug);
    _.I("Iframe.prototype.getId", Hq.prototype.getId);
    _.I("Iframe.prototype.getIframeEl", Hq.prototype.getIframeEl);
    _.I("Iframe.prototype.getSiteEl", Hq.prototype.getSiteEl);
    _.I("Iframe.prototype.openInto", Hq.prototype.qg);
    _.I("Iframe.prototype.remove", Hq.prototype.remove);
    _.I("Iframe.prototype.setSiteEl", Hq.prototype.setSiteEl);
    _.I("Iframe.prototype.addCallback", Hq.prototype.kd);
    _.I("Iframe.prototype.getMethods", Hq.prototype.Wv);
    _.I("Iframe.prototype.getOpenerIframe", Hq.prototype.Lc);
    _.I("Iframe.prototype.getOpenParams", Hq.prototype.$b);
    _.I("Iframe.prototype.getParams", Hq.prototype.vC);
    _.I("Iframe.prototype.removeCallback", Hq.prototype.Sm);
    _.I("IframeProxy", Iq);
    _.I("IframeProxy.prototype.getTargetIframeId", Iq.prototype.PX);
    _.I("IframeProxy.prototype.addCallback", Iq.prototype.kd);
    _.I("IframeProxy.prototype.getMethods", Iq.prototype.Wv);
    _.I("IframeProxy.prototype.getOpenerIframe", Iq.prototype.Lc);
    _.I("IframeProxy.prototype.getOpenParams", Iq.prototype.$b);
    _.I("IframeProxy.prototype.getParams", Iq.prototype.vC);
    _.I("IframeProxy.prototype.removeCallback", Iq.prototype.Sm);
    _.I("IframeWindow", Jq);
    _.I("IframeWindow.prototype.close", Jq.prototype.close);
    _.I("IframeWindow.prototype.onClosed", Jq.prototype.PO);
    _.I("iframes.util.getTopMostAccessibleWindow", _.r.Ja.Eh.rM);
    _.I("iframes.handlers.get", _.r.yw.get);
    _.I("iframes.handlers.set", _.r.yw.set);
    _.I("iframes.resizeMe", _.r.TP);
    _.I("iframes.setVersionOverride", _.r.s3);
    _.I("iframes.CROSS_ORIGIN_IFRAMES_FILTER", _.r.CROSS_ORIGIN_IFRAMES_FILTER);
    _.I("IframeBase.prototype.send", Bq.prototype.send);
    _.I("IframeBase.prototype.register", Bq.prototype.register);
    _.I("Iframe.prototype.send", Hq.prototype.send);
    _.I("Iframe.prototype.register", Hq.prototype.register);
    _.I("IframeProxy.prototype.send", Iq.prototype.send);
    _.I("IframeProxy.prototype.register", Iq.prototype.register);
    _.I("IframeWindow.prototype.send", Jq.prototype.send);
    _.I("IframeWindow.prototype.register", Jq.prototype.register);
    _.I("iframes.iframer.send", _.r.lN.send);

    var lt = _.r.qc
      , mt = {
        open: function(a) {
            var b = _.tn(a.$b());
            return a.qg(b, {
                style: _.un(b)
            })
        },
        attach: function(a, b) {
            var c = _.tn(a.$b())
              , d = b.id
              , e = b.getAttribute("data-postorigin") || b.src
              , f = /#(?:.*&)?rpctoken=(\d+)/.exec(e);
            f = f && f[1];
            a.id = d;
            a.Rs = f;
            a.el = c;
            a.jh = b;
            _.r.Hk[d] = a;
            b = _.vq(a.methods);
            b._ready = a.Rx;
            b._close = a.close;
            b._open = a.fP;
            b._resizeMe = a.VP;
            b._renderstart = a.XO;
            _.wq(b, d, "", a, !0);
            _.If.Xy(a.id, a.Rs);
            _.If.Di(a.id, e);
            c = _.r.Xl({
                style: _.un(c)
            });
            for (var h in c)
                Object.prototype.hasOwnProperty.call(c, h) && ("style" == h ? a.jh.style.cssText = c[h] : a.jh.setAttribute(h, c[h]))
        }
    };
    mt.onready = _.vn;
    mt.onRenderStart = _.vn;
    mt.close = _.wn;
    lt("inline", mt);

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.fh = function(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            255 < e && (b[c++] = e & 255,
            e >>= 8);
            b[c++] = e
        }
        return b
    }
    ;
    var gh, hh, jh;
    gh = {};
    hh = null;
    _.ih = _.kd || _.ld || !_.dh && !_.hd && "function" == typeof _.D.atob;
    _.kh = function(a, b) {
        void 0 === b && (b = 0);
        jh();
        b = gh[b];
        for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
            var h = a[e]
              , k = a[e + 1]
              , l = a[e + 2]
              , m = b[h >> 2];
            h = b[(h & 3) << 4 | k >> 4];
            k = b[(k & 15) << 2 | l >> 6];
            l = b[l & 63];
            c[f++] = m + h + k + l
        }
        m = 0;
        l = d;
        switch (a.length - e) {
        case 2:
            m = a[e + 1],
            l = b[(m & 15) << 2] || d;
        case 1:
            a = a[e],
            c[f] = b[a >> 2] + b[(a & 3) << 4 | m >> 4] + l + d
        }
        return c.join("")
    }
    ;
    _.lh = function(a, b) {
        function c(l) {
            for (; d < a.length; ) {
                var m = a.charAt(d++)
                  , n = hh[m];
                if (null != n)
                    return n;
                if (!_.nc(m))
                    throw Error("x`" + m);
            }
            return l
        }
        jh();
        for (var d = 0; ; ) {
            var e = c(-1)
              , f = c(0)
              , h = c(64)
              , k = c(64);
            if (64 === k && -1 === e)
                break;
            b(e << 2 | f >> 4);
            64 != h && (b(f << 4 & 240 | h >> 2),
            64 != k && b(h << 6 & 192 | k))
        }
    }
    ;
    jh = function() {
        if (!hh) {
            hh = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                var d = a.concat(b[c].split(""));
                gh[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e];
                    void 0 === hh[f] && (hh[f] = e)
                }
            }
        }
    }
    ;

    _.Fh = {};
    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var Hh;
    _.Gh = function(a) {
        this.nb = a || {
            cookie: ""
        }
    }
    ;
    _.g = _.Gh.prototype;
    _.g.isEnabled = function() {
        if (!_.D.navigator.cookieEnabled)
            return !1;
        if (!this.isEmpty())
            return !0;
        this.set("TESTCOOKIESENABLED", "1", {
            YD: 60
        });
        if ("1" !== this.get("TESTCOOKIESENABLED"))
            return !1;
        this.remove("TESTCOOKIESENABLED");
        return !0
    }
    ;
    _.g.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.Pda;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var h = c.path || void 0;
            var k = c.YD
        }
        if (/[;=\s]/.test(a))
            throw Error("A`" + a);
        if (/[;\r\n]/.test(b))
            throw Error("B`" + b);
        void 0 === k && (k = -1);
        this.nb.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (h ? ";path=" + h : "") + (0 > k ? "" : 0 == k ? ";expires=" + (new Date(1970,1,1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * k)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    }
    ;
    _.g.get = function(a, b) {
        for (var c = a + "=", d = (this.nb.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = (0,
            _.oc)(d[e]);
            if (0 == f.lastIndexOf(c, 0))
                return f.substr(c.length);
            if (f == a)
                return ""
        }
        return b
    }
    ;
    _.g.remove = function(a, b, c) {
        var d = this.re(a);
        this.set(a, "", {
            YD: 0,
            path: b,
            domain: c
        });
        return d
    }
    ;
    _.g.Ef = function() {
        return Hh(this).keys
    }
    ;
    _.g.Sc = function() {
        return Hh(this).values
    }
    ;
    _.g.isEmpty = function() {
        return !this.nb.cookie
    }
    ;
    _.g.Eb = function() {
        return this.nb.cookie ? (this.nb.cookie || "").split(";").length : 0
    }
    ;
    _.g.re = function(a) {
        return void 0 !== this.get(a)
    }
    ;
    _.g.Ui = function(a) {
        for (var b = Hh(this).values, c = 0; c < b.length; c++)
            if (b[c] == a)
                return !0;
        return !1
    }
    ;
    _.g.clear = function() {
        for (var a = Hh(this).keys, b = a.length - 1; 0 <= b; b--)
            this.remove(a[b])
    }
    ;
    Hh = function(a) {
        a = (a.nb.cookie || "").split(";");
        for (var b = [], c = [], d, e, f = 0; f < a.length; f++)
            e = (0,
            _.oc)(a[f]),
            d = e.indexOf("="),
            -1 == d ? (b.push(""),
            c.push(e)) : (b.push(e.substring(0, d)),
            c.push(e.substring(d + 1)));
        return {
            keys: b,
            values: c
        }
    }
    ;
    _.Ih = new _.Gh("undefined" == typeof document ? null : document);

    _.Th = {};
    _.Uh = function(a) {
        return _.Th[a || "token"] || null
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var xi;
    _.wi = function(a, b) {
        b = (0,
        _.kb)(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    }
    ;
    xi = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a))
                return !0;
        return !1
    }
    ;
    _.yi = function(a) {
        for (var b in a)
            return !1;
        return !0
    }
    ;
    _.zi = function(a) {
        a && "function" == typeof a.Ga && a.Ga()
    }
    ;
    _.Ai = function(a, b) {
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) == c
    }
    ;
    _.Bi = function() {
        this.dg = this.dg;
        this.Im = this.Im
    }
    ;
    _.Bi.prototype.dg = !1;
    _.Bi.prototype.isDisposed = function() {
        return this.dg
    }
    ;
    _.Bi.prototype.Ga = function() {
        this.dg || (this.dg = !0,
        this.na())
    }
    ;
    _.Di = function(a, b) {
        _.Ci(a, _.ri(_.zi, b))
    }
    ;
    _.Ci = function(a, b) {
        a.dg ? b() : (a.Im || (a.Im = []),
        a.Im.push(b))
    }
    ;
    _.Bi.prototype.na = function() {
        if (this.Im)
            for (; this.Im.length; )
                this.Im.shift()()
    }
    ;
    _.Ei = function(a, b) {
        this.type = a;
        this.currentTarget = this.target = b;
        this.defaultPrevented = this.Ls = !1
    }
    ;
    _.Ei.prototype.stopPropagation = function() {
        this.Ls = !0
    }
    ;
    _.Ei.prototype.preventDefault = function() {
        this.defaultPrevented = !0
    }
    ;
    var Fi = function() {
        if (!_.D.addEventListener || !Object.defineProperty)
            return !1;
        var a = !1
          , b = Object.defineProperty({}, "passive", {
            get: function() {
                a = !0
            }
        });
        try {
            _.D.addEventListener("test", _.Cb, b),
            _.D.removeEventListener("test", _.Cb, b)
        } catch (c) {}
        return a
    }();
    _.Gi = function(a, b) {
        _.Ei.call(this, a ? a.type : "");
        this.relatedTarget = this.currentTarget = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
        this.key = "";
        this.charCode = this.keyCode = 0;
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.IE = !1;
        this.pointerId = 0;
        this.pointerType = "";
        this.ye = null;
        a && this.wd(a, b)
    }
    ;
    _.$a(_.Gi, _.Ei);
    var Hi = {
        2: "touch",
        3: "pen",
        4: "mouse"
    };
    _.Gi.prototype.wd = function(a, b) {
        var c = this.type = a.type
          , d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
        this.target = a.target || a.srcElement;
        this.currentTarget = b;
        (b = a.relatedTarget) ? _.kd && (_.ed(b, "nodeName") || (b = null)) : "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
        this.relatedTarget = b;
        d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX,
        this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY,
        this.screenX = d.screenX || 0,
        this.screenY = d.screenY || 0) : (this.offsetX = _.ld || void 0 !== a.offsetX ? a.offsetX : a.layerX,
        this.offsetY = _.ld || void 0 !== a.offsetY ? a.offsetY : a.layerY,
        this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX,
        this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY,
        this.screenX = a.screenX || 0,
        this.screenY = a.screenY || 0);
        this.button = a.button;
        this.keyCode = a.keyCode || 0;
        this.key = a.key || "";
        this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.IE = _.nd ? a.metaKey : a.ctrlKey;
        this.pointerId = a.pointerId || 0;
        this.pointerType = "string" === typeof a.pointerType ? a.pointerType : Hi[a.pointerType] || "";
        this.state = a.state;
        this.ye = a;
        a.defaultPrevented && _.Gi.H.preventDefault.call(this)
    }
    ;
    _.Gi.prototype.stopPropagation = function() {
        _.Gi.H.stopPropagation.call(this);
        this.ye.stopPropagation ? this.ye.stopPropagation() : this.ye.cancelBubble = !0
    }
    ;
    _.Gi.prototype.preventDefault = function() {
        _.Gi.H.preventDefault.call(this);
        var a = this.ye;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    }
    ;
    _.Ii = "closure_listenable_" + (1E6 * Math.random() | 0);
    _.Ji = function(a) {
        return !(!a || !a[_.Ii])
    }
    ;
    var Ki = 0;
    var Li = function(a, b, c, d, e) {
        this.listener = a;
        this.proxy = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.Xe = e;
        this.key = ++Ki;
        this.Os = this.Hu = !1
    }
      , Mi = function(a) {
        a.Os = !0;
        a.listener = null;
        a.proxy = null;
        a.src = null;
        a.Xe = null
    };
    var Ni = function(a) {
        this.src = a;
        this.Nd = {};
        this.Kt = 0
    };
    Ni.prototype.add = function(a, b, c, d, e) {
        var f = a.toString();
        a = this.Nd[f];
        a || (a = this.Nd[f] = [],
        this.Kt++);
        var h = Oi(a, b, d, e);
        -1 < h ? (b = a[h],
        c || (b.Hu = !1)) : (b = new Li(b,this.src,f,!!d,e),
        b.Hu = c,
        a.push(b));
        return b
    }
    ;
    Ni.prototype.remove = function(a, b, c, d) {
        a = a.toString();
        if (!(a in this.Nd))
            return !1;
        var e = this.Nd[a];
        b = Oi(e, b, c, d);
        return -1 < b ? (Mi(e[b]),
        Array.prototype.splice.call(e, b, 1),
        0 == e.length && (delete this.Nd[a],
        this.Kt--),
        !0) : !1
    }
    ;
    var Pi = function(a, b) {
        var c = b.type;
        if (!(c in a.Nd))
            return !1;
        var d = _.wi(a.Nd[c], b);
        d && (Mi(b),
        0 == a.Nd[c].length && (delete a.Nd[c],
        a.Kt--));
        return d
    };
    Ni.prototype.removeAll = function(a) {
        a = a && a.toString();
        var b = 0, c;
        for (c in this.Nd)
            if (!a || c == a) {
                for (var d = this.Nd[c], e = 0; e < d.length; e++)
                    ++b,
                    Mi(d[e]);
                delete this.Nd[c];
                this.Kt--
            }
        return b
    }
    ;
    Ni.prototype.ko = function(a, b, c, d) {
        a = this.Nd[a.toString()];
        var e = -1;
        a && (e = Oi(a, b, c, d));
        return -1 < e ? a[e] : null
    }
    ;
    Ni.prototype.hasListener = function(a, b) {
        var c = void 0 !== a
          , d = c ? a.toString() : ""
          , e = void 0 !== b;
        return xi(this.Nd, function(f) {
            for (var h = 0; h < f.length; ++h)
                if (!(c && f[h].type != d || e && f[h].capture != b))
                    return !0;
            return !1
        })
    }
    ;
    var Oi = function(a, b, c, d) {
        for (var e = 0; e < a.length; ++e) {
            var f = a[e];
            if (!f.Os && f.listener == b && f.capture == !!c && f.Xe == d)
                return e
        }
        return -1
    };
    var Qi, Ri, Si, Wi, Yi, Zi, $i, cj;
    Qi = "closure_lm_" + (1E6 * Math.random() | 0);
    Ri = {};
    Si = 0;
    _.Ui = function(a, b, c, d, e) {
        if (d && d.once)
            return _.Ti(a, b, c, d, e);
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++)
                _.Ui(a, b[f], c, d, e);
            return null
        }
        c = _.Vi(c);
        return _.Ji(a) ? a.V(b, c, _.Bb(d) ? !!d.capture : !!d, e) : Wi(a, b, c, !1, d, e)
    }
    ;
    Wi = function(a, b, c, d, e, f) {
        if (!b)
            throw Error("C");
        var h = _.Bb(e) ? !!e.capture : !!e
          , k = _.Xi(a);
        k || (a[Qi] = k = new Ni(a));
        c = k.add(b, c, d, h, f);
        if (c.proxy)
            return c;
        d = Yi();
        c.proxy = d;
        d.src = a;
        d.listener = c;
        if (a.addEventListener)
            Fi || (e = h),
            void 0 === e && (e = !1),
            a.addEventListener(b.toString(), d, e);
        else if (a.attachEvent)
            a.attachEvent(Zi(b.toString()), d);
        else if (a.addListener && a.removeListener)
            a.addListener(d);
        else
            throw Error("D");
        Si++;
        return c
    }
    ;
    Yi = function() {
        var a = $i
          , b = function(c) {
            return a.call(b.src, b.listener, c)
        };
        return b
    }
    ;
    _.Ti = function(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++)
                _.Ti(a, b[f], c, d, e);
            return null
        }
        c = _.Vi(c);
        return _.Ji(a) ? a.Uo(b, c, _.Bb(d) ? !!d.capture : !!d, e) : Wi(a, b, c, !0, d, e)
    }
    ;
    _.aj = function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++)
                _.aj(a, b[f], c, d, e);
        else
            d = _.Bb(d) ? !!d.capture : !!d,
            c = _.Vi(c),
            _.Ji(a) ? a.Xb(b, c, d, e) : a && (a = _.Xi(a)) && (b = a.ko(b, c, d, e)) && _.bj(b)
    }
    ;
    _.bj = function(a) {
        if ("number" === typeof a || !a || a.Os)
            return !1;
        var b = a.src;
        if (_.Ji(b))
            return b.MH(a);
        var c = a.type
          , d = a.proxy;
        b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Zi(c), d) : b.addListener && b.removeListener && b.removeListener(d);
        Si--;
        (c = _.Xi(b)) ? (Pi(c, a),
        0 == c.Kt && (c.src = null,
        b[Qi] = null)) : Mi(a);
        return !0
    }
    ;
    Zi = function(a) {
        return a in Ri ? Ri[a] : Ri[a] = "on" + a
    }
    ;
    $i = function(a, b) {
        if (a.Os)
            a = !0;
        else {
            b = new _.Gi(b,this);
            var c = a.listener
              , d = a.Xe || a.src;
            a.Hu && _.bj(a);
            a = c.call(d, b)
        }
        return a
    }
    ;
    _.Xi = function(a) {
        a = a[Qi];
        return a instanceof Ni ? a : null
    }
    ;
    cj = "__closure_events_fn_" + (1E9 * Math.random() >>> 0);
    _.Vi = function(a) {
        if ("function" === typeof a)
            return a;
        a[cj] || (a[cj] = function(b) {
            return a.handleEvent(b)
        }
        );
        return a[cj]
    }
    ;
    _.vi(function(a) {
        $i = a($i)
    });
    _.dj = function() {
        _.Bi.call(this);
        this.cj = new Ni(this);
        this.yU = this;
        this.DE = null
    }
    ;
    _.$a(_.dj, _.Bi);
    _.dj.prototype[_.Ii] = !0;
    _.g = _.dj.prototype;
    _.g.Zl = function() {
        return this.DE
    }
    ;
    _.g.iz = _.ea(3);
    _.g.addEventListener = function(a, b, c, d) {
        _.Ui(this, a, b, c, d)
    }
    ;
    _.g.removeEventListener = function(a, b, c, d) {
        _.aj(this, a, b, c, d)
    }
    ;
    _.g.dispatchEvent = function(a) {
        var b, c = this.Zl();
        if (c)
            for (b = []; c; c = c.Zl())
                b.push(c);
        c = this.yU;
        var d = a.type || a;
        if ("string" === typeof a)
            a = new _.Ei(a,c);
        else if (a instanceof _.Ei)
            a.target = a.target || c;
        else {
            var e = a;
            a = new _.Ei(d,c);
            _.qi(a, e)
        }
        e = !0;
        if (b)
            for (var f = b.length - 1; !a.Ls && 0 <= f; f--) {
                var h = a.currentTarget = b[f];
                e = h.er(d, !0, a) && e
            }
        a.Ls || (h = a.currentTarget = c,
        e = h.er(d, !0, a) && e,
        a.Ls || (e = h.er(d, !1, a) && e));
        if (b)
            for (f = 0; !a.Ls && f < b.length; f++)
                h = a.currentTarget = b[f],
                e = h.er(d, !1, a) && e;
        return e
    }
    ;
    _.g.na = function() {
        _.dj.H.na.call(this);
        this.WE();
        this.DE = null
    }
    ;
    _.g.V = function(a, b, c, d) {
        return this.cj.add(String(a), b, !1, c, d)
    }
    ;
    _.g.Uo = function(a, b, c, d) {
        return this.cj.add(String(a), b, !0, c, d)
    }
    ;
    _.g.Xb = function(a, b, c, d) {
        return this.cj.remove(String(a), b, c, d)
    }
    ;
    _.g.MH = function(a) {
        return Pi(this.cj, a)
    }
    ;
    _.g.WE = function(a) {
        this.cj && this.cj.removeAll(a)
    }
    ;
    _.g.er = function(a, b, c) {
        a = this.cj.Nd[String(a)];
        if (!a)
            return !0;
        a = a.concat();
        for (var d = !0, e = 0; e < a.length; ++e) {
            var f = a[e];
            if (f && !f.Os && f.capture == b) {
                var h = f.listener
                  , k = f.Xe || f.src;
                f.Hu && this.MH(f);
                d = !1 !== h.call(k, c) && d
            }
        }
        return d && !c.defaultPrevented
    }
    ;
    _.g.ko = function(a, b, c, d) {
        return this.cj.ko(String(a), b, c, d)
    }
    ;
    _.g.hasListener = function(a, b) {
        return this.cj.hasListener(void 0 !== a ? String(a) : void 0, b)
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var zs;
    zs = function(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    }
    ;
    _.As = function(a, b, c, d) {
        return Array.prototype.splice.apply(a, zs(arguments, 1))
    }
    ;
    _.Bs = function(a, b, c) {
        if (null !== a && b in a)
            throw Error("f`" + b);
        a[b] = c
    }
    ;
    _.Rd.prototype.N = _.cb(1, function(a) {
        return _.oi(this.nb, a)
    });
    _.Cs = function(a, b) {
        var c = b || document;
        if (c.getElementsByClassName)
            a = c.getElementsByClassName(a)[0];
        else {
            c = document;
            var d = b || c;
            a = d.querySelectorAll && d.querySelector && a ? d.querySelector(a ? "." + a : "") : _.Ud(c, "*", a, b)[0] || null
        }
        return a || null
    }
    ;
    _.Ds = function(a) {
        var b;
        if (_.Hd && !(_.hd && _.Dd("9") && !_.Dd("10") && _.D.SVGElement && a instanceof _.D.SVGElement) && (b = a.parentElement))
            return b;
        b = a.parentNode;
        return _.ie(b) ? b : null
    }
    ;
    _.Es = function(a) {
        _.Bi.call(this);
        this.$d = a;
        this.Lb = {}
    }
    ;
    _.$a(_.Es, _.Bi);
    var Fs = [];
    _.Es.prototype.V = function(a, b, c, d) {
        return this.ds(a, b, c, d)
    }
    ;
    _.Es.prototype.ds = function(a, b, c, d, e) {
        Array.isArray(b) || (b && (Fs[0] = b.toString()),
        b = Fs);
        for (var f = 0; f < b.length; f++) {
            var h = _.Ui(a, b[f], c || this.handleEvent, d || !1, e || this.$d || this);
            if (!h)
                break;
            this.Lb[h.key] = h
        }
        return this
    }
    ;
    _.Es.prototype.Uo = function(a, b, c, d) {
        return Gs(this, a, b, c, d)
    }
    ;
    var Gs = function(a, b, c, d, e, f) {
        if (Array.isArray(c))
            for (var h = 0; h < c.length; h++)
                Gs(a, b, c[h], d, e, f);
        else {
            b = _.Ti(b, c, d || a.handleEvent, e, f || a.$d || a);
            if (!b)
                return a;
            a.Lb[b.key] = b
        }
        return a
    };
    _.Es.prototype.Xb = function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++)
                this.Xb(a, b[f], c, d, e);
        else
            c = c || this.handleEvent,
            d = _.Bb(d) ? !!d.capture : !!d,
            e = e || this.$d || this,
            c = _.Vi(c),
            d = !!d,
            b = _.Ji(a) ? a.ko(b, c, d, e) : a ? (a = _.Xi(a)) ? a.ko(b, c, d, e) : null : null,
            b && (_.bj(b),
            delete this.Lb[b.key]);
        return this
    }
    ;
    _.Es.prototype.removeAll = function() {
        _.nb(this.Lb, function(a, b) {
            this.Lb.hasOwnProperty(b) && _.bj(a)
        }, this);
        this.Lb = {}
    }
    ;
    _.Es.prototype.na = function() {
        _.Es.H.na.call(this);
        this.removeAll()
    }
    ;
    _.Es.prototype.handleEvent = function() {
        throw Error("K");
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/

    var Au, Bu, Cu, Du, Fu, Gu, Hu, Iu, Ku;
    _.zu = !1;
    Au = function(a) {
        try {
            _.zu && window.console && window.console.log && window.console.log(a)
        } catch (b) {}
    }
    ;
    Bu = function(a, b) {
        if (!a)
            return -1;
        if (a.indexOf)
            return a.indexOf(b, void 0);
        for (var c = 0, d = a.length; c < d; c++)
            if (a[c] === b)
                return c;
        return -1
    }
    ;
    Cu = function(a, b) {
        function c() {}
        if (!a)
            throw Error("N");
        if (!b)
            throw Error("O");
        c.prototype = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a
    }
    ;
    Du = function(a) {
        return "[object Function]" === Object.prototype.toString.call(a)
    }
    ;
    _.Eu = function(a) {
        var b = {};
        if (a)
            for (var c in a)
                a.hasOwnProperty(c) && (b[c] = a[c]);
        return b
    }
    ;
    Fu = function(a) {
        var b = location.hash;
        a = new RegExp("[&#]" + a + "=([^&]*)");
        b = decodeURIComponent(b);
        b = a.exec(b);
        return null == b ? "" : b[1].replace(/\+/g, " ")
    }
    ;
    Gu = function(a, b, c) {
        if (a.addEventListener)
            a.addEventListener(b, c, !1);
        else if (a.attachEvent)
            a.attachEvent("on" + b, c);
        else
            throw Error("P`" + b);
    }
    ;
    Hu = {
        token: 1,
        id_token: 1
    };
    Iu = function() {
        var a = navigator.userAgent.toLowerCase();
        return -1 != a.indexOf("msie") && 8 == parseInt(a.split("msie")[1], 10)
    }
    ;
    _.Ju = window.JSON;
    Ku = function(a) {
        this.cI = a || [];
        this.Ub = {}
    }
    ;
    Ku.prototype.addEventListener = function(a, b) {
        if (!(0 <= Bu(this.cI, a)))
            throw Error("R`" + a);
        if (!Du(b))
            throw Error("S`" + a);
        this.Ub[a] || (this.Ub[a] = []);
        0 > Bu(this.Ub[a], b) && this.Ub[a].push(b)
    }
    ;
    Ku.prototype.removeEventListener = function(a, b) {
        if (!(0 <= Bu(this.cI, a)))
            throw Error("R`" + a);
        Du(b) && this.Ub[a] && this.Ub[a].length && (b = Bu(this.Ub[a], b),
        0 <= b && this.Ub[a].splice(b, 1))
    }
    ;
    Ku.prototype.dispatchEvent = function(a) {
        var b = a.type;
        if (!(b && 0 <= Bu(this.cI, b)))
            throw Error("T`" + b);
        if (this.Ub[b] && this.Ub[b].length)
            for (var c = 0, d = this.Ub[b].length; c < d; c++)
                this.Ub[b][c](a)
    }
    ;
    var Lu, Mu, Nu, Ru, Su, iv, jv, lv, mv, ov, xv;
    Lu = {};
    Mu = {};
    Nu = {
        google: {
            authServerUrl: "https://accounts.google.com/o/oauth2/auth",
            idpIFrameUrl: "https://accounts.google.com/o/oauth2/iframe"
        }
    };
    _.Ou = function(a, b) {
        if (a = Nu[a])
            return a[b]
    }
    ;
    _.Pu = function(a, b) {
        if (!a)
            throw Error("U");
        if (!b.authServerUrl)
            throw Error("V");
        if (!b.idpIFrameUrl)
            throw Error("W");
        Nu[a] = {
            authServerUrl: b.authServerUrl,
            idpIFrameUrl: b.idpIFrameUrl
        }
    }
    ;
    _.Qu = void 0;
    Ru = function(a) {
        a.style.position = "absolute";
        a.style.width = "1px";
        a.style.height = "1px";
        a.style.left = "-9999px";
        a.style.top = "-9999px";
        a.style.right = "-9999px";
        a.style.bottom = "-9999px";
        a.style.display = "none";
        a.setAttribute("aria-hidden", "true")
    }
    ;
    Su = function() {
        this.B4 = window;
        this.$u = this.Il = this.Is = this.th = null
    }
    ;
    Su.prototype.open = function(a, b, c, d) {
        Tu(this);
        this.Is ? (this.Il && (this.Il(),
        this.Il = null),
        Uu(this)) : this.Is = "authPopup" + Math.floor(1E6 * Math.random() + 1);
        a: {
            this.th = this.B4.open(a, this.Is, b);
            try {
                this.th.focus();
                if (this.th.closed || "undefined" == typeof this.th.closed)
                    throw Error("Y");
                _.Qu = this.th
            } catch (e) {
                d && setTimeout(d, 0);
                this.th = null;
                break a
            }
            c && (this.Il = c,
            Vu(this))
        }
    }
    ;
    var Tu = function(a) {
        try {
            if (null == a.th || a.th.closed)
                a.th = null,
                a.Is = null,
                Uu(a),
                a.Il && (a.Il(),
                a.Il = null)
        } catch (b) {
            a.th = null,
            a.Is = null,
            Uu(a)
        }
    }
      , Vu = function(a) {
        a.$u = window.setInterval(function() {
            Tu(a)
        }, 300)
    }
      , Uu = function(a) {
        a.$u && (window.clearInterval(a.$u),
        a.$u = null)
    };
    Mu = Mu || {};
    var Wu = function(a, b) {
        this.Nb = a;
        this.CD = b;
        this.Zc = null;
        this.om = !1
    };
    Wu.prototype.start = function() {
        if (!this.om && !this.Zc) {
            var a = this;
            this.Zc = window.setTimeout(function() {
                a.clear();
                a.om || (a.Nb(),
                a.om = !0)
            }, Mu.pM(this.CD))
        }
    }
    ;
    Wu.prototype.clear = function() {
        this.Zc && (window.clearTimeout(this.Zc),
        this.Zc = null)
    }
    ;
    var Xu = function(a, b) {
        var c = Mu.qq;
        this.uZ = Mu.jq;
        this.XR = c;
        this.Nb = a;
        this.CD = b;
        this.Zc = null;
        this.om = !1;
        var d = this;
        this.YR = function() {
            document[d.uZ] || (d.clear(),
            d.start())
        }
    };
    Xu.prototype.start = function() {
        if (!this.om && !this.Zc) {
            Gu(document, this.XR, this.YR);
            var a = this;
            this.Zc = window.setTimeout(function() {
                a.clear();
                a.om || (a.Nb(),
                a.om = !0)
            }, Mu.pM(this.CD))
        }
    }
    ;
    Xu.prototype.clear = function() {
        var a = this.XR
          , b = this.YR
          , c = document;
        if (c.removeEventListener)
            c.removeEventListener(a, b, !1);
        else if (c.detachEvent)
            c.detachEvent("on" + a, b);
        else
            throw Error("Q`" + a);
        this.Zc && (window.clearTimeout(this.Zc),
        this.Zc = null)
    }
    ;
    Mu.jq = null;
    Mu.qq = null;
    Mu.QZ = function() {
        var a = document;
        "undefined" !== typeof a.hidden ? (Mu.jq = "hidden",
        Mu.qq = "visibilitychange") : "undefined" !== typeof a.msHidden ? (Mu.jq = "msHidden",
        Mu.qq = "msvisibilitychange") : "undefined" !== typeof a.webkitHidden && (Mu.jq = "webkitHidden",
        Mu.qq = "webkitvisibilitychange")
    }
    ;
    Mu.QZ();
    Mu.DV = function(a, b) {
        return Mu.jq && Mu.qq ? new Xu(a,b) : new Wu(a,b)
    }
    ;
    Mu.pM = function(a) {
        return Math.max(1, a - (new Date).getTime())
    }
    ;
    var Yu = function(a, b) {
        document.cookie = "G_ENABLED_IDPS=" + a + ";domain=." + b + ";expires=Fri, 31 Dec 9999 12:00:00 GMT;path=/"
    }
      , Zu = function() {
        function a() {
            e[0] = 1732584193;
            e[1] = 4023233417;
            e[2] = 2562383102;
            e[3] = 271733878;
            e[4] = 3285377520;
            n = m = 0
        }
        function b(q) {
            for (var p = h, t = 0; 64 > t; t += 4)
                p[t / 4] = q[t] << 24 | q[t + 1] << 16 | q[t + 2] << 8 | q[t + 3];
            for (t = 16; 80 > t; t++)
                q = p[t - 3] ^ p[t - 8] ^ p[t - 14] ^ p[t - 16],
                p[t] = (q << 1 | q >>> 31) & 4294967295;
            q = e[0];
            var v = e[1]
              , u = e[2]
              , w = e[3]
              , z = e[4];
            for (t = 0; 80 > t; t++) {
                if (40 > t)
                    if (20 > t) {
                        var E = w ^ v & (u ^ w);
                        var A = 1518500249
                    } else
                        E = v ^ u ^ w,
                        A = 1859775393;
                else
                    60 > t ? (E = v & u | w & (v | u),
                    A = 2400959708) : (E = v ^ u ^ w,
                    A = 3395469782);
                E = ((q << 5 | q >>> 27) & 4294967295) + E + z + A + p[t] & 4294967295;
                z = w;
                w = u;
                u = (v << 30 | v >>> 2) & 4294967295;
                v = q;
                q = E
            }
            e[0] = e[0] + q & 4294967295;
            e[1] = e[1] + v & 4294967295;
            e[2] = e[2] + u & 4294967295;
            e[3] = e[3] + w & 4294967295;
            e[4] = e[4] + z & 4294967295
        }
        function c(q, p) {
            if ("string" === typeof q) {
                q = unescape(encodeURIComponent(q));
                for (var t = [], v = 0, u = q.length; v < u; ++v)
                    t.push(q.charCodeAt(v));
                q = t
            }
            p || (p = q.length);
            t = 0;
            if (0 == m)
                for (; t + 64 < p; )
                    b(q.slice(t, t + 64)),
                    t += 64,
                    n += 64;
            for (; t < p; )
                if (f[m++] = q[t++],
                n++,
                64 == m)
                    for (m = 0,
                    b(f); t + 64 < p; )
                        b(q.slice(t, t + 64)),
                        t += 64,
                        n += 64
        }
        function d() {
            var q = []
              , p = 8 * n;
            56 > m ? c(k, 56 - m) : c(k, 64 - (m - 56));
            for (var t = 63; 56 <= t; t--)
                f[t] = p & 255,
                p >>>= 8;
            b(f);
            for (t = p = 0; 5 > t; t++)
                for (var v = 24; 0 <= v; v -= 8)
                    q[p++] = e[t] >> v & 255;
            return q
        }
        for (var e = [], f = [], h = [], k = [128], l = 1; 64 > l; ++l)
            k[l] = 0;
        var m, n;
        a();
        return {
            reset: a,
            update: c,
            digest: d,
            Ih: function() {
                for (var q = d(), p = "", t = 0; t < q.length; t++)
                    p += "0123456789ABCDEF".charAt(Math.floor(q[t] / 16)) + "0123456789ABCDEF".charAt(q[t] % 16);
                return p
            }
        }
    }
      , $u = window.crypto
      , av = !1
      , bv = 0
      , cv = 1
      , dv = 0
      , ev = ""
      , fv = function(a) {
        a = a || window.event;
        var b = a.screenX + a.clientX << 16;
        b += a.screenY + a.clientY;
        b *= (new Date).getTime() % 1E6;
        cv = cv * b % dv;
        if (3 == ++bv)
            if (a = window,
            b = fv,
            a.removeEventListener)
                a.removeEventListener("mousemove", b, !1);
            else if (a.detachEvent)
                a.detachEvent("onmousemove", b);
            else
                throw Error("Q`mousemove");
    }
      , gv = function(a) {
        var b = Zu();
        b.update(a);
        return b.Ih()
    };
    av = !!$u && "function" == typeof $u.getRandomValues;
    av || (dv = 1E6 * (screen.width * screen.width + screen.height),
    ev = gv(document.cookie + "|" + document.location + "|" + (new Date).getTime() + "|" + Math.random()),
    Gu(window, "mousemove", fv));
    Lu = Lu || {};
    Lu.IS = "ssIFrame_";
    _.hv = function(a, b, c) {
        c = void 0 === c ? !1 : c;
        this.ub = a;
        if (!this.ub)
            throw Error("Z");
        a = _.Ou(a, "idpIFrameUrl");
        if (!a)
            throw Error("$");
        this.fN = a;
        if (!b)
            throw Error("aa");
        this.kl = b;
        a = this.fN;
        b = document.createElement("a");
        b.setAttribute("href", a);
        a = [b.protocol, "//", b.hostname];
        "http:" == b.protocol && "" != b.port && "0" != b.port && "80" != b.port ? (a.push(":"),
        a.push(b.port)) : "https:" == b.protocol && "" != b.port && "0" != b.port && "443" != b.port && (a.push(":"),
        a.push(b.port));
        this.lD = a.join("");
        this.c2 = [location.protocol, "//", location.host].join("");
        this.Bt = this.kD = this.um = !1;
        this.bN = null;
        this.Qx = [];
        this.jp = [];
        this.Qi = {};
        this.wm = void 0;
        this.Tp = c
    }
    ;
    _.g = _.hv.prototype;
    _.g.show = function() {
        var a = this.wm;
        a.style.position = "fixed";
        a.style.width = "100%";
        a.style.height = "100%";
        a.style.left = "0px";
        a.style.top = "0px";
        a.style.right = "0px";
        a.style.bottom = "0px";
        a.style.display = "block";
        a.style.zIndex = "9999999";
        a.style.overflow = "hidden";
        a.setAttribute("aria-hidden", "false")
    }
    ;
    _.g.Tb = function() {
        Ru(this.wm)
    }
    ;
    _.g.qx = function(a) {
        if (this.um)
            a && a(this);
        else {
            if (!this.wm) {
                var b = Lu.IS + this.ub;
                var c = this.ub;
                var d = location.hostname;
                var e, f = document.cookie.match("(^|;) ?G_ENABLED_IDPS=([^;]*)(;|$)");
                f && 2 < f.length && (e = f[2]);
                (f = e && 0 <= Bu(e.split("|"), c)) ? Yu(e, d) : Yu(e ? e + "|" + c : c, d);
                c = !f;
                var h = this.fN
                  , k = this.c2;
                d = this.kl;
                e = this.Tp;
                e = void 0 === e ? !1 : e;
                f = document.createElement("iframe");
                f.setAttribute("id", b);
                b = "allow-scripts allow-same-origin";
                document.requestStorageAccess && Du(document.requestStorageAccess) && (b += " allow-storage-access-by-user-activation");
                f.setAttribute("sandbox", b);
                Ru(f);
                f.setAttribute("frame-border", "0");
                b = [h, "#origin=", encodeURIComponent(k)];
                b.push("&rpcToken=");
                b.push(encodeURIComponent(d));
                c && b.push("&clearCache=1");
                _.zu && b.push("&debug=1");
                e && b.push("&supportBlocked3PCookies=1");
                document.body.appendChild(f);
                f.setAttribute("src", b.join(""));
                this.wm = f
            }
            a && this.Qx.push(a)
        }
    }
    ;
    _.g.bx = function() {
        return this.um && this.Bt
    }
    ;
    _.g.Yl = function() {
        return this.bN
    }
    ;
    iv = function(a) {
        for (var b = 0; b < a.Qx.length; b++)
            a.Qx[b](a);
        a.Qx = []
    }
    ;
    _.kv = function(a, b, c, d) {
        if (a.um) {
            if (a.um && a.kD)
                throw a = "Failed to communicate with IDP IFrame due to unitialization error: " + a.Yl(),
                Au(a),
                Error(a);
            jv(a, {
                method: b,
                params: c
            }, d)
        } else
            a.jp.push({
                Vm: {
                    method: b,
                    params: c
                },
                callback: d
            }),
            a.qx()
    }
    ;
    jv = function(a, b, c) {
        if (c) {
            for (var d = b.id; !d || a.Qi[d]; )
                d = (new Date).getMilliseconds() + "-" + (1E6 * Math.random() + 1);
            b.id = d;
            a.Qi[d] = c
        }
        b.rpcToken = a.kl;
        a.wm.contentWindow.postMessage(_.Ju.stringify(b), a.lD)
    }
    ;
    lv = function(a) {
        if (a && 0 <= a.indexOf("::"))
            throw Error("ba");
    }
    ;
    _.hv.prototype.ki = function(a, b, c, d, e, f, h, k, l) {
        l = void 0 === l ? !1 : l;
        lv(f);
        b = _.Eu(b);
        _.kv(this, "getTokenResponse", {
            clientId: a,
            loginHint: c,
            request: b,
            sessionSelector: d,
            forceRefresh: h,
            skipCache: k,
            id: f,
            userInteracted: l
        }, e)
    }
    ;
    _.hv.prototype.px = function(a, b, c, d, e) {
        b = _.Eu(b);
        _.kv(this, "listIdpSessions", {
            clientId: a,
            request: b,
            sessionSelector: c,
            forceRefresh: e
        }, d)
    }
    ;
    mv = function(a, b, c) {
        lv(b.identifier);
        _.kv(a, "getSessionSelector", b, c)
    }
    ;
    _.nv = function(a, b, c, d, e) {
        lv(b.identifier);
        _.kv(a, "setSessionSelector", {
            domain: b.domain,
            crossSubDomains: b.crossSubDomains,
            policy: b.policy,
            id: b.id,
            hint: d,
            disabled: !!c
        }, e)
    }
    ;
    ov = function(a, b, c) {
        _.kv(a, "monitorClient", {
            clientId: b
        }, c)
    }
    ;
    _.hv.prototype.revoke = _.ea(9);
    _.hv.prototype.Gq = _.ea(11);
    Lu.Fw = {};
    Lu.oC = function(a) {
        return Lu.Fw[a]
    }
    ;
    Lu.qx = function(a, b, c) {
        c = void 0 === c ? !1 : c;
        var d = Lu.oC(a);
        if (!d) {
            d = String;
            if (av) {
                var e = new window.Uint32Array(1);
                $u.getRandomValues(e);
                e = Number("0." + e[0])
            } else
                e = cv,
                e += parseInt(ev.substr(0, 20), 16),
                ev = gv(ev),
                e /= dv + Math.pow(16, 20);
            d = new _.hv(a,d(2147483647 * e),c);
            Lu.Fw[a] = d
        }
        d.qx(b)
    }
    ;
    Lu.aX = function(a) {
        for (var b in Lu.Fw) {
            var c = Lu.oC(b);
            if (c && c.wm && c.wm.contentWindow == a.source && c.lD == a.origin)
                return c
        }
    }
    ;
    Lu.FX = function(a) {
        for (var b in Lu.Fw) {
            var c = Lu.oC(b);
            if (c && c.lD == a)
                return c
        }
    }
    ;
    Lu = Lu || {};
    var qv = function() {
        var a = [], b;
        for (b in pv)
            a.push(pv[b]);
        Ku.call(this, a);
        this.Ik = {};
        Au("EventBus is ready.")
    };
    Cu(qv, Ku);
    var pv = {
        TT: "sessionSelectorChanged",
        tA: "sessionStateChanged",
        bA: "authResult",
        wS: "displayIFrame"
    }
      , sv = function(a) {
        var b = rv;
        a && (b.Ik[a] || (b.Ik[a] = []))
    }
      , tv = function(a, b, c) {
        return b && a.Ik[b] && 0 <= Bu(a.Ik[b], c)
    };
    _.g = qv.prototype;
    _.g.g1 = function(a) {
        var b, c = !!a.source && (a.source.opener === window || a.source === _.Qu);
        if (b = c ? Lu.FX(a.origin) : Lu.aX(a)) {
            try {
                var d = _.Ju.parse(a.data)
            } catch (e) {
                Au("Bad event, an error happened when parsing data.");
                return
            }
            if (!c) {
                if (!d || !d.rpcToken || d.rpcToken != b.kl) {
                    Au("Bad event, no RPC token.");
                    return
                }
                if (d.id && !d.method) {
                    c = d;
                    if (a = b.Qi[c.id])
                        delete b.Qi[c.id],
                        a(c.result, c.error);
                    return
                }
            }
            "fireIdpEvent" != d.method ? Au("Bad IDP event, method unknown.") : (a = d.params) && a.type && this.eN[a.type] ? (d = this.eN[a.type],
            c && !d.CU ? Au("Bad IDP event. Source window cannot be a popup.") : d.$p && !d.$p.call(this, b, a) ? Au("Bad IDP event.") : d.Xe.call(this, b, a)) : Au("Bad IDP event.")
        } else
            Au("Bad event, no corresponding Idp Stub.")
    }
    ;
    _.g.E2 = function(a, b) {
        return tv(this, a.ub, b.clientId)
    }
    ;
    _.g.D2 = function(a, b) {
        b = b.clientId;
        return !b || tv(this, a.ub, b)
    }
    ;
    _.g.MU = function(a, b) {
        return tv(this, a.ub, b.clientId)
    }
    ;
    _.g.v0 = function(a, b) {
        a.um = !0;
        a.Bt = !!b.cookieDisabled;
        iv(a);
        for (b = 0; b < a.jp.length; b++)
            jv(a, a.jp[b].Vm, a.jp[b].callback);
        a.jp = []
    }
    ;
    _.g.u0 = function(a, b) {
        b = {
            error: b.error
        };
        a.um = !0;
        a.kD = !0;
        a.bN = b;
        a.jp = [];
        iv(a)
    }
    ;
    _.g.vy = function(a, b) {
        b.originIdp = a.ub;
        this.dispatchEvent(b)
    }
    ;
    var rv = new qv
      , uv = rv
      , vv = {};
    vv.idpReady = {
        Xe: uv.v0
    };
    vv.idpError = {
        Xe: uv.u0
    };
    vv.sessionStateChanged = {
        Xe: uv.vy,
        $p: uv.E2
    };
    vv.sessionSelectorChanged = {
        Xe: uv.vy,
        $p: uv.D2
    };
    vv.authResult = {
        Xe: uv.vy,
        $p: uv.MU,
        CU: !0
    };
    vv.displayIFrame = {
        Xe: uv.vy
    };
    rv.eN = vv || {};
    Gu(window, "message", function(a) {
        rv.g1.call(rv, a)
    });
    _.wv = function(a, b) {
        this.ke = !1;
        if (!a)
            throw Error("ca");
        var c = [], d;
        for (d in a)
            c.push(a[d]);
        Ku.call(this, c);
        this.zd = [location.protocol, "//", location.host].join("");
        this.Vd = b.crossSubDomains ? b.domain || this.zd : this.zd;
        if (!b)
            throw Error("da");
        if (!b.idpId)
            throw Error("ea");
        if (!_.Ou(b.idpId, "authServerUrl") || !_.Ou(b.idpId, "idpIFrameUrl"))
            throw Error("fa`" + b.idpId);
        this.ub = b.idpId;
        this.Sb = void 0;
        this.LV = !!b.disableTokenRefresh;
        this.AW = !!b.forceTokenRefresh;
        this.D3 = !!b.skipTokenCache;
        this.Tp = !!b.supportBlocked3PCookies;
        this.setOptions(b);
        this.Pq = [];
        this.Bt = this.zm = this.LN = !1;
        this.Ko = void 0;
        this.IP();
        this.vd = void 0;
        var e = this
          , f = function() {
            Au("Token Manager is ready.");
            if (e.Pq.length)
                for (var h = 0; h < e.Pq.length; h++)
                    e.Pq[h].call(e);
            e.LN = !0;
            e.Pq = []
        };
        Lu.qx(this.ub, function(h) {
            e.vd = h;
            h.um && h.kD ? (e.zm = !0,
            e.Ko = h.Yl(),
            e.Mx(e.Ko)) : (e.Bt = h.bx(),
            e.Sb ? ov(e.vd, e.Sb, function(k) {
                if (k) {
                    k = e.ub;
                    var l = e.Sb
                      , m = rv;
                    k && l && (m.Ik[k] || (m.Ik[k] = []),
                    0 > Bu(m.Ik[k], l) && m.Ik[k].push(l));
                    f()
                } else
                    e.Ko = {
                        error: "Not a valid origin for the client: " + e.zd + " has not been registered for client ID " + e.Sb + ". Please go to https://console.developers.google.com/ and register this origin for your project's client ID."
                    },
                    e.zm = !0,
                    e.Mx(e.Ko)
            }) : (sv(e.ub),
            f()))
        }, this.Tp)
    }
    ;
    Cu(_.wv, Ku);
    _.g = _.wv.prototype;
    _.g.setOptions = function() {}
    ;
    _.g.IP = function() {}
    ;
    _.g.Mx = function() {}
    ;
    _.g.bx = function() {
        return this.Bt
    }
    ;
    _.g.Yl = function() {
        return this.Ko
    }
    ;
    xv = function(a, b, c) {
        return function() {
            b.apply(a, c)
        }
    }
    ;
    _.yv = function(a, b, c) {
        if (a.LN)
            b.apply(a, c);
        else {
            if (a.zm)
                throw a.Ko;
            a.Pq.push(xv(a, b, c))
        }
    }
    ;
    _.wv.prototype.ZJ = _.ea(12);
    _.wv.prototype.Gq = _.ea(10);
    _.Av = function(a, b) {
        _.wv.call(this, a, b);
        this.rP = new Su;
        this.vj = this.Mm = null;
        zv(this)
    }
    ;
    Cu(_.Av, _.wv);
    _.Av.prototype.setOptions = function() {}
    ;
    var Bv = function(a, b) {
        a.ie = {
            crossSubDomains: !!b.crossSubDomains,
            id: b.sessionSelectorId,
            domain: a.Vd
        };
        b.crossSubDomains && (a.ie.policy = b.policy)
    }
      , Cv = function(a, b) {
        if (!b.authParameters)
            throw Error("ga");
        if (!b.authParameters.scope)
            throw Error("ha");
        if (!b.authParameters.response_type)
            throw Error("ia");
        a.wq = b.authParameters;
        a.wq.redirect_uri || (a.wq.redirect_uri = [location.protocol, "//", location.host, location.pathname].join(""));
        a.xi = _.Eu(b.rpcAuthParameters || a.wq);
        if (!a.xi.scope)
            throw Error("ja");
        if (!a.xi.response_type)
            throw Error("ka");
        a: {
            var c = a.xi.response_type.split(" ");
            for (var d = 0, e = c.length; d < e; d++)
                if (c[d] && !Hu[c[d]]) {
                    c = !0;
                    break a
                }
            c = !1
        }
        if (c)
            throw Error("la");
        b.enableSerialConsent && (a.xi.enable_serial_consent = !0);
        b.authResultIdentifier && (a.NU = b.authResultIdentifier);
        b.spec_compliant && (a.xi.spec_compliant = b.spec_compliant)
    };
    _.Av.prototype.IP = function() {
        var a = this;
        rv.addEventListener(pv.TT, function(b) {
            a.ke && a.ie && b.originIdp == a.ub && !b.crossSubDomains == !a.ie.crossSubDomains && b.domain == a.ie.domain && b.id == a.ie.id && a.ZO(b)
        });
        rv.addEventListener(pv.tA, function(b) {
            a.ke && b.originIdp == a.ub && b.clientId == a.Sb && a.$O(b)
        });
        rv.addEventListener(pv.bA, function(b) {
            _.Qu = void 0;
            a.ke && b.originIdp == a.ub && b.clientId == a.Sb && b.id == a.sj && (a.Mm && (window.clearTimeout(a.Mm),
            a.Mm = null),
            a.sj = void 0,
            a.ws(b))
        });
        rv.addEventListener(pv.wS, function(b) {
            a.ke && b.originIdp == a.ub && (b.Tb ? a.vd.Tb() : a.vd.show())
        })
    }
    ;
    _.Av.prototype.ZO = function() {}
    ;
    _.Av.prototype.$O = function() {}
    ;
    _.Av.prototype.ws = function() {}
    ;
    var Ev = function(a, b) {
        Dv(a);
        a.LV || (a.vj = Mu.DV(function() {
            a.ki(!0)
        }, b - 3E5),
        navigator.onLine && a.vj.start())
    }
      , Dv = function(a) {
        a.vj && (a.vj.clear(),
        a.vj = null)
    }
      , zv = function(a) {
        var b = window;
        Iu() && (b = document.body);
        Gu(b, "online", function() {
            a.vj && a.vj.start()
        });
        Gu(b, "offline", function() {
            a.vj && a.vj.clear()
        })
    };
    _.Av.prototype.ki = function() {}
    ;
    _.Av.prototype.FO = _.ea(13);
    _.Av.prototype.v_ = function(a, b) {
        if (!this.Sb)
            throw Error("pa");
        this.vd.px(this.Sb, this.xi, this.ie, a, b)
    }
    ;
    _.Av.prototype.px = function(a, b) {
        _.yv(this, this.v_, [a, b])
    }
    ;
    _.Gv = function(a) {
        this.ee = void 0;
        this.Rg = !1;
        this.Ap = void 0;
        _.Av.call(this, _.Fv, a)
    }
    ;
    Cu(_.Gv, _.Av);
    _.Fv = {
        JI: "noSessionBound",
        pq: "userLoggedOut",
        hS: "activeSessionChanged",
        tA: "sessionStateChanged",
        fJ: "tokenReady",
        eU: "tokenFailed",
        bA: "authResult",
        ERROR: "error"
    };
    _.Gv.prototype.setOptions = function(a) {
        if (!a.clientId)
            throw Error("qa");
        this.Sb = a.clientId;
        this.Ba = a.id;
        Bv(this, a);
        Cv(this, a)
    }
    ;
    _.Gv.prototype.Mx = function(a) {
        this.dispatchEvent({
            type: _.Fv.ERROR,
            error: "idpiframe_initialization_failed",
            details: a.error,
            idpId: this.ub
        })
    }
    ;
    var Hv = function(a) {
        Dv(a);
        a.Ap = void 0;
        a.lx = void 0
    };
    _.g = _.Gv.prototype;
    _.g.ZO = function(a) {
        var b = a.newValue || {};
        if (this.ee != b.hint || this.Rg != !!b.disabled) {
            a = this.ee;
            var c = !this.ee || this.Rg;
            Hv(this);
            this.ee = b.hint;
            this.Rg = !!b.disabled;
            (b = !this.ee || this.Rg) && !c ? this.dispatchEvent({
                type: _.Fv.pq,
                idpId: this.ub
            }) : b || (a != this.ee && this.dispatchEvent({
                type: _.Fv.hS,
                idpId: this.ub
            }),
            this.ee && this.ki())
        }
    }
    ;
    _.g.$O = function(a) {
        this.Rg || (this.ee ? a.user || this.Ap ? a.user == this.ee && (this.Ap ? a.sessionState ? this.Ap = a.sessionState : (Hv(this),
        this.dispatchEvent({
            type: _.Fv.pq,
            idpId: this.ub
        })) : a.sessionState && (this.Ap = a.sessionState,
        this.ki())) : this.ki() : this.dispatchEvent({
            type: _.Fv.tA,
            idpId: this.ub
        }))
    }
    ;
    _.g.ws = function(a) {
        this.dispatchEvent({
            type: _.Fv.bA,
            authResult: a.authResult
        })
    }
    ;
    _.g.tr = _.ea(15);
    _.g.kr = function(a) {
        _.yv(this, this.eC, [a])
    }
    ;
    _.g.eC = function(a) {
        mv(this.vd, this.ie, a)
    }
    ;
    _.g.Az = function(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        if (!a)
            throw Error("ra");
        Hv(this);
        this.ee = a;
        this.Rg = !1;
        b && _.nv(this.vd, this.ie, !1, this.ee);
        this.ke = !0;
        this.ki(c, !0, d)
    }
    ;
    _.g.start = function() {
        _.yv(this, this.J3, [])
    }
    ;
    _.g.J3 = function() {
        var a = this.Sb == Fu("client_id") ? Fu("login_hint") : void 0;
        var b = this.Sb == Fu("client_id") ? Fu("state") : void 0;
        this.nE = b;
        if (a)
            window.history.replaceState ? window.history.replaceState(null, document.title, window.location.href.split("#")[0]) : window.location.href.hash = "",
            this.Az(a, !0, !0, !0);
        else {
            var c = this;
            this.kr(function(d) {
                c.ke = !0;
                d && d.hint ? (Hv(c),
                c.ee = d.hint,
                c.Rg = !!d.disabled,
                c.Rg ? c.dispatchEvent({
                    type: _.Fv.pq,
                    idpId: c.ub
                }) : c.Az(d.hint)) : (Hv(c),
                c.ee = void 0,
                c.Rg = !(!d || !d.disabled),
                c.dispatchEvent({
                    type: _.Fv.JI,
                    autoOpenAuthUrl: !c.Rg,
                    idpId: c.ub
                }))
            })
        }
    }
    ;
    _.g.xW = function() {
        var a = this;
        this.kr(function(b) {
            b && b.hint ? b.disabled ? a.dispatchEvent({
                type: _.Fv.pq,
                idpId: a.ub
            }) : a.ki(!0) : a.dispatchEvent({
                type: _.Fv.JI,
                idpId: a.ub
            })
        })
    }
    ;
    _.g.AL = function() {
        _.yv(this, this.xW, [])
    }
    ;
    _.g.ki = function(a, b, c) {
        var d = this;
        this.vd.ki(this.Sb, this.xi, this.ee, this.ie, function(e, f) {
            (f = f || e.error) ? "user_logged_out" == f ? (Hv(d),
            d.dispatchEvent({
                type: _.Fv.pq,
                idpId: d.ub
            })) : (d.lx = null,
            d.dispatchEvent({
                type: _.Fv.eU,
                idpId: d.ub,
                error: f
            })) : (d.lx = e,
            d.Ap = e.session_state,
            Ev(d, e.expires_at),
            e.idpId = d.ub,
            b && d.nE && (e.state = d.nE,
            d.nE = void 0),
            d.dispatchEvent({
                type: _.Fv.fJ,
                idpId: d.ub,
                response: e
            }))
        }, this.Ba, a, !1, void 0 === c ? !1 : c)
    }
    ;
    _.g.revoke = _.ea(8);
    _.g.YP = _.ea(16);
    _.Iv = function(a) {
        this.Al = null;
        _.Av.call(this, {}, a);
        this.ke = !0
    }
    ;
    Cu(_.Iv, _.Av);
    _.g = _.Iv.prototype;
    _.g.setOptions = function(a) {
        if (!a.clientId)
            throw Error("qa");
        this.Sb = a.clientId;
        this.Ba = a.id;
        Bv(this, a);
        Cv(this, a)
    }
    ;
    _.g.Mx = function(a) {
        this.Al && (this.Al({
            authResult: {
                error: "idpiframe_initialization_failed",
                details: a.error
            }
        }),
        this.Al = null)
    }
    ;
    _.g.ws = function(a) {
        if (this.Al) {
            var b = this.Al;
            this.Al = null;
            b(a)
        }
    }
    ;
    _.g.tr = _.ea(14);
    _.g.kr = function(a) {
        this.zm ? a(this.Yl()) : _.yv(this, this.eC, [a])
    }
    ;
    _.g.eC = function(a) {
        mv(this.vd, this.ie, a)
    }
    ;
    _.Jv = function(a, b, c) {
        a.zm ? c(a.Yl()) : _.yv(a, a.I0, [b, c])
    }
    ;
    _.Iv.prototype.I0 = function(a, b) {
        this.vd.ki(this.Sb, this.xi, a, this.ie, function(c, d) {
            d ? b({
                error: d
            }) : b(c)
        }, this.Ba, this.AW, this.D3)
    }
    ;
    _.Iv.prototype.hO = _.ea(17);

    var Kv = function(a) {
        return Array.prototype.concat.apply([], arguments)
    }, Lv = function() {
        try {
            var a = Array.from((window.crypto || window.msCrypto).getRandomValues(new Uint8Array(64)))
        } catch (c) {
            a = [];
            for (var b = 0; 64 > b; b++)
                a[b] = Math.floor(256 * Math.random())
        }
        return _.kh(a, 3).substring(0, 64)
    }, Mv = function() {
        var a = navigator.userAgent.toLowerCase();
        return 0 > a.indexOf("edge/") && (-1 < a.indexOf("chrome/") || -1 < a.indexOf("crios/"))
    }, Nv = function() {
        var a = navigator.userAgent.toLowerCase();
        return -1 < a.indexOf("firefox/") && 0 > a.indexOf("chrome/") && 0 > a.indexOf("crios/") && 0 > a.indexOf("safari/")
    }, Ov = function(a, b, c) {
        if (!a.ke)
            throw Error("ma");
        b ? _.nv(a.vd, a.ie, !0, void 0, c) : _.nv(a.vd, a.ie, !0, a.ee, c)
    }, Pv = function(a) {
        if (!a.ke)
            throw Error("ma");
        return a.lx
    }, Qv, Rv, Sv, Tv, Uv, Vv, Wv, Xv, Yv, $v;
    _.Iv.prototype.hO = _.cb(17, function(a, b) {
        var c = this.vd
          , d = this.Sb
          , e = this.ie
          , f = _.Eu(this.xi);
        delete f.response_type;
        _.kv(c, "getOnlineCode", {
            clientId: d,
            loginHint: a,
            request: f,
            sessionSelector: e
        }, b)
    });
    _.Gv.prototype.YP = _.cb(16, function(a) {
        Pv(this) && Pv(this).access_token && (this.vd.revoke(this.Sb, Pv(this).access_token, a),
        Ov(this, !0))
    });
    _.Gv.prototype.tr = _.cb(15, function() {
        var a = this;
        return function(b) {
            if (b && b.authResult && b.authResult.login_hint)
                if (a.bx() && a.Tp && (Mv() || Nv())) {
                    b = b.authResult;
                    var c = Date.now()
                      , d = b.expires_in;
                    b = {
                        access_token: b.access_token,
                        token_type: b.token_type,
                        login_hint: b.login_hint,
                        expires_in: d,
                        id_token: b.id_token,
                        scope: b.scope,
                        first_issued_at: c,
                        expires_at: c + 1E3 * d,
                        idpId: a.ub
                    };
                    a.lx = b;
                    a.dispatchEvent({
                        type: _.Fv.fJ,
                        idpId: a.ub,
                        response: b
                    })
                } else
                    a.Az(b.authResult.login_hint, a.Rg || b.authResult.login_hint != a.ee, !0, !0)
        }
    });
    _.Iv.prototype.tr = _.cb(14, function(a) {
        var b = this;
        return function(c) {
            c && c.authResult && c.authResult.login_hint ? b.kr(function(d) {
                _.nv(b.vd, b.ie, d && d.disabled, c.authResult.login_hint, function() {
                    _.Jv(b, c.authResult.login_hint, a)
                })
            }) : a(c && c.authResult && c.authResult.error ? c.authResult : c && c.authResult && !c.authResult.login_hint ? {
                error: "wrong_response_type"
            } : {
                error: "unknown_error"
            })
        }
    });
    _.Av.prototype.FO = _.cb(13, function() {
        this.Sb && _.kv(this.vd, "startPolling", {
            clientId: this.Sb,
            origin: this.zd,
            id: this.sj
        }, void 0)
    });
    _.hv.prototype.revoke = _.cb(9, function(a, b, c) {
        _.kv(this, "revoke", {
            clientId: a,
            token: b
        }, c)
    });
    _.Gv.prototype.revoke = _.cb(8, function(a) {
        _.yv(this, this.YP, [a])
    });
    Qv = function() {
        var a = navigator.userAgent, b;
        if (b = !!a && -1 != a.indexOf("CriOS"))
            b = -1,
            (a = a.match(/CriOS\/(\d+)/)) && a[1] && (b = parseInt(a[1], 10) || -1),
            b = 48 > b;
        return b
    }
    ;
    Rv = function() {
        var a = navigator.userAgent.toLowerCase();
        if (!(-1 < a.indexOf("safari/") && 0 > a.indexOf("chrome/") && 0 > a.indexOf("crios/") && 0 > a.indexOf("android")))
            return !1;
        var b = RegExp("version/(\\d+)\\.(\\d+)[\\.0-9]*").exec(navigator.userAgent.toLowerCase());
        if (!b || 3 > b.length)
            return !1;
        a = parseInt(b[1], 10);
        b = parseInt(b[2], 10);
        return 12 < a || 12 == a && 1 <= b
    }
    ;
    Sv = function(a, b, c, d, e, f, h) {
        var k = _.Ou(a, "authServerUrl");
        if (!k)
            throw Error("X`" + a);
        a = _.Eu(d);
        a.response_type = h || "permission";
        a.client_id = c;
        a.ss_domain = b;
        if (f && f.extraQueryParams)
            for (var l in f.extraQueryParams)
                a[l] = f.extraQueryParams[l];
        (b = e) && !(b = Rv()) && (b = navigator.userAgent.toLowerCase(),
        -1 < b.indexOf("ipad;") || -1 < b.indexOf("iphone;") ? (b = RegExp("os (\\d+)_\\d+(_\\d+)? like mac os x").exec(navigator.userAgent.toLowerCase()),
        b = !b || 2 > b.length ? !1 : 14 <= parseInt(b[1], 10)) : b = !1);
        b && !a.prompt && (a.prompt = "select_account");
        k += 0 > k.indexOf("?") ? "?" : "&";
        b = [];
        for (var m in a)
            if (a.hasOwnProperty(m)) {
                c = a[m];
                if (null === c || void 0 === c)
                    c = "";
                b.push(encodeURIComponent(m) + "=" + encodeURIComponent(c))
            }
        return k + b.join("&")
    }
    ;
    Tv = function(a, b, c, d) {
        if (!a.Sb)
            throw Error("na");
        a.sj = c || a.NU || "auth" + Math.floor(1E6 * Math.random() + 1);
        b = b || {};
        b.extraQueryParams = b.extraQueryParams || {};
        if (!b.extraQueryParams.redirect_uri) {
            var e = a.zd.split("//");
            c = b.extraQueryParams;
            var f = e[0]
              , h = f.indexOf(":");
            0 < h && (f = f.substring(0, h));
            e = ["storagerelay://", f, "/", e[1], "?"];
            e.push("id=" + a.sj);
            c.redirect_uri = e.join("")
        }
        return Sv(a.ub, a.Vd, a.Sb, a.wq, !0, b, d)
    }
    ;
    Uv = function(a, b, c) {
        if (!a.Sb)
            throw Error("na");
        return Sv(a.ub, a.Vd, a.Sb, a.wq, !1, b, c)
    }
    ;
    Vv = function(a) {
        if (!a)
            return "permission token";
        var b = a.split(" ");
        if (-1 < b.indexOf("token") || -1 < b.indexOf("code") || -1 < b.indexOf("gsession"))
            return a;
        b.push("token");
        return b.join(" ")
    }
    ;
    Wv = function(a, b) {
        a.Mm && window.clearTimeout(a.Mm);
        a.Mm = window.setTimeout(function() {
            a.sj == b && (_.Qu = void 0,
            a.Mm = null,
            a.sj = void 0,
            a.ws({
                authResult: {
                    error: "popup_closed_by_user"
                }
            }))
        }, 1E3)
    }
    ;
    Xv = function(a, b, c) {
        if (!a.Sb)
            throw Error("oa");
        c = c || {};
        a.bx() && a.Tp && (Mv() || Nv()) && (c.responseType = Vv(c.responseType));
        c = Tv(a, c.sessionMeta, c.oneTimeId, c.responseType);
        (Object.hasOwnProperty.call(window, "ActiveXObject") && !window.ActiveXObject || Qv()) && _.yv(a, a.FO, []);
        var d = a.sj;
        a.rP.open(c, b, function() {
            a.sj == d && Wv(a, d)
        }, function() {
            a.sj = void 0;
            a.ws({
                authResult: {
                    error: "popup_blocked_by_browser"
                }
            })
        })
    }
    ;
    Yv = function(a, b, c) {
        a.zm ? c(a.Yl()) : _.yv(a, a.hO, [b, c])
    }
    ;
    _.Zv = function(a) {
        for (var b = [], c = 0, d = 0; c < a.length; ) {
            var e = a[c++];
            if (128 > e)
                b[d++] = String.fromCharCode(e);
            else if (191 < e && 224 > e) {
                var f = a[c++];
                b[d++] = String.fromCharCode((e & 31) << 6 | f & 63)
            } else if (239 < e && 365 > e) {
                f = a[c++];
                var h = a[c++]
                  , k = a[c++];
                e = ((e & 7) << 18 | (f & 63) << 12 | (h & 63) << 6 | k & 63) - 65536;
                b[d++] = String.fromCharCode(55296 + (e >> 10));
                b[d++] = String.fromCharCode(56320 + (e & 1023))
            } else
                f = a[c++],
                h = a[c++],
                b[d++] = String.fromCharCode((e & 15) << 12 | (f & 63) << 6 | h & 63)
        }
        return b.join("")
    }
    ;
    $v = function(a) {
        var b = [];
        _.lh(a, function(c) {
            b.push(c)
        });
        return b
    }
    ;
    _.aw = function(a, b) {
        _.Th[b || "token"] = a
    }
    ;
    _.bw = function(a) {
        delete _.Th[a || "token"]
    }
    ;
    _.Ju = {
        parse: function(a) {
            a = _.xf("[" + String(a) + "]");
            if (!1 === a || 1 !== a.length)
                throw new SyntaxError("JSON parsing failed.");
            return a[0]
        },
        stringify: function(a) {
            return _.yf(a)
        }
    };
    _.Iv.prototype.UB = function(a, b) {
        _.yv(this, this.mW, [a, b])
    }
    ;
    _.Iv.prototype.mW = function(a, b) {
        this.vd.UB(this.Sb, a, this.xi, this.ie, b)
    }
    ;
    _.hv.prototype.UB = function(a, b, c, d, e) {
        c = _.Eu(c);
        _.kv(this, "gsi:fetchLoginHint", {
            clientId: a,
            loginHint: b,
            request: c,
            sessionSelector: d
        }, e)
    }
    ;
    var cw, dw = ["client_id", "cookie_policy", "scope"], ew = "client_id cookie_policy fetch_basic_profile hosted_domain scope openid_realm disable_token_refresh login_hint ux_mode redirect_uri state prompt oidc_spec_compliant nonce enable_serial_consent include_granted_scopes response_type session_selection gsiwebsdk".split(" "), fw = ["authuser", "after_redirect", "access_type", "hl"], gw = ["login_hint", "prompt"], hw = {
        clientid: "client_id",
        cookiepolicy: "cookie_policy"
    }, iw = ["approval_prompt", "authuser", "login_hint", "prompt", "hd"], jw = ["login_hint", "g-oauth-window", "status"], kw = Math.min(_.Ke("oauth-flow/authWindowWidth", 599), screen.width - 20), lw = Math.min(_.Ke("oauth-flow/authWindowHeight", 600), screen.height - 30);
    var mw = function(a) {
        _.jb.call(this, a)
    };
    _.O(mw, _.jb);
    mw.prototype.name = "gapi.auth2.ExternallyVisibleError";
    var nw = function() {};
    nw.prototype.select = function(a, b) {
        if (a.sessions && 1 == a.sessions.length && (a = a.sessions[0],
        a.login_hint)) {
            b(a);
            return
        }
        b()
    }
    ;
    var ow = function() {};
    ow.prototype.select = function(a, b) {
        if (a.sessions && a.sessions.length)
            for (var c = 0; c < a.sessions.length; c++) {
                var d = a.sessions[c];
                if (d.login_hint) {
                    b(d);
                    return
                }
            }
        b()
    }
    ;
    var pw = function(a) {
        this.OU = a
    };
    pw.prototype.select = function(a, b) {
        if (a.sessions)
            for (var c = 0; c < a.sessions.length; c++) {
                var d = a.sessions[c];
                if (d.session_state && d.session_state.extraQueryParams && d.session_state.extraQueryParams.authuser == this.OU) {
                    d.login_hint ? b(d) : b();
                    return
                }
            }
        b()
    }
    ;
    var qw = function(a) {
        this.Sd = a;
        this.Ty = []
    };
    qw.prototype.select = function(a) {
        var b = 0
          , c = this
          , d = function(e) {
            if (e)
                a(e);
            else {
                var f = c.Ty[b];
                f ? (b++,
                c.Sd.px(function(h) {
                    h ? f.select(h, d) : d()
                })) : a()
            }
        };
        d()
    }
    ;
    var rw = function(a) {
        a = new qw(a);
        a.Ty.push(new nw);
        return a
    }
      , sw = function(a) {
        a = new qw(a);
        a.Ty.push(new ow);
        return a
    }
      , tw = function(a, b) {
        void 0 === b || null === b ? b = rw(a) : (a = new qw(a),
        a.Ty.push(new pw(b)),
        b = a);
        return b
    };
    var uw = function(a) {
        this.Xe = a;
        this.Uc = !0
    };
    uw.prototype.remove = function() {
        this.Uc = !1
    }
    ;
    uw.prototype.trigger = function() {}
    ;
    var vw = function(a) {
        this.remove = function() {
            a.remove()
        }
        ;
        this.trigger = function() {
            a.trigger()
        }
    }
      , ww = function() {
        this.Ub = []
    };
    ww.prototype.add = function(a) {
        this.Ub.push(a)
    }
    ;
    ww.prototype.notify = function(a) {
        for (var b = this.Ub, c = [], d = 0; d < b.length; d++) {
            var e = b[d];
            e.Uc && (c.push(e),
            _.vj(xw(e.Xe, a)))
        }
        this.Ub = c
    }
    ;
    var xw = function(a, b) {
        return function() {
            a(b)
        }
    };
    var zw = function(a) {
        this.Mb = null;
        this.v4 = new yw(this);
        this.Ub = new ww;
        void 0 != a && this.set(a)
    };
    zw.prototype.set = function(a) {
        a != this.Mb && (this.Mb = a,
        this.v4.value = a,
        this.Ub.notify(this.Mb))
    }
    ;
    zw.prototype.get = function() {
        return this.Mb
    }
    ;
    zw.prototype.V = function(a) {
        a = new Aw(this,a);
        this.Ub.add(a);
        return a
    }
    ;
    zw.prototype.get = zw.prototype.get;
    var Aw = function(a, b) {
        uw.call(this, b);
        this.y_ = a
    };
    _.O(Aw, uw);
    Aw.prototype.trigger = function() {
        var a = this.Xe;
        a(this.y_.get())
    }
    ;
    var yw = function(a) {
        this.value = null;
        this.V = function(b) {
            return new vw(a.V(b))
        }
    };
    var Bw = {
        T6: "fetch_basic_profile",
        Z7: "login_hint",
        v9: "prompt",
        C9: "redirect_uri",
        U9: "scope",
        laa: "ux_mode",
        I$: "state"
    }
      , Cw = function(a) {
        this.Ia = {};
        if (a && !_.yi(a))
            if ("function" == typeof a.get)
                this.Ia = a.get();
            else
                for (var b in Bw) {
                    var c = Bw[b];
                    c in a && (this.Ia[c] = a[c])
                }
    };
    Cw.prototype.get = function() {
        return this.Ia
    }
    ;
    Cw.prototype.QQ = function(a) {
        this.Ia.scope = a;
        return this
    }
    ;
    Cw.prototype.Dr = function() {
        return this.Ia.scope
    }
    ;
    var Dw = function(a, b) {
        var c = a.Ia.scope;
        b = Kv(b.split(" "), c ? c.split(" ") : []);
        _.kj(b);
        a.Ia.scope = b.join(" ")
    };
    _.g = Cw.prototype;
    _.g.h3 = function(a) {
        this.Ia.prompt = a;
        return this
    }
    ;
    _.g.HX = function() {
        return this.Ia.prompt
    }
    ;
    _.g.I2 = function() {
        _.Df.warn("Property app_package_name no longer supported and was not set");
        return this
    }
    ;
    _.g.IW = function() {
        _.Df.warn("Property app_package_name no longer supported")
    }
    ;
    _.g.Ne = function(a) {
        this.Ia.state = a
    }
    ;
    _.g.getState = function() {
        return this.Ia.state
    }
    ;
    var Ew = function() {
        return ["toolbar=no", "location=" + (window.opera ? "no" : "yes"), "directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no", "width=" + kw, "height=" + lw, "top=" + (screen.height - lw) / 2, "left=" + (screen.width - kw) / 2].join()
    }
      , Fw = function(a) {
        a = a && a.id_token;
        if (!a || !a.split(".")[1])
            return null;
        a = (a.split(".")[1] + "...").replace(/^((....)+).?.?.?$/, "$1");
        return JSON.parse(_.Zv($v(a)))
    }
      , Gw = function() {
        cw = _.Ke("auth2/idpValue", "google");
        var a = _.Ke("oauth-flow/authUrl", "https://accounts.google.com/o/oauth2/auth")
          , b = _.Ke("oauth-flow/idpIframeUrl", "https://accounts.google.com/o/oauth2/iframe");
        _.Pu(cw, {
            authServerUrl: a,
            idpIFrameUrl: b
        })
    }
      , Hw = function(a, b, c) {
        for (var d = 0; d < b.length; d++) {
            var e = b[d];
            if (d === b.length - 1) {
                a[e] = c;
                break
            }
            _.Bb(a[e]) || (a[e] = {});
            a = a[e]
        }
    }
      , Iw = function() {
        var a = window.location.origin;
        a || (a = window.location.protocol + "//" + window.location.host);
        return a
    };
    var Jw = function(a) {
        var b = a ? (b = Fw(a)) ? b.sub : null : null;
        this.Ba = b;
        this.wc = a ? _.mj(a) : null
    };
    _.g = Jw.prototype;
    _.g.getId = function() {
        return this.Ba
    }
    ;
    _.g.lC = function() {
        var a = Fw(this.wc);
        return a ? a.hd : null
    }
    ;
    _.g.Kf = function() {
        return !!this.wc
    }
    ;
    _.g.nk = function(a) {
        if (a)
            return this.wc;
        a = Kw;
        var b = _.mj(this.wc);
        !a.Qw || a.fD || a.iZ || (delete b.access_token,
        delete b.scope);
        return b
    }
    ;
    _.g.VE = function() {
        return Kw.VE()
    }
    ;
    _.g.Gj = function() {
        this.wc = null
    }
    ;
    _.g.jX = function() {
        return this.wc ? this.wc.scope : null
    }
    ;
    _.g.update = function(a) {
        this.Ba = a.Ba;
        this.wc = a.wc;
        this.wc.id_token ? this.zu = new Lw(this.wc) : this.zu && (this.zu = null)
    }
    ;
    var Mw = function(a) {
        return a.wc && "object" == typeof a.wc.session_state ? _.mj(a.wc.session_state.extraQueryParams || {}) : {}
    };
    _.g = Jw.prototype;
    _.g.gr = function() {
        var a = Mw(this);
        return a && void 0 !== a.authuser && null !== a.authuser ? a.authuser : null
    }
    ;
    _.g.Fj = function(a) {
        var b = Kw
          , c = new Cw(a);
        b.fD = c.Dr() ? !0 : !1;
        Kw.Qw && Dw(c, "openid profile email");
        return new _.Lj(function(d, e) {
            var f = Mw(this);
            f.login_hint = this.getId();
            f.scope = c.Dr();
            Nw(b, d, e, f)
        }
        ,this)
    }
    ;
    _.g.Fr = function(a) {
        return new _.Lj(function(b, c) {
            var d = a || {}
              , e = Kw;
            d.login_hint = this.getId();
            e.Fr(d).then(b, c)
        }
        ,this)
    }
    ;
    _.g.YX = function(a) {
        return this.Fj(a)
    }
    ;
    _.g.disconnect = function() {
        return Kw.disconnect()
    }
    ;
    _.g.LW = function() {
        return this.zu
    }
    ;
    _.g.Bw = function(a) {
        if (!this.Kf())
            return !1;
        var b = this.wc && this.wc.scope ? this.wc.scope.split(" ") : "";
        return _.Vb(a ? a.split(" ") : [], function(c) {
            return _.lb(b, c)
        })
    }
    ;
    var Lw = function(a) {
        a = Fw(a);
        this.GW = a.sub;
        this.hf = a.name;
        this.VX = a.given_name;
        this.kW = a.family_name;
        this.mN = a.picture;
        this.ov = a.email
    };
    _.g = Lw.prototype;
    _.g.getId = function() {
        return this.GW
    }
    ;
    _.g.fj = function() {
        return this.hf
    }
    ;
    _.g.hX = function() {
        return this.VX
    }
    ;
    _.g.cX = function() {
        return this.kW
    }
    ;
    _.g.pX = function() {
        return this.mN
    }
    ;
    _.g.Kv = function() {
        return this.ov
    }
    ;
    var Ow;
    Ow = function(a) {
        var b = location;
        if (a && "none" != a)
            return "single_host_origin" == a ? b.protocol + "//" + b.host : a
    }
    ;
    _.Pw = function(a) {
        if (!a)
            throw new mw("No cookiePolicy");
        var b = window.location.hostname;
        "single_host_origin" == a && (a = window.location.protocol + "//" + b);
        if ("none" == a)
            return null;
        var c = /^(https?:\/\/)([0-9.\-_A-Za-z]+)(?::(\d+))?$/.exec(a);
        if (!c)
            throw new mw("Invalid cookiePolicy");
        a = c[2];
        c = c[1];
        var d = {};
        d.dotValue = a.split(".").length;
        d.isSecure = -1 != c.indexOf("https");
        d.domain = a;
        if (!_.Ai(b, "." + a) && !_.Ai(b, a))
            throw new mw("Invalid cookiePolicy domain");
        return d
    }
    ;
    var Rw = function(a) {
        var b = a || {}
          , c = Qw();
        _.Sb(ew, function(d) {
            "undefined" === typeof b[d] && "undefined" !== typeof c[d] && (b[d] = c[d])
        });
        return b
    }
      , Qw = function() {
        for (var a = {}, b = document.getElementsByTagName("meta"), c = 0; c < b.length; ++c)
            if (b[c].name) {
                var d = b[c].name;
                if (0 == d.indexOf("google-signin-")) {
                    d = d.substring(14);
                    var e = b[c].content;
                    hw[d] && (d = hw[d]);
                    _.lb(ew, d) && e && (a[d] = "true" == e ? !0 : "false" == e ? !1 : e)
                }
            }
        return a
    }
      , Sw = function(a) {
        return String(a).replace(/_([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }
      , Tw = function(a) {
        _.Sb(ew, function(b) {
            var c = Sw(b);
            "undefined" !== typeof a[c] && "undefined" === typeof a[b] && (a[b] = a[c],
            delete a[c])
        })
    }
      , Uw = function(a) {
        a = Rw(a);
        Tw(a);
        a.cookie_policy || (a.cookie_policy = "single_host_origin");
        var b = ew + fw, c;
        for (c in a)
            0 > b.indexOf(c) && delete a[c];
        return a
    }
      , Vw = function(a, b) {
        if (!a)
            throw new mw("Empty initial options.");
        for (var c = 0; c < dw.length; ++c)
            if (!(b && "scope" == dw[c] || a[dw[c]]))
                throw new mw("Missing required parameter '" + dw[c] + "'");
        _.Pw(a.cookie_policy)
    }
      , Xw = function(a) {
        var b = {
            authParameters: {
                redirect_uri: void 0,
                response_type: "token id_token",
                scope: a.scope,
                "openid.realm": a.openid_realm,
                include_granted_scopes: !0
            },
            clientId: a.client_id,
            crossSubDomains: !0,
            domain: Ow(a.cookie_policy),
            disableTokenRefresh: !!a.disable_token_refresh,
            idpId: cw
        };
        Ww(b, a);
        _.Sb(gw, function(c) {
            a[c] && (b.authParameters[c] = a[c])
        });
        "boolean" == typeof a.enable_serial_consent && (b.enableSerialConsent = a.enable_serial_consent);
        return b
    }
      , Ww = function(a, b) {
        var c = b.oidc_spec_compliant;
        b = b.nonce;
        c && (a.spec_compliant = c,
        b = b || Lv());
        b && (a.authParameters.nonce = b,
        a.forceTokenRefresh = !0,
        a.skipTokenCache = !0)
    }
      , bx = function(a) {
        var b = a.client_id
          , c = a.cookie_policy
          , d = a.scope
          , e = a.openid_realm
          , f = a.hosted_domain
          , h = a.oidc_spec_compliant
          , k = a.nonce
          , l = Yw(a)
          , m = {
            authParameters: {
                response_type: l,
                scope: d,
                "openid.realm": e
            },
            rpcAuthParameters: {
                response_type: l,
                scope: d,
                "openid.realm": e
            },
            clientId: b,
            crossSubDomains: !0,
            domain: Ow(c),
            idpId: cw
        };
        f && (m.authParameters.hd = f,
        m.rpcAuthParameters.hd = f);
        h && (m.rpcAuthParameters.spec_compliant = h,
        k = k || Lv());
        k && (m.authParameters.nonce = k,
        m.rpcAuthParameters.nonce = k,
        m.forceTokenRefresh = !0,
        m.skipTokenCache = !0);
        _.Sb(gw.concat(fw), function(n) {
            a[n] && (m.authParameters[n] = a[n])
        });
        void 0 !== a.authuser && null !== a.authuser && (m.authParameters.authuser = a.authuser);
        "boolean" == typeof a.include_granted_scopes && (b = new Zw(a.response_type || "token"),
        $w(b) && (m.authParameters.include_granted_scopes = a.include_granted_scopes),
        ax(b) && (m.rpcAuthParameters.include_granted_scopes = a.include_granted_scopes,
        !1 === a.include_granted_scopes && (m.forceTokenRefresh = !0,
        m.skipTokenCache = !0)));
        "boolean" == typeof a.enable_serial_consent && (m.enableSerialConsent = a.enable_serial_consent);
        return m
    }
      , Yw = function(a) {
        a = new Zw(a.response_type || "token");
        var b = [];
        ax(a) && b.push("token");
        cx(a, "id_token") && b.push("id_token");
        0 == b.length && (b = ["token", "id_token"]);
        return b.join(" ")
    }
      , dx = ["permission", "id_token"]
      , ex = /(^|[^_])token/
      , Zw = function(a) {
        this.np = [];
        this.yD(a)
    };
    Zw.prototype.yD = function(a) {
        a ? ((0 <= a.indexOf("permission") || a.match(ex)) && this.np.push("permission"),
        0 <= a.indexOf("id_token") && this.np.push("id_token"),
        0 <= a.indexOf("code") && this.np.push("code")) : this.np = dx
    }
    ;
    var $w = function(a) {
        return cx(a, "code")
    }
      , ax = function(a) {
        return cx(a, "permission")
    };
    Zw.prototype.toString = function() {
        return this.np.join(" ")
    }
    ;
    var cx = function(a, b) {
        var c = !1;
        _.Sb(a.np, function(d) {
            d == b && (c = !0)
        });
        return c
    };
    var gx = function(a, b, c) {
        this.Hm = b;
        this.i0 = a;
        for (var d in a)
            a.hasOwnProperty(d) && fx(this, d);
        if (c && c.length)
            for (a = 0; a < c.length; a++)
                this[c[a]] = this.Hm[c[a]]
    }
      , fx = function(a, b) {
        a[b] = function() {
            return a.i0[b].apply(a.Hm, arguments)
        }
    };
    gx.prototype.then = function(a, b, c) {
        var d = this;
        return _.Pj().then(function() {
            return hx(d.Hm, a, b, c)
        })
    }
    ;
    _.pj(gx);
    var Kw, ix, kx;
    Kw = null;
    _.jx = function() {
        return Kw ? ix() : null
    }
    ;
    ix = function() {
        return new gx(kx.prototype,Kw,["currentUser", "isSignedIn"])
    }
    ;
    kx = function(a) {
        delete a.include_granted_scopes;
        this.Ia = Xw(a);
        this.BV = a.cookie_policy;
        this.iZ = !!a.scope;
        (this.Qw = !1 !== a.fetch_basic_profile) && (this.Ia.authParameters.scope = lx(this, "openid profile email"));
        _.Fh.GSI_SUPPORT_BLOCKED_3P_COOKIES && (this.Tp = this.Ia.supportBlocked3PCookies = !0);
        this.Pr = a.hosted_domain;
        this.t4 = a.ux_mode || "popup";
        this.n1 = a.redirect_uri || null;
        this.vD()
    }
    ;
    kx.prototype.vD = function() {
        this.currentUser = new zw(new Jw(null));
        this.isSignedIn = new zw(!1);
        this.Sd = new _.Gv(this.Ia);
        this.Xw = this.Mo = null;
        this.k_ = new _.Lj(function(a, b) {
            this.Mo = a;
            this.Xw = b
        }
        ,this);
        this.Px = {};
        this.Yr = !0;
        mx(this);
        this.Sd.start()
    }
    ;
    var mx = function(a) {
        a.Sd.addEventListener("error", function(b) {
            a.Yr && a.Mo && (a.Yr = !1,
            a.Xw({
                error: b.error,
                details: b.details
            }),
            a.Mo = null,
            a.Xw = null)
        });
        a.Sd.addEventListener("authResult", function(b) {
            b && b.authResult && a.Se(b);
            a.Sd.tr()(b)
        });
        a.Sd.addEventListener("tokenReady", function(b) {
            var c = new Jw(b.response);
            if (a.Pr && a.Pr != c.lC())
                a.Se({
                    type: "tokenFailed",
                    reason: "Account domain does not match hosted_domain specified by gapi.auth2.init.",
                    accountDomain: c.lC(),
                    expectedDomain: a.Pr
                });
            else {
                a.currentUser.get().update(c);
                var d = a.currentUser;
                d.Ub.notify(d.Mb);
                a.isSignedIn.set(!0);
                c = c.gr();
                (d = _.Pw(a.BV)) && c && _.Ih.set(["G_AUTHUSER_", "https:" === window.location.protocol && d.De ? "S" : "H", d.Jh].join(""), c, {
                    domain: d.domain,
                    secure: d.isSecure
                });
                _.aw(b.response);
                a.Se(b)
            }
        });
        a.Sd.addEventListener("noSessionBound", function(b) {
            a.Yr && b.autoOpenAuthUrl ? (a.Yr = !1,
            rw(a.Sd).select(function(c) {
                if (c && c.login_hint) {
                    var d = a.Sd;
                    _.yv(d, d.Az, [c.login_hint, !0])
                } else
                    a.currentUser.set(new Jw(null)),
                    a.isSignedIn.set(!1),
                    _.bw(),
                    a.Se(b)
            })) : (a.currentUser.set(new Jw(null)),
            a.isSignedIn.set(!1),
            _.bw(),
            a.Se(b))
        });
        a.Sd.addEventListener("tokenFailed", function(b) {
            a.Se(b)
        });
        a.Sd.addEventListener("userLoggedOut", function(b) {
            a.currentUser.get().Gj();
            var c = a.currentUser;
            c.Ub.notify(c.Mb);
            a.isSignedIn.set(!1);
            _.bw();
            a.Se(b)
        })
    }
      , hx = function(a, b, c, d) {
        return a.k_.then(function(e) {
            if (b)
                return b(e.WX)
        }, c, d)
    };
    kx.prototype.Se = function(a) {
        if (a) {
            this.Yr = !1;
            var b = a.type || "";
            if (this.Px[b])
                this.Px[b](a);
            this.Mo && (this.Mo({
                WX: this
            }),
            this.Xw = this.Mo = null)
        }
    }
    ;
    var nx = function(a, b) {
        _.nb(b, function(c, d) {
            a.Px[d] = function(e) {
                a.Px = {};
                c(e)
            }
        })
    }
      , Nw = function(a, b, c, d) {
        d = _.mj(d);
        a.Pr && (d.hd = a.Pr);
        var e = d.ux_mode || a.t4;
        delete d.ux_mode;
        delete d.app_package_name;
        var f = {
            sessionMeta: {
                extraQueryParams: d
            },
            responseType: "permission id_token"
        };
        "redirect" == e ? (d.redirect_uri || (d.redirect_uri = a.n1 || Iw() + window.location.pathname),
        ox(a, f)) : (delete d.redirect_uri,
        px(a, f),
        nx(a, {
            authResult: function(h) {
                h.authResult && h.authResult.error ? c(h.authResult) : nx(a, {
                    tokenReady: function() {
                        b(a.currentUser.get())
                    },
                    tokenFailed: c
                })
            }
        }))
    };
    kx.prototype.Fj = function(a) {
        return new _.Lj(function(b, c) {
            var d = new Cw(a);
            this.fD = d.Dr() ? !0 : !1;
            this.Qw ? (d.Ia.fetch_basic_profile = !0,
            Dw(d, "email profile openid")) : d.Ia.fetch_basic_profile = !1;
            var e = lx(this, d.Dr());
            d.QQ(e);
            Nw(this, b, c, d.get())
        }
        ,this)
    }
    ;
    kx.prototype.Fr = function(a) {
        var b = a || {};
        this.fD = !!b.scope;
        a = lx(this, b.scope);
        if ("" == a)
            return _.Qj({
                error: "Missing required parameter: scope"
            });
        var c = {
            scope: a,
            access_type: "offline",
            include_granted_scopes: !0
        };
        _.Sb(iw, function(d) {
            null != b[d] && (c[d] = b[d])
        });
        c.hasOwnProperty("prompt") || c.hasOwnProperty("approval_prompt") || (c.prompt = "consent");
        return "postmessage" == b.redirect_uri || void 0 == b.redirect_uri ? qx(this, c) : rx(this, c, b.redirect_uri)
    }
    ;
    var rx = function(a, b, c) {
        b.redirect_uri = c;
        ox(a, {
            sessionMeta: {
                extraQueryParams: b
            },
            responseType: "code id_token"
        });
        return _.Pj({
            message: "Redirecting to IDP."
        })
    }
      , qx = function(a, b) {
        b.origin = Iw();
        delete b.redirect_uri;
        px(a, {
            sessionMeta: {
                extraQueryParams: b
            },
            responseType: "code permission id_token"
        });
        return new _.Lj(function(c, d) {
            nx(this, {
                authResult: function(e) {
                    (e = e && e.authResult) && e.code ? c({
                        code: e.code
                    }) : d(e && e.error ? e : {
                        error: "unknown_error"
                    })
                }
            })
        }
        ,a)
    }
      , px = function(a, b) {
        Hw(b, ["sessionMeta", "extraQueryParams", "gsiwebsdk"], "2");
        Xv(a.Sd, Ew(), b)
    }
      , ox = function(a, b) {
        Hw(b, ["sessionMeta", "extraQueryParams", "gsiwebsdk"], "2");
        b = b || {};
        window.location.assign(Uv(a.Sd, b.sessionMeta, b.responseType))
    };
    kx.prototype.Gj = function(a) {
        var b = a || !1;
        return new _.Lj(function(c) {
            Ov(this.Sd, b, function() {
                c()
            })
        }
        ,this)
    }
    ;
    kx.prototype.YL = function() {
        return this.Ia.authParameters.scope
    }
    ;
    var lx = function(a, b) {
        a = a.YL();
        b = Kv(b ? b.split(" ") : [], a ? a.split(" ") : []);
        _.kj(b);
        return b.join(" ")
    };
    kx.prototype.VE = function() {
        var a = this;
        return new _.Lj(function(b, c) {
            nx(a, {
                noSessionBound: c,
                tokenFailed: c,
                userLoggedOut: c,
                tokenReady: function(d) {
                    b(d.response)
                }
            });
            a.Sd.AL()
        }
        )
    }
    ;
    kx.prototype.GJ = function(a, b, c, d) {
        if (a = "string" === typeof a ? document.getElementById(a) : a) {
            var e = this;
            _.Ui(a, "click", function() {
                var f = b;
                "function" == typeof b && (f = b());
                e.Fj(f).then(function(h) {
                    c && c(h)
                }, function(h) {
                    d && d(h)
                })
            })
        } else
            d && d({
                error: "Could not attach click handler to the element. Reason: element not found."
            })
    }
    ;
    kx.prototype.disconnect = function() {
        return new _.Lj(function(a) {
            this.Sd.revoke(function() {
                a()
            })
        }
        ,this)
    }
    ;
    kx.prototype.attachClickHandler = kx.prototype.GJ;
    var sx;
    _.Lj.prototype["catch"] = _.Lj.prototype.Gz;
    sx = null;
    _.tx = function(a) {
        a = Uw(a);
        if (Kw) {
            if (_.lj(a, sx || {}))
                return ix();
            throw new mw("gapi.auth2 has been initialized with different options. Consider calling gapi.auth2.getAuthInstance() instead of gapi.auth2.init().");
        }
        Vw(a, !1 !== a.fetch_basic_profile);
        Gw();
        sx = a;
        Kw = new kx(a);
        _.Be.ga = 1;
        return ix()
    }
    ;
    var vx, xx, ux, zx, yx, Ax;
    _.wx = function(a, b) {
        Gw();
        a = Uw(a);
        Vw(a);
        var c = bx(a)
          , d = new _.Iv(c);
        "none" == a.prompt ? ux(d, a, function(e) {
            e.status = e.error ? {
                signed_in: !1,
                method: null,
                google_logged_in: !1
            } : {
                signed_in: !0,
                method: "AUTO",
                google_logged_in: !0
            };
            b(e)
        }) : vx(d, a, function(e) {
            if (e.error)
                e.status = {
                    signed_in: !1,
                    method: null,
                    google_logged_in: !1
                };
            else {
                var f = e.access_token || e.id_token;
                e.status = {
                    signed_in: !!f,
                    method: "PROMPT",
                    google_logged_in: !!f
                }
            }
            e["g-oauth-window"] = d.rP.th;
            b(e)
        })
    }
    ;
    vx = function(a, b, c) {
        var d = new Zw(b.response_type);
        c = xx(a, d, c);
        var e = {
            responseType: d.toString()
        };
        Hw(e, ["sessionMeta", "extraQueryParams", "gsiwebsdk"], b.gsiwebsdk || "2");
        $w(d) && Hw(e, ["sessionMeta", "extraQueryParams", "access_type"], b.access_type || "offline");
        b.redirect_uri && Hw(e, ["sessionMeta", "extraQueryParams", "redirect_uri"], b.redirect_uri);
        b.state && Hw(e, ["sessionMeta", "extraQueryParams", "state"], b.state);
        b = Ew();
        a.zm ? c({
            authResult: {
                error: "idpiframe_initialization_failed",
                details: a.Yl().error
            }
        }) : (a.Al = c,
        Xv(a, b, e))
    }
    ;
    xx = function(a, b, c) {
        if (ax(b)) {
            var d = yx(c);
            return function(e) {
                e && e.authResult && !e.authResult.error ? a.tr(function(f) {
                    f && !f.error ? (f = _.mj(f),
                    $w(b) && (f.code = e.authResult.code),
                    d(f)) : d(f ? f : {
                        error: "unknown_error"
                    })
                })(e) : d(e && e.authResult ? e.authResult : {
                    error: "unknown_error"
                })
            }
        }
        return function(e) {
            e && e.authResult && !e.authResult.error ? c(_.mj(e.authResult)) : c(e && e.authResult ? e.authResult : {
                error: "unknown_error"
            })
        }
    }
    ;
    ux = function(a, b, c) {
        if ($w(new Zw(b.response_type)) && "offline" == b.access_type)
            c({
                error: "immediate_failed",
                error_subtype: "access_denied"
            });
        else {
            var d = yx(c);
            b.login_hint ? a.UB(b.login_hint, function(e) {
                e ? zx(a, b, e, d) : c({
                    error: "immediate_failed",
                    error_subtype: "access_denied"
                })
            }) : void 0 !== b.authuser && null !== b.authuser ? tw(a, b.authuser).select(function(e) {
                e && e.login_hint ? zx(a, b, e.login_hint, d) : d({
                    error: "immediate_failed",
                    error_subtype: "access_denied"
                })
            }) : a.kr(function(e) {
                e && e.hint ? zx(a, b, e.hint, d) : e && e.disabled ? d({
                    error: "immediate_failed",
                    error_subtype: "no_user_bound"
                }) : ("first_valid" == b.session_selection ? sw(a) : rw(a)).select(function(f) {
                    f && f.login_hint ? zx(a, b, f.login_hint, d) : d({
                        error: "immediate_failed",
                        error_subtype: "no_user_bound"
                    })
                })
            })
        }
    }
    ;
    zx = function(a, b, c, d) {
        b = new Zw(b.response_type);
        var e = 0
          , f = {}
          , h = function(k) {
            !k || k.error ? d(k) : (e--,
            _.qi(f, k),
            0 == e && d(f))
        };
        (ax(b) || cx(b, "id_token")) && e++;
        $w(b) && e++;
        (ax(b) || cx(b, "id_token")) && _.Jv(a, c, h);
        $w(b) && Yv(a, c, h)
    }
    ;
    yx = function(a) {
        return function(b) {
            if (!b || b.error)
                _.bw(),
                b ? a(b) : a({
                    error: "unknown_error"
                });
            else {
                if (b.access_token) {
                    var c = _.mj(b);
                    Ax(c);
                    delete c.id_token;
                    delete c.code;
                    _.aw(c)
                }
                a(b)
            }
        }
    }
    ;
    Ax = function(a) {
        _.Sb(jw, function(b) {
            delete a[b]
        })
    }
    ;
    _.I("gapi.auth2.init", _.tx);
    _.I("gapi.auth2.authorize", function(a, b) {
        if (null != Kw)
            throw new mw("gapi.auth2.authorize cannot be called after GoogleAuth has been initialized (i.e. with a call to gapi.auth2.init, or gapi.client.init when given a 'clientId' and a 'scope' parameters).");
        _.wx(a, function(c) {
            Ax(c);
            b(c)
        })
    });
    _.I("gapi.auth2._gt", function() {
        return _.Uh()
    });
    _.I("gapi.auth2.enableDebugLogs", function(a) {
        a = !1 !== a;
        _.zu = "0" != a && !!a
    });
    _.I("gapi.auth2.getAuthInstance", _.jx);
    _.I("gapi.auth2.BasicProfile", Lw);
    _.I("gapi.auth2.BasicProfile.prototype.getId", Lw.prototype.getId);
    _.I("gapi.auth2.BasicProfile.prototype.getName", Lw.prototype.fj);
    _.I("gapi.auth2.BasicProfile.prototype.getGivenName", Lw.prototype.hX);
    _.I("gapi.auth2.BasicProfile.prototype.getFamilyName", Lw.prototype.cX);
    _.I("gapi.auth2.BasicProfile.prototype.getImageUrl", Lw.prototype.pX);
    _.I("gapi.auth2.BasicProfile.prototype.getEmail", Lw.prototype.Kv);
    _.I("gapi.auth2.GoogleAuth", kx);
    _.I("gapi.auth2.GoogleAuth.prototype.attachClickHandler", kx.prototype.GJ);
    _.I("gapi.auth2.GoogleAuth.prototype.disconnect", kx.prototype.disconnect);
    _.I("gapi.auth2.GoogleAuth.prototype.grantOfflineAccess", kx.prototype.Fr);
    _.I("gapi.auth2.GoogleAuth.prototype.signIn", kx.prototype.Fj);
    _.I("gapi.auth2.GoogleAuth.prototype.signOut", kx.prototype.Gj);
    _.I("gapi.auth2.GoogleAuth.prototype.getInitialScopes", kx.prototype.YL);
    _.I("gapi.auth2.GoogleUser", Jw);
    _.I("gapi.auth2.GoogleUser.prototype.grant", Jw.prototype.YX);
    _.I("gapi.auth2.GoogleUser.prototype.getId", Jw.prototype.getId);
    _.I("gapi.auth2.GoogleUser.prototype.isSignedIn", Jw.prototype.Kf);
    _.I("gapi.auth2.GoogleUser.prototype.getAuthResponse", Jw.prototype.nk);
    _.I("gapi.auth2.GoogleUser.prototype.getBasicProfile", Jw.prototype.LW);
    _.I("gapi.auth2.GoogleUser.prototype.getGrantedScopes", Jw.prototype.jX);
    _.I("gapi.auth2.GoogleUser.prototype.getHostedDomain", Jw.prototype.lC);
    _.I("gapi.auth2.GoogleUser.prototype.grantOfflineAccess", Jw.prototype.Fr);
    _.I("gapi.auth2.GoogleUser.prototype.hasGrantedScopes", Jw.prototype.Bw);
    _.I("gapi.auth2.GoogleUser.prototype.reloadAuthResponse", Jw.prototype.VE);
    _.I("gapi.auth2.LiveValue", zw);
    _.I("gapi.auth2.LiveValue.prototype.listen", zw.prototype.V);
    _.I("gapi.auth2.LiveValue.prototype.get", zw.prototype.get);
    _.I("gapi.auth2.SigninOptionsBuilder", Cw);
    _.I("gapi.auth2.SigninOptionsBuilder.prototype.getAppPackageName", Cw.prototype.IW);
    _.I("gapi.auth2.SigninOptionsBuilder.prototype.setAppPackageName", Cw.prototype.I2);
    _.I("gapi.auth2.SigninOptionsBuilder.prototype.getScope", Cw.prototype.Dr);
    _.I("gapi.auth2.SigninOptionsBuilder.prototype.setScope", Cw.prototype.QQ);
    _.I("gapi.auth2.SigninOptionsBuilder.prototype.getPrompt", Cw.prototype.HX);
    _.I("gapi.auth2.SigninOptionsBuilder.prototype.setPrompt", Cw.prototype.h3);
    _.I("gapi.auth2.SigninOptionsBuilder.prototype.get", Cw.prototype.get);

    _.Ne = _.Ne || {};
    (function() {
        function a(b) {
            var c = "";
            if (3 == b.nodeType || 4 == b.nodeType)
                c = b.nodeValue;
            else if (b.innerText)
                c = b.innerText;
            else if (b.innerHTML)
                c = b.innerHTML;
            else if (b.firstChild) {
                c = [];
                for (b = b.firstChild; b; b = b.nextSibling)
                    c.push(a(b));
                c = c.join("")
            }
            return c
        }
        _.Ne.createElement = function(b) {
            if (!document.body || document.body.namespaceURI)
                try {
                    var c = document.createElementNS("http://www.w3.org/1999/xhtml", b)
                } catch (d) {}
            return c || document.createElement(b)
        }
        ;
        _.Ne.qK = function(b) {
            var c = _.Ne.createElement("iframe");
            try {
                var d = ["<", "iframe"], e = b || {}, f;
                for (f in e)
                    e.hasOwnProperty(f) && (d.push(" "),
                    d.push(f),
                    d.push('="'),
                    d.push(_.Ne.HB(e[f])),
                    d.push('"'));
                d.push("></");
                d.push("iframe");
                d.push(">");
                var h = _.Ne.createElement(d.join(""));
                h && (!c || h.tagName == c.tagName && h.namespaceURI == c.namespaceURI) && (c = h)
            } catch (l) {}
            d = c;
            b = b || {};
            for (var k in b)
                b.hasOwnProperty(k) && (d[k] = b[k]);
            return c
        }
        ;
        _.Ne.GL = function() {
            if (document.body)
                return document.body;
            try {
                var b = document.getElementsByTagNameNS("http://www.w3.org/1999/xhtml", "body");
                if (b && 1 == b.length)
                    return b[0]
            } catch (c) {}
            return document.documentElement || document
        }
        ;
        _.Ne.oca = function(b) {
            return a(b)
        }
    }
    )();

    _.Jh = function() {
        function a() {
            e[0] = 1732584193;
            e[1] = 4023233417;
            e[2] = 2562383102;
            e[3] = 271733878;
            e[4] = 3285377520;
            n = m = 0
        }
        function b(q) {
            for (var p = h, t = 0; 64 > t; t += 4)
                p[t / 4] = q[t] << 24 | q[t + 1] << 16 | q[t + 2] << 8 | q[t + 3];
            for (t = 16; 80 > t; t++)
                q = p[t - 3] ^ p[t - 8] ^ p[t - 14] ^ p[t - 16],
                p[t] = (q << 1 | q >>> 31) & 4294967295;
            q = e[0];
            var v = e[1]
              , u = e[2]
              , w = e[3]
              , z = e[4];
            for (t = 0; 80 > t; t++) {
                if (40 > t)
                    if (20 > t) {
                        var E = w ^ v & (u ^ w);
                        var A = 1518500249
                    } else
                        E = v ^ u ^ w,
                        A = 1859775393;
                else
                    60 > t ? (E = v & u | w & (v | u),
                    A = 2400959708) : (E = v ^ u ^ w,
                    A = 3395469782);
                E = ((q << 5 | q >>> 27) & 4294967295) + E + z + A + p[t] & 4294967295;
                z = w;
                w = u;
                u = (v << 30 | v >>> 2) & 4294967295;
                v = q;
                q = E
            }
            e[0] = e[0] + q & 4294967295;
            e[1] = e[1] + v & 4294967295;
            e[2] = e[2] + u & 4294967295;
            e[3] = e[3] + w & 4294967295;
            e[4] = e[4] + z & 4294967295
        }
        function c(q, p) {
            if ("string" === typeof q) {
                q = unescape(encodeURIComponent(q));
                for (var t = [], v = 0, u = q.length; v < u; ++v)
                    t.push(q.charCodeAt(v));
                q = t
            }
            p || (p = q.length);
            t = 0;
            if (0 == m)
                for (; t + 64 < p; )
                    b(q.slice(t, t + 64)),
                    t += 64,
                    n += 64;
            for (; t < p; )
                if (f[m++] = q[t++],
                n++,
                64 == m)
                    for (m = 0,
                    b(f); t + 64 < p; )
                        b(q.slice(t, t + 64)),
                        t += 64,
                        n += 64
        }
        function d() {
            var q = []
              , p = 8 * n;
            56 > m ? c(k, 56 - m) : c(k, 64 - (m - 56));
            for (var t = 63; 56 <= t; t--)
                f[t] = p & 255,
                p >>>= 8;
            b(f);
            for (t = p = 0; 5 > t; t++)
                for (var v = 24; 0 <= v; v -= 8)
                    q[p++] = e[t] >> v & 255;
            return q
        }
        for (var e = [], f = [], h = [], k = [128], l = 1; 64 > l; ++l)
            k[l] = 0;
        var m, n;
        a();
        return {
            reset: a,
            update: c,
            digest: d,
            Ih: function() {
                for (var q = d(), p = "", t = 0; t < q.length; t++)
                    p += "0123456789ABCDEF".charAt(Math.floor(q[t] / 16)) + "0123456789ABCDEF".charAt(q[t] % 16);
                return p
            }
        }
    }
    ;
    var Lh = function(a, b, c) {
        var d = String(_.D.location.href);
        return d && a && b ? [b, Kh(_.pg(d), a, c || null)].join(" ") : null
    }
      , Kh = function(a, b, c) {
        var d = []
          , e = [];
        if (1 == (Array.isArray(c) ? 2 : 1))
            return e = [b, a],
            _.Sb(d, function(k) {
                e.push(k)
            }),
            Mh(e.join(" "));
        var f = []
          , h = [];
        _.Sb(c, function(k) {
            h.push(k.key);
            f.push(k.value)
        });
        c = Math.floor((new Date).getTime() / 1E3);
        e = 0 == f.length ? [c, b, a] : [f.join(":"), c, b, a];
        _.Sb(d, function(k) {
            e.push(k)
        });
        a = Mh(e.join(" "));
        a = [c, a];
        0 == h.length || a.push(h.join(""));
        return a.join("_")
    }
      , Mh = function(a) {
        var b = _.Jh();
        b.update(a);
        return b.Ih().toLowerCase()
    };
    var Ph;
    _.Nh = function(a) {
        return !!_.Fh.FPA_SAMESITE_PHASE2_MOD || !(void 0 === a || !a)
    }
    ;
    _.Oh = function(a) {
        a = void 0 === a ? !1 : a;
        var b = _.D.__SAPISID || _.D.__APISID || _.D.__3PSAPISID || _.D.__OVERRIDE_SID;
        _.Nh(a) && (b = b || _.D.__1PSAPISID);
        if (b)
            return !0;
        var c = new _.Gh(document);
        b = c.get("SAPISID") || c.get("APISID") || c.get("__Secure-3PAPISID") || c.get("SID");
        _.Nh(a) && (b = b || c.get("__Secure-1PAPISID"));
        return !!b
    }
    ;
    Ph = function(a, b, c, d) {
        (a = _.D[a]) || (a = (new _.Gh(document)).get(b));
        return a ? Lh(a, c, d) : null
    }
    ;
    _.Qh = function(a, b) {
        b = void 0 === b ? !1 : b;
        var c = _.pg(String(_.D.location.href))
          , d = [];
        if (_.Oh(b)) {
            c = 0 == c.indexOf("https:") || 0 == c.indexOf("chrome-extension:") || 0 == c.indexOf("moz-extension:");
            var e = c ? _.D.__SAPISID : _.D.__APISID;
            e || (e = new _.Gh(document),
            e = e.get(c ? "SAPISID" : "APISID") || e.get("__Secure-3PAPISID"));
            (e = e ? Lh(e, c ? "SAPISIDHASH" : "APISIDHASH", a) : null) && d.push(e);
            c && _.Nh(b) && ((b = Ph("__1PSAPISID", "__Secure-1PAPISID", "SAPISID1PHASH", a)) && d.push(b),
            (a = Ph("__3PSAPISID", "__Secure-3PAPISID", "SAPISID3PHASH", a)) && d.push(a))
        }
        return 0 == d.length ? null : d.join(" ")
    }
    ;

    _.Rh = function(a, b) {
        var c = {
            SAPISIDHASH: !0,
            SAPISID3PHASH: !0,
            APISIDHASH: !0
        };
        _.Nh(void 0 === b ? !1 : b) && (c.SAPISID1PHASH = !0);
        return a && (a.OriginToken || a.Authorization && c[String(a.Authorization).split(" ")[0]]) ? !0 : !1
    }
    ;
    _.Sh = {
        NM: _.Rh,
        h_: _.Oh,
        dM: function() {
            var a = null;
            _.Oh() && (a = window.__PVT,
            null == a && (a = (new _.Gh(document)).get("BEAT")));
            return a
        },
        EL: _.Qh
    };

    _.ng = window.gapi && window.gapi.util || {};

    _.ng = _.ng = {};
    _.ng.getOrigin = function(a) {
        return _.pg(a)
    }
    ;

    _.vy = function(a) {
        if (0 !== a.indexOf("GCSC"))
            return null;
        var b = {
            ii: !1
        };
        a = a.substr(4);
        if (!a)
            return b;
        var c = a.charAt(0);
        a = a.substr(1);
        var d = a.lastIndexOf("_");
        if (-1 == d)
            return b;
        var e = _.ty(a.substr(d + 1));
        if (null == e)
            return b;
        a = a.substring(0, d);
        if ("_" !== a.charAt(0))
            return b;
        d = "E" === c && e.De;
        return !d && ("U" !== c || e.De) || d && !_.uy ? b : {
            ii: !0,
            De: d,
            rV: a.substr(1),
            domain: e.domain,
            Jh: e.Jh
        }
    }
    ;
    _.wy = function(a, b) {
        this.hf = a;
        a = b || {};
        this.P_ = Number(a.maxAge) || 0;
        this.Vd = a.domain;
        this.Wk = a.path;
        this.q2 = !!a.secure
    }
    ;
    _.wy.prototype.read = function() {
        for (var a = this.hf + "=", b = document.cookie.split(/;\s*/), c = 0; c < b.length; ++c) {
            var d = b[c];
            if (0 == d.indexOf(a))
                return d.substr(a.length)
        }
    }
    ;
    _.wy.prototype.write = function(a, b) {
        if (!xy.test(this.hf))
            throw "Invalid cookie name";
        if (!yy.test(a))
            throw "Invalid cookie value";
        a = this.hf + "=" + a;
        this.Vd && (a += ";domain=" + this.Vd);
        this.Wk && (a += ";path=" + this.Wk);
        b = "number" === typeof b ? b : this.P_;
        if (0 <= b) {
            var c = new Date;
            c.setSeconds(c.getSeconds() + b);
            a += ";expires=" + c.toUTCString()
        }
        this.q2 && (a += ";secure");
        document.cookie = a;
        return !0
    }
    ;
    _.wy.prototype.clear = function() {
        this.write("", 0)
    }
    ;
    var yy = /^[-+/_=.:|%&a-zA-Z0-9@]*$/
      , xy = /^[A-Z_][A-Z0-9_]{0,63}$/;
    _.wy.iterate = function(a) {
        for (var b = document.cookie.split(/;\s*/), c = 0; c < b.length; ++c) {
            var d = b[c].split("=")
              , e = d.shift();
            a(e, d.join("="))
        }
    }
    ;
    _.zy = function(a) {
        this.ji = a
    }
    ;
    _.zy.prototype.read = function() {
        if (Ay.hasOwnProperty(this.ji))
            return Ay[this.ji]
    }
    ;
    _.zy.prototype.write = function(a) {
        Ay[this.ji] = a;
        return !0
    }
    ;
    _.zy.prototype.clear = function() {
        delete Ay[this.ji]
    }
    ;
    var Ay = {};
    _.zy.iterate = function(a) {
        for (var b in Ay)
            Ay.hasOwnProperty(b) && a(b, Ay[b])
    }
    ;
    var By = function() {
        this.Mb = null;
        this.key = function() {
            return null
        }
        ;
        this.getItem = function() {
            return this.Mb
        }
        ;
        this.setItem = function(a, b) {
            this.Mb = b;
            this.length = 1
        }
        ;
        this.removeItem = function() {
            this.clear()
        }
        ;
        this.clear = function() {
            this.Mb = null;
            this.length = 0
        }
        ;
        this.length = 0
    }
      , Cy = function(a) {
        try {
            var b = a || window.sessionStorage;
            if (!b)
                return !1;
            b.setItem("gapi.sessionStorageTest", "gapi.sessionStorageTest" + b.length);
            b.removeItem("gapi.sessionStorageTest");
            return !0
        } catch (c) {
            return !1
        }
    }
      , Dy = function(a, b) {
        this.hf = a;
        this.yH = Cy(b) ? b || window.sessionStorage : new By
    };
    Dy.prototype.read = function() {
        return this.yH.getItem(this.hf)
    }
    ;
    Dy.prototype.write = function(a) {
        try {
            this.yH.setItem(this.hf, a)
        } catch (b) {
            return !1
        }
        return !0
    }
    ;
    Dy.prototype.clear = function() {
        this.yH.removeItem(this.hf)
    }
    ;
    Dy.iterate = function(a) {
        if (Cy())
            for (var b = 0, c = window.sessionStorage.length; b < c; ++b) {
                var d = window.sessionStorage.key(b);
                a(d, window.sessionStorage[d])
            }
    }
    ;
    for (var Ey = 0; 64 > Ey; ++Ey)
        ;
    _.uy = "https:" === window.location.protocol;
    _.Fy = _.uy || "http:" === window.location.protocol ? _.wy : _.zy;
    _.ty = function(a) {
        var b = a.substr(1)
          , c = ""
          , d = window.location.hostname;
        if ("" !== b) {
            c = parseInt(b, 10);
            if (isNaN(c))
                return null;
            b = d.split(".");
            if (b.length < c - 1)
                return null;
            b.length == c - 1 && (d = "." + d)
        } else
            d = "";
        return {
            De: "S" == a.charAt(0),
            domain: d,
            Jh: c
        }
    }
    ;
    var Gy, Hy, Ky, Ly;
    Gy = _.re();
    Hy = _.re();
    _.Iy = _.re();
    _.Jy = _.re();
    Ky = "state code cookie_policy g_user_cookie_policy authuser prompt g-oauth-window status".split(" ");
    Ly = function(a) {
        this.nP = a;
        this.$D = null
    }
    ;
    Ly.prototype.write = function(a) {
        var b = _.re(), c = _.re(), d = window.decodeURIComponent ? decodeURIComponent : unescape, e;
        for (e in a)
            if (_.se(a, e)) {
                var f = a[e];
                f = f.replace(/\+/g, " ");
                c[e] = d(f);
                b[e] = a[e]
            }
        d = 0;
        for (e = Ky.length; d < e; ++d)
            delete c[Ky[d]];
        a = String(a.authuser || 0);
        d = _.re();
        d[a] = c;
        c = _.yf(d);
        this.nP.write(c);
        this.$D = b
    }
    ;
    Ly.prototype.read = function() {
        return this.$D
    }
    ;
    Ly.prototype.clear = function() {
        this.nP.clear();
        this.$D = _.re()
    }
    ;
    _.My = function(a) {
        return a ? {
            domain: a.domain,
            path: "/",
            secure: a.De
        } : null
    }
    ;
    Dy.iterate(function(a) {
        var b = _.vy(a);
        b && b.ii && (Gy[a] = new Ly(new Dy(a)))
    });
    _.Fy.iterate(function(a) {
        Gy[a] && (Hy[a] = new _.Fy(a,_.My(_.vy(a))))
    });

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Lq = function() {
        return !_.Kq() && (_.rb("iPod") || _.rb("iPhone") || _.rb("Android") || _.rb("IEMobile"))
    }
    ;
    _.Kq = function() {
        return _.rb("iPad") || _.rb("Android") && !_.rb("Mobile") || _.rb("Silk")
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var jr, kr, nr, mr, xr, lr, Br, Cr, Dr, Fr, Kr;
    jr = function(a) {
        for (var b = !0, c = /^[-_a-zA-Z0-9]$/, d = 0; d < a.length; d++) {
            var e = a.charAt(d);
            if ("]" == e) {
                if (b)
                    return !1;
                b = !0
            } else if ("[" == e) {
                if (!b)
                    return !1;
                b = !1
            } else if (!b && !c.test(e))
                return !1
        }
        return b
    }
    ;
    kr = function(a) {
        return a.replace(_.Pc, function(b, c, d, e) {
            var f = "";
            d = d.replace(/^(['"])(.*)\1$/, function(h, k, l) {
                f = k;
                return l
            });
            b = (_.Ic(d) || _.Jc).Hf();
            return c + f + b + f + e
        })
    }
    ;
    nr = function(a) {
        if (a instanceof _.Cc)
            return 'url("' + _.Dc(a).replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")';
        if (a instanceof _.dc)
            a = _.ec(a);
        else {
            a = String(a);
            var b = a.replace(_.Qc, "$1").replace(_.Qc, "$1").replace(_.Pc, "url");
            if (_.Oc.test(b)) {
                if (b = !lr.test(a)) {
                    for (var c = b = !0, d = 0; d < a.length; d++) {
                        var e = a.charAt(d);
                        "'" == e && c ? b = !b : '"' == e && b && (c = !c)
                    }
                    b = b && c && jr(a)
                }
                a = b ? kr(a) : "zClosurez"
            } else
                a = "zClosurez"
        }
        if (/[{;}]/.test(a))
            throw new mr("Value does not allow [{;}], got: %s.",[a]);
        return a
    }
    ;
    _.or = function(a, b) {
        return a == b ? !0 : a && b ? a.x == b.x && a.y == b.y : !1
    }
    ;
    _.pr = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    }
    ;
    _.g = _.pr.prototype;
    _.g.clone = function() {
        return new _.pr(this.x,this.y)
    }
    ;
    _.g.equals = function(a) {
        return a instanceof _.pr && _.or(this, a)
    }
    ;
    _.g.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    }
    ;
    _.g.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    }
    ;
    _.g.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    }
    ;
    _.g.translate = function(a, b) {
        a instanceof _.pr ? (this.x += a.x,
        this.y += a.y) : (this.x += Number(a),
        "number" === typeof b && (this.y += b));
        return this
    }
    ;
    _.g.scale = function(a, b) {
        this.x *= a;
        this.y *= "number" === typeof b ? b : a;
        return this
    }
    ;
    _.qr = function(a, b) {
        this.width = a;
        this.height = b
    }
    ;
    _.g = _.qr.prototype;
    _.g.clone = function() {
        return new _.qr(this.width,this.height)
    }
    ;
    _.g.aspectRatio = function() {
        return this.width / this.height
    }
    ;
    _.g.isEmpty = function() {
        return !(this.width * this.height)
    }
    ;
    _.g.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    }
    ;
    _.g.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    }
    ;
    _.g.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    }
    ;
    _.g.scale = function(a, b) {
        this.width *= a;
        this.height *= "number" === typeof b ? b : a;
        return this
    }
    ;
    _.rr = function(a) {
        return "CSS1Compat" == a.compatMode
    }
    ;
    _.sr = function(a) {
        a = a.document;
        a = _.rr(a) ? a.documentElement : a.body;
        return new _.qr(a.clientWidth,a.clientHeight)
    }
    ;
    _.tr = function(a) {
        return _.sr(a || window)
    }
    ;
    _.ur = function(a) {
        return a.scrollingElement ? a.scrollingElement : !_.ld && _.rr(a) ? a.documentElement : a.body || a.documentElement
    }
    ;
    _.vr = function(a) {
        var b = _.ur(a);
        a = a.parentWindow || a.defaultView;
        return _.hd && _.Dd("10") && a.pageYOffset != b.scrollTop ? new _.pr(b.scrollLeft,b.scrollTop) : new _.pr(a.pageXOffset || b.scrollLeft,a.pageYOffset || b.scrollTop)
    }
    ;
    _.wr = function(a, b, c, d) {
        return _.Ud(a.nb, b, c, d)
    }
    ;
    mr = function(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++)
            c += a[e] + (e < b.length ? b[e] : "%s");
        _.jb.call(this, c + a[d])
    }
    ;
    _.$a(mr, _.jb);
    mr.prototype.name = "AssertionError";
    xr = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    _.yr = function(a) {
        if (a instanceof _.Mc && a.constructor === _.Mc)
            return a.PE;
        _.Db(a);
        return "type_error:SafeStyle"
    }
    ;
    lr = /\/\*/;
    _.zr = function(a) {
        var b = "", c;
        for (c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                if (!/^[-_a-zA-Z0-9]+$/.test(c))
                    throw Error("h`" + c);
                var d = a[c];
                null != d && (d = Array.isArray(d) ? d.map(nr).join(" ") : nr(d),
                b += c + ":" + d + ";")
            }
        return b ? new _.Mc(b,_.Lc) : _.Nc
    }
    ;
    _.Ar = function(a) {
        if (a instanceof _.Sc && a.constructor === _.Sc)
            return a.OE;
        _.Db(a);
        return "type_error:SafeStyleSheet"
    }
    ;
    Br = /^[a-zA-Z0-9-]+$/;
    Cr = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    };
    Dr = function(a) {
        var b = _.ad(_.bd)
          , c = b.tk()
          , d = []
          , e = function(f) {
            Array.isArray(f) ? f.forEach(e) : (f = _.ad(f),
            d.push(_.Zc(f).toString()),
            f = f.tk(),
            0 == c ? c = f : 0 != f && c != f && (c = null))
        };
        a.forEach(e);
        return _.$c(d.join(_.Zc(b).toString()), c)
    }
    ;
    _.Er = function(a) {
        return Dr(Array.prototype.slice.call(arguments))
    }
    ;
    Fr = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    };
    _.Gr = function(a, b, c) {
        var d = String(a);
        if (!Br.test(d))
            throw Error("e");
        if (d.toUpperCase()in Cr)
            throw Error("e");
        a = String(a);
        d = c;
        c = null;
        var e = "<" + a
          , f = "";
        if (b)
            for (l in b)
                if (Object.prototype.hasOwnProperty.call(b, l)) {
                    if (!Br.test(l))
                        throw Error("e");
                    var h = b[l];
                    if (null != h) {
                        var k = l;
                        if (h instanceof _.dc)
                            h = _.ec(h);
                        else if ("style" == k.toLowerCase()) {
                            if (!_.Bb(h))
                                throw Error("e");
                            h instanceof _.Mc || (h = _.zr(h));
                            h = _.yr(h)
                        } else {
                            if (/^on/i.test(k))
                                throw Error("e");
                            if (k.toLowerCase()in Fr)
                                if (h instanceof _.hc)
                                    h = _.jc(h);
                                else if (h instanceof _.Cc)
                                    h = _.Dc(h);
                                else if ("string" === typeof h)
                                    h = (_.Ic(h) || _.Jc).Hf();
                                else
                                    throw Error("e");
                        }
                        h.Yh && (h = h.Hf());
                        k = k + '="' + _.yc(String(h)) + '"';
                        f += " " + k
                    }
                }
        var l = e + f;
        null == d ? d = [] : Array.isArray(d) || (d = [d]);
        !0 === xr[a.toLowerCase()] ? l += ">" : (c = _.Er(d),
        l += ">" + _.Zc(c).toString() + "</" + a + ">",
        c = c.tk());
        (b = b && b.dir) && (c = /^(ltr|rtl|auto)$/i.test(b) ? 0 : null);
        return _.$c(l, c)
    }
    ;
    _.Hr = function(a) {
        return Number(_.Gd) >= a
    }
    ;
    _.Ir = function(a) {
        return _.Od('style[nonce],link[rel="stylesheet"][nonce]', a)
    }
    ;
    _.Jr = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }
    ;
    Kr = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    }
    ;
    _.Lr = function(a, b, c) {
        return _.ae(document, arguments)
    }
    ;
    _.Mr = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    ;
    _.g = _.Mr.prototype;
    _.g.Ob = function() {
        return this.right - this.left
    }
    ;
    _.g.Ac = function() {
        return this.bottom - this.top
    }
    ;
    _.g.clone = function() {
        return new _.Mr(this.top,this.right,this.bottom,this.left)
    }
    ;
    _.g.contains = function(a) {
        return this && a ? a instanceof _.Mr ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    }
    ;
    _.g.expand = function(a, b, c, d) {
        _.Bb(a) ? (this.top -= a.top,
        this.right += a.right,
        this.bottom += a.bottom,
        this.left -= a.left) : (this.top -= a,
        this.right += Number(b),
        this.bottom += Number(c),
        this.left -= Number(d));
        return this
    }
    ;
    _.g.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    }
    ;
    _.g.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    }
    ;
    _.g.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    }
    ;
    _.g.translate = function(a, b) {
        a instanceof _.pr ? (this.left += a.x,
        this.right += a.x,
        this.top += a.y,
        this.bottom += a.y) : (this.left += a,
        this.right += a,
        "number" === typeof b && (this.top += b,
        this.bottom += b));
        return this
    }
    ;
    _.g.scale = function(a, b) {
        b = "number" === typeof b ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    }
    ;
    var Pr, Vr, Tr, Yr, js, ks;
    _.Or = function(a, b, c) {
        if ("string" === typeof b)
            (b = _.Nr(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d]
                  , f = _.Nr(c, d);
                f && (c.style[f] = e)
            }
    }
    ;
    Pr = {};
    _.Nr = function(a, b) {
        var c = Pr[b];
        if (!c) {
            var d = _.Jr(b);
            c = d;
            void 0 === a.style[d] && (d = (_.ld ? "Webkit" : _.kd ? "Moz" : _.hd ? "ms" : null) + Kr(d),
            void 0 !== a.style[d] && (c = d));
            Pr[b] = c
        }
        return c
    }
    ;
    _.Qr = function(a, b) {
        var c = _.Sd(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    }
    ;
    _.Rr = function(a, b) {
        return a.currentStyle ? a.currentStyle[b] : null
    }
    ;
    _.Sr = function(a, b) {
        return _.Qr(a, b) || _.Rr(a, b) || a.style && a.style[b]
    }
    ;
    _.Ur = function(a, b, c) {
        if (b instanceof _.pr) {
            var d = b.x;
            b = b.y
        } else
            d = b,
            b = c;
        a.style.left = Tr(d, !1);
        a.style.top = Tr(b, !1)
    }
    ;
    Vr = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }
    ;
    _.Zr = function(a, b) {
        b = b || _.ur(document);
        var c = b || _.ur(document);
        var d = _.Wr(a)
          , e = _.Wr(c)
          , f = _.Xr(c);
        if (c == _.ur(document)) {
            var h = d.x - c.scrollLeft;
            d = d.y - c.scrollTop;
            _.hd && !_.Hr(10) && (h += f.left,
            d += f.top)
        } else
            h = d.x - e.x - f.left,
            d = d.y - e.y - f.top;
        a = Yr(a);
        f = c.clientHeight - a.height;
        e = c.scrollLeft;
        var k = c.scrollTop;
        e += Math.min(h, Math.max(h - (c.clientWidth - a.width), 0));
        k += Math.min(d, Math.max(d - f, 0));
        c = new _.pr(e,k);
        b.scrollLeft = c.x;
        b.scrollTop = c.y
    }
    ;
    _.Wr = function(a) {
        var b = _.Sd(a)
          , c = new _.pr(0,0);
        var d = b ? _.Sd(b) : document;
        d = !_.hd || _.Hr(9) || _.rr(_.Td(d).nb) ? d.documentElement : d.body;
        if (a == d)
            return c;
        a = Vr(a);
        b = _.vr(_.Td(b).nb);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }
    ;
    _.as = function(a, b) {
        var c = new _.pr(0,0)
          , d = _.Yd(_.Sd(a));
        if (!_.ed(d, "parent"))
            return c;
        do {
            var e = d == b ? _.Wr(a) : _.$r(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    }
    ;
    _.$r = function(a) {
        a = Vr(a);
        return new _.pr(a.left,a.top)
    }
    ;
    _.bs = function(a, b, c) {
        if (b instanceof _.qr)
            c = b.height,
            b = b.width;
        else if (void 0 == c)
            throw Error("J");
        a.style.width = Tr(b, !0);
        a.style.height = Tr(c, !0)
    }
    ;
    Tr = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    }
    ;
    _.cs = function(a) {
        var b = Yr;
        if ("none" != _.Sr(a, "display"))
            return b(a);
        var c = a.style
          , d = c.display
          , e = c.visibility
          , f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }
    ;
    Yr = function(a) {
        var b = a.offsetWidth
          , c = a.offsetHeight
          , d = _.ld && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = Vr(a),
        new _.qr(a.right - a.left,a.bottom - a.top)) : new _.qr(b,c)
    }
    ;
    _.ds = function(a, b) {
        a.style.display = b ? "" : "none"
    }
    ;
    _.fs = function(a) {
        var b = _.Td(void 0)
          , c = b.Za();
        if (_.hd && c.createStyleSheet)
            b = c.createStyleSheet(),
            _.es(b, a);
        else {
            c = _.wr(b, "HEAD")[0];
            if (!c) {
                var d = _.wr(b, "BODY")[0];
                c = b.ma("HEAD");
                d.parentNode.insertBefore(c, d)
            }
            d = b.ma("STYLE");
            var e = _.Ir();
            e && d.setAttribute("nonce", e);
            _.es(d, a);
            b.appendChild(c, d)
        }
    }
    ;
    _.es = function(a, b) {
        b = _.Ar(b);
        _.hd && void 0 !== a.cssText ? a.cssText = b : _.D.trustedTypes ? _.ke(a, b) : a.innerHTML = b
    }
    ;
    _.gs = function(a) {
        return "rtl" == _.Sr(a, "direction")
    }
    ;
    _.hs = _.kd ? "MozUserSelect" : _.ld || _.id ? "WebkitUserSelect" : null;
    _.is = function(a, b) {
        if (/^\d+px?$/.test(b))
            return parseInt(b, 10);
        var c = a.style.left
          , d = a.runtimeStyle.left;
        a.runtimeStyle.left = a.currentStyle.left;
        a.style.left = b;
        b = a.style.pixelLeft;
        a.style.left = c;
        a.runtimeStyle.left = d;
        return +b
    }
    ;
    js = {
        thin: 2,
        medium: 4,
        thick: 6
    };
    ks = function(a, b) {
        if ("none" == _.Rr(a, b + "Style"))
            return 0;
        b = _.Rr(a, b + "Width");
        return b in js ? js[b] : _.is(a, b)
    }
    ;
    _.Xr = function(a) {
        if (_.hd && !_.Hr(9)) {
            var b = ks(a, "borderLeft")
              , c = ks(a, "borderRight")
              , d = ks(a, "borderTop");
            a = ks(a, "borderBottom");
            return new _.Mr(d,c,a,b)
        }
        b = _.Qr(a, "borderLeftWidth");
        c = _.Qr(a, "borderRightWidth");
        d = _.Qr(a, "borderTopWidth");
        a = _.Qr(a, "borderBottomWidth");
        return new _.Mr(parseFloat(d),parseFloat(c),parseFloat(a),parseFloat(b))
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Lx = function(a, b, c) {
        if ("function" === typeof a)
            c && (a = (0,
            _.R)(a, c));
        else if (a && "function" == typeof a.handleEvent)
            a = (0,
            _.R)(a.handleEvent, a);
        else
            throw Error("va");
        return 2147483647 < Number(b) ? -1 : _.D.setTimeout(a, b || 0)
    }
    ;
    _.Mx = function(a) {
        _.D.clearTimeout(a)
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Ny = function(a) {
        _.Bi.call(this);
        this.ji = 1;
        this.ky = [];
        this.qy = 0;
        this.sf = [];
        this.Hi = {};
        this.JU = !!a
    }
    ;
    _.$a(_.Ny, _.Bi);
    _.g = _.Ny.prototype;
    _.g.subscribe = function(a, b, c) {
        var d = this.Hi[a];
        d || (d = this.Hi[a] = []);
        var e = this.ji;
        this.sf[e] = a;
        this.sf[e + 1] = b;
        this.sf[e + 2] = c;
        this.ji = e + 3;
        d.push(e);
        return e
    }
    ;
    _.g.yt = _.ea(19);
    _.g.unsubscribe = function(a, b, c) {
        if (a = this.Hi[a]) {
            var d = this.sf;
            if (a = a.find(function(e) {
                return d[e + 1] == b && d[e + 2] == c
            }))
                return this.Mj(a)
        }
        return !1
    }
    ;
    _.g.Mj = function(a) {
        var b = this.sf[a];
        if (b) {
            var c = this.Hi[b];
            0 != this.qy ? (this.ky.push(a),
            this.sf[a + 1] = _.Cb) : (c && _.wi(c, a),
            delete this.sf[a],
            delete this.sf[a + 1],
            delete this.sf[a + 2])
        }
        return !!b
    }
    ;
    _.g.Rm = function(a, b) {
        var c = this.Hi[a];
        if (c) {
            for (var d = Array(arguments.length - 1), e = 1, f = arguments.length; e < f; e++)
                d[e - 1] = arguments[e];
            if (this.JU)
                for (e = 0; e < c.length; e++) {
                    var h = c[e];
                    Oy(this.sf[h + 1], this.sf[h + 2], d)
                }
            else {
                this.qy++;
                try {
                    for (e = 0,
                    f = c.length; e < f && !this.isDisposed(); e++)
                        h = c[e],
                        this.sf[h + 1].apply(this.sf[h + 2], d)
                } finally {
                    if (this.qy--,
                    0 < this.ky.length && 0 == this.qy)
                        for (; c = this.ky.pop(); )
                            this.Mj(c)
                }
            }
            return 0 != e
        }
        return !1
    }
    ;
    var Oy = function(a, b, c) {
        _.Ij(function() {
            a.apply(b, c)
        })
    };
    _.Ny.prototype.clear = function(a) {
        if (a) {
            var b = this.Hi[a];
            b && (b.forEach(this.Mj, this),
            delete this.Hi[a])
        } else
            this.sf.length = 0,
            this.Hi = {}
    }
    ;
    _.Ny.prototype.Eb = function(a) {
        if (a) {
            var b = this.Hi[a];
            return b ? b.length : 0
        }
        a = 0;
        for (b in this.Hi)
            a += this.Eb(b);
        return a
    }
    ;
    _.Ny.prototype.na = function() {
        _.Ny.H.na.call(this);
        this.clear();
        this.ky.length = 0
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Py = function(a) {
        this.d4 = a
    }
    ;
    _.Py.prototype.toString = function() {
        return this.d4
    }
    ;
    _.Qy = function(a) {
        _.Bi.call(this);
        this.Od = new _.Ny(a);
        _.Di(this, this.Od)
    }
    ;
    _.$a(_.Qy, _.Bi);
    _.g = _.Qy.prototype;
    _.g.subscribe = function(a, b, c) {
        return this.Od.subscribe(a.toString(), b, c)
    }
    ;
    _.g.yt = _.ea(18);
    _.g.unsubscribe = function(a, b, c) {
        return this.Od.unsubscribe(a.toString(), b, c)
    }
    ;
    _.g.Mj = function(a) {
        return this.Od.Mj(a)
    }
    ;
    _.g.Rm = function(a, b) {
        return this.Od.Rm(a.toString(), b)
    }
    ;
    _.g.clear = function(a) {
        this.Od.clear(void 0 !== a ? a.toString() : void 0)
    }
    ;
    _.g.Eb = function(a) {
        return this.Od.Eb(void 0 !== a ? a.toString() : void 0)
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Ry = function(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return "string" === typeof c ? c : c.py + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        _.Or(a, "transition", b.join(","))
    }
    ;
    _.Sy = _.Id(function() {
        if (_.hd)
            return _.Dd("10.0");
        var a = _.be("DIV")
          , b = _.ld ? "-webkit" : _.kd ? "-moz" : _.hd ? "-ms" : null
          , c = {
            transition: "opacity 1s linear"
        };
        b && (c[b + "-transition"] = "opacity 1s linear");
        b = _.Gr("div", {
            style: c
        });
        _.Kd(a, b);
        a = a.firstChild;
        b = a.style[_.Jr("transition")];
        return "" != ("undefined" !== typeof b ? b : a.style[_.Nr(a, "transition")] || "")
    });

    _.Uy = function() {
        _.Ty = "oauth2relay" + String(2147483647 * (0,
        _.vg)() | 0)
    }
    ;
    _.Vy = new _.Qy;
    _.Wy = new _.Py("oauth");
    _.Uy();
    _.Ke("oauth-flow/client_id");
    var Xy = String(_.Ke("oauth-flow/redirectUri"));
    if (Xy)
        Xy.replace(/[#][\s\S]*/, "");
    else {
        var Yy = _.ng.getOrigin(window.location.href);
        _.Ke("oauth-flow/callbackUrl");
        encodeURIComponent(Yy)
    }
    _.ng.getOrigin(window.location.href);

    var $y, az, bz, cz, dz, ez, fz, gz, hz, iz, jz, lz, mz, nz, oz, pz, qz, rz, sz, tz, uz, vz, wz, xz, yz, zz, Az, Bz, Cz, Dz, Ez, Fz, Gz, Hz, Iz, Jz, Kz, Lz, Mz, Nz, Oz, Pz, Sz, Rz, Tz, Uz, Vz, Wz, Xz, Yz, Zz, $z, aA, cA;
    _.Zy = function(a, b) {
        if (_.ih && !b)
            return _.D.atob(a);
        var c = "";
        _.lh(a, function(d) {
            c += String.fromCharCode(d)
        });
        return c
    }
    ;
    $y = function(a) {
        var b = String(a("immediate") || "");
        a = String(a("prompt") || "");
        return "true" === b || "none" === a
    }
    ;
    az = function(a) {
        return _.Ah("enableMultilogin") && a("cookie_policy") && !$y(a) ? !0 : !1
    }
    ;
    dz = function() {
        var a, b = null;
        _.Fy.iterate(function(c, d) {
            0 === c.indexOf("G_AUTHUSER_") && (c = _.ty(c.substring(11)),
            !a || c.De && !a.De || c.De == a.De && c.Jh > a.Jh) && (a = c,
            b = d)
        });
        return {
            UU: a,
            authuser: b
        }
    }
    ;
    ez = [".APPS.GOOGLEUSERCONTENT.COM", "@DEVELOPER.GSERVICEACCOUNT.COM"];
    fz = function(a) {
        a = a.toUpperCase();
        for (var b = 0, c = ez.length; b < c; ++b) {
            var d = a.split(ez[b]);
            2 == d.length && "" === d[1] && (a = d[0])
        }
        a = a.replace(/-/g, "_").toUpperCase();
        40 < a.length && (b = new _.ug,
        b.Nt(a),
        a = b.Ih().toUpperCase());
        return a
    }
    ;
    gz = function(a) {
        if (!a)
            return [];
        a = a.split("=");
        return a[1] ? a[1].split("|") : []
    }
    ;
    hz = function(a) {
        a = a.split(":");
        return {
            clientId: a[0].split("=")[1],
            G2: gz(a[1]),
            fda: gz(a[2]),
            Zba: gz(a[3])
        }
    }
    ;
    iz = function(a) {
        var b = dz()
          , c = b.UU;
        b = b.authuser;
        var d = a && fz(a);
        if (null !== b) {
            var e;
            _.Fy.iterate(function(h, k) {
                (h = _.vy(h)) && h.ii && (d && h.rV != d || h.De == c.De && h.Jh == c.Jh && (e = k))
            });
            if (e) {
                var f = hz(e);
                a = f && f.G2[Number(b)];
                f = f && f.clientId;
                if (a)
                    return {
                        authuser: b,
                        Wda: a,
                        clientId: f
                    }
            }
        }
        return null
    }
    ;
    jz = function(a, b) {
        a = _.Uh(a);
        if (!a || !b && a.error)
            return null;
        b = Math.floor((new Date).getTime() / 1E3);
        return a.expires_at && b > a.expires_at ? null : a
    }
    ;
    _.kz = function(a, b) {
        if (b) {
            var c = b;
            var d = a
        } else
            "string" === typeof a ? d = a : c = a;
        c ? _.aw(c, d) : _.bw(d)
    }
    ;
    lz = function(a) {
        if (!a)
            return null;
        "single_host_origin" !== a && (a = _.pg(a));
        var b = window.location.hostname
          , c = b
          , d = _.uy;
        if ("single_host_origin" !== a) {
            c = a.split("://");
            if (2 == c.length)
                d = "https" === c.shift();
            else
                return _.Df.log("WARNING invalid cookie_policy: " + a),
                null;
            c = c[0]
        }
        if (-1 !== c.indexOf(":"))
            c = b = "";
        else {
            a = "." + c;
            if (b.lastIndexOf(a) !== b.length - a.length)
                return _.Df.log("Invalid cookie_policy domain: " + c),
                null;
            c = a;
            b = c.split(".").length - 1
        }
        return {
            domain: c,
            De: d,
            Jh: b
        }
    }
    ;
    mz = function(a) {
        var b = lz(a);
        if (!b)
            return new _.zy("G_USERSTATE_");
        a = ["G_USERSTATE_", _.uy && b.De ? "S" : "H", b.Jh].join("");
        var c = _.Jy[a];
        c || (c = {
            YD: 63072E3
        },
        _.te(_.My(b), c),
        c = new _.wy(a,c),
        _.Jy[a] = c,
        b = c.read(),
        "undefined" !== typeof b && null !== b && (document.cookie = a + "=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/",
        c.write(b)));
        return c
    }
    ;
    nz = function(a) {
        var b = mz(a).read();
        a = _.re();
        if (b) {
            b = b.split(":");
            for (var c; c = b.shift(); )
                c = c.split("="),
                a[c[0]] = c[1]
        }
        return a
    }
    ;
    oz = function(a, b, c) {
        var d = nz(b)
          , e = d[a];
        d[a] = "0";
        var f = [];
        _.am(d, function(k, l) {
            f.push(l + "=" + k)
        });
        var h = f.join(":");
        b = mz(b);
        h ? b.write(h) : b.clear();
        d[a] !== e && c && c()
    }
    ;
    pz = function(a, b) {
        b = nz(b);
        return "0" == b[a] || "X" == b[a]
    }
    ;
    qz = function(a) {
        a = lz(a.g_user_cookie_policy);
        if (!a || a.De && !_.uy)
            a = null;
        else {
            var b = ["G_AUTHUSER_", _.uy && a.De ? "S" : "H", a.Jh].join("")
              , c = _.Iy[b];
            c || (c = new _.Fy(b,_.My(a)),
            _.Iy[b] = c);
            a = c
        }
        _.Le("googleapis.config/sessionIndex", null);
        a.clear()
    }
    ;
    rz = function(a) {
        return $y(function(b) {
            return a[b]
        })
    }
    ;
    sz = 0;
    tz = !1;
    uz = [];
    vz = {};
    wz = {};
    xz = null;
    yz = function(a) {
        var b = _.Ty;
        return function(c) {
            if (this.f == b && this.t == _.If.Ul(this.f) && this.origin == _.If.hm(this.f))
                return a.apply(this, arguments)
        }
    }
    ;
    zz = function(a) {
        "function" === typeof a.setAttribute ? a.setAttribute("aria-hidden", "true") : a["aria-hidden"] = "true"
    }
    ;
    Az = function(a) {
        if (a && !decodeURIComponent(a).startsWith("m;/_/scs/"))
            throw Error("Aa");
    }
    ;
    Bz = function(a) {
        var b = _.Ne.jg
          , c = b(a).jsh;
        if (null != c)
            return Az(c),
            a;
        if (b = String(b().jsh || _.Be.h || ""))
            Az(b),
            c = (a + "#").indexOf("#"),
            a = a.substr(0, c) + (-1 !== a.substr(0, c).indexOf("?") ? "&" : "?") + "jsh=" + encodeURIComponent(b) + a.substr(c);
        return a
    }
    ;
    Cz = function() {
        return !!_.Ke("oauth-flow/usegapi")
    }
    ;
    Dz = function(a, b) {
        Cz() ? xz.unregister(a) : _.If.unregister(a + ":" + b)
    }
    ;
    Ez = function(a, b, c) {
        Cz() ? xz.register(a, c, _.ik) : _.If.register(a + ":" + b, yz(c))
    }
    ;
    Fz = function() {
        bz.parentNode.removeChild(bz)
    }
    ;
    Gz = function(a) {
        var b = bz;
        _.Ry(b, [{
            py: "-webkit-transform",
            duration: 1,
            timing: "ease",
            delay: 0
        }]);
        _.Ry(b, [{
            py: "transform",
            duration: 1,
            timing: "ease",
            delay: 0
        }]);
        _.Lx(function() {
            b.style.webkitTransform = "translate3d(0px," + a + "px,0px)";
            b.style.transform = "translate3d(0px," + a + "px,0px)"
        }, 0)
    }
    ;
    Hz = function() {
        var a = cz + 88;
        Gz(a);
        cz = a
    }
    ;
    Iz = function() {
        var a = cz - 88;
        Gz(a);
        cz = a
    }
    ;
    Jz = function(a) {
        var b = a ? Hz : Iz
          , c = a ? Iz : Hz;
        a = a ? "-" : "";
        cz = parseInt(a + 88, 10);
        bz.style.webkitTransform = "translate3d(0px," + a + 88 + "px,0px)";
        bz.style.transform = "translate3d(0px," + a + 88 + "px,0px)";
        bz.style.display = "";
        bz.style.visibility = "visible";
        b();
        _.Lx(c, 4E3);
        _.Lx(Fz, 5E3)
    }
    ;
    Kz = function(a) {
        var b = _.Ke("oauth-flow/toast/position");
        "top" !== b && (b = "bottom");
        var c = document.createElement("div");
        bz = c;
        c.style.cssText = "position:fixed;left:0px;z-index:1000;width:100%;";
        _.Or(c, "visibility", "hidden");
        _.Or(c, b, "-40px");
        _.Or(c, "height", "128px");
        var d = c;
        if (!_.Lq() && !_.Kq()) {
            d = document.createElement("div");
            d.style.cssText = "float:left;position:relative;left:50%;";
            c.appendChild(d);
            var e = document.createElement("div");
            e.style.cssText = "float:left;position:relative;left:-50%";
            d.appendChild(e);
            d = e
        }
        e = "top" == b ? "-" : "";
        cz = parseInt(e + 88, 10);
        bz.style.webkitTransform = "translate3d(0px," + e + 88 + "px,0px)";
        bz.style.transform = "translate3d(0px," + e + 88 + "px,0px)";
        e = window;
        try {
            for (; e.parent != e && e.parent.document; )
                e = e.parent
        } catch (f) {}
        e = e.document.body;
        try {
            e.insertBefore(c, e.firstChild)
        } catch (f) {}
        _.hk.openChild({
            url: ":socialhost:/:session_prefix:_/widget/oauthflow/toast",
            queryParams: {
                clientId: a.client_id,
                idToken: a.id_token
            },
            where: d,
            onRestyle: function() {
                "top" === b ? Jz(!0) : Jz(!1)
            }
        })
    }
    ;
    Lz = function(a) {
        var b = _.Jn()
          , c = b && b.scope;
        b = a && a.scope;
        b = "string" === typeof b ? b.split(" ") : b || [];
        if (c) {
            c = c.split(" ");
            for (var d = 0; d < c.length; ++d) {
                var e = c[d];
                -1 == _.Zl.call(b, e) && b.push(e)
            }
            0 < b.length && (a.scope = b.join(" "))
        }
        return a
    }
    ;
    Mz = function(a, b) {
        var c = null;
        a && b && (c = b.client_id = b.client_id || a.client_id,
        b.scope = b.scope || a.scope,
        b.g_user_cookie_policy = a.cookie_policy,
        b.cookie_policy = b.cookie_policy || a.cookie_policy,
        b.response_type = b.response_type || a.response_type);
        if (b) {
            b.issued_at || (b.issued_at = String(Math.floor((new Date).getTime() / 1E3)));
            var d = parseInt(b.expires_in, 10) || 86400;
            b.error && (d = _.Ke("oauth-flow/errorMaxAge") || 86400);
            b.expires_in = String(d);
            b.expires_at || (b.expires_at = String(Math.floor((new Date).getTime() / 1E3) + d));
            b._aa || b.error || null != iz(c) || !rz(a) || (b._aa = "1");
            a = b.status = {};
            a.google_logged_in = !!b.session_state;
            c = a.signed_in = !!b.access_token;
            a.method = c ? b["g-oauth-window"] ? "PROMPT" : "AUTO" : null
        }
        return b
    }
    ;
    Nz = function(a) {
        a = a && a.id_token;
        if (!a || !a.split(".")[1])
            return null;
        a = (a.split(".")[1] + "...").replace(/^((....)+)\.?\.?\.?$/, "$1");
        a = _.xf(_.Zy(a, !0));
        if (!1 === a)
            throw Error("Ba");
        return a
    }
    ;
    Oz = function(a) {
        return (a = Nz(a)) ? a.sub : null
    }
    ;
    Pz = function(a) {
        a && uz.push(a);
        a = _.Ty;
        var b = document.getElementById(a)
          , c = (new Date).getTime();
        if (b) {
            if (sz && 6E4 > c - sz)
                return;
            var d = _.If.Ul(a);
            d && (Dz("oauth2relayReady", d),
            Dz("oauth2callback", d));
            b.parentNode.removeChild(b);
            if (/Firefox/.test(navigator.userAgent))
                try {
                    window.frames[a] = void 0
                } catch (f) {}
            _.Uy();
            a = _.Ty
        }
        sz = c;
        var e = String(2147483647 * (0,
        _.vg)() | 0);
        b = _.Ke("oauth-flow/proxyUrl") || _.Ke("oauth-flow/relayUrl");
        Cz() ? xz = _.hk.openChild({
            where: _.Ne.GL(),
            url: b,
            id: a,
            attributes: {
                style: {
                    width: "1px",
                    height: "1px",
                    position: "absolute",
                    top: "-100px",
                    display: "none"
                },
                "aria-hidden": "true"
            },
            dontclear: !0
        }) : (b = [b, "?parent=", encodeURIComponent(_.ng.getOrigin(window.location.href)), "#rpctoken=", e, "&forcesecure=1"].join(""),
        c = _.Ne.GL(),
        d = _.Ne.qK({
            name: a,
            id: a
        }),
        d.src = Bz(b),
        d.style.width = "1px",
        d.style.height = "1px",
        d.style.position = "absolute",
        d.style.top = "-100px",
        d.tabIndex = -1,
        zz(d),
        c.appendChild(d),
        _.If.lt(a));
        Ez("oauth2relayReady", e, function() {
            Dz("oauth2relayReady", e);
            var f = uz;
            if (null !== f) {
                uz = null;
                for (var h = 0, k = f.length; h < k; ++h)
                    f[h]()
            }
        });
        Ez("oauth2callback", e, function(f) {
            var h = _.Ne.jg;
            h = h(f);
            var k = h.state;
            f = k.replace(/\|.*$/, "");
            f = {}.hasOwnProperty.call(wz, f) ? wz[f] : null;
            h.state = f;
            if (null != h.state) {
                f = vz[k];
                delete vz[k];
                k = f && f.key || "token";
                var l = h = Mz(f && f.params, h);
                var m = (m = Oz(l)) ? pz(m, l.cookie_policy) : !1;
                !m && l && 0 <= (" " + (l.scope || "") + " ").indexOf(" https://www.googleapis.com/auth/plus.login ") && _.Ke("isLoggedIn") && "1" === (l && l._aa) && (l._aa = "0",
                tz || (tz = !0,
                Kz(l)));
                _.kz(k, h);
                h = jz(k);
                if (f) {
                    k = f.popup;
                    l = f.after_redirect;
                    if (k && "keep_open" != l)
                        try {
                            k.close()
                        } catch (n) {}
                    f.callback && (f.callback(h),
                    f.callback = null)
                }
            }
        })
    }
    ;
    _.Qz = function(a) {
        null !== uz ? Pz(a) : a && a()
    }
    ;
    Sz = function(a, b) {
        var c = Rz
          , d = Oz(a);
        d && (qz(a),
        oz(d, b, function() {
            if (c) {
                var e = {
                    error: "user_signed_out"
                };
                e.client_id = a.client_id;
                e.g_user_cookie_policy = a.g_user_cookie_policy;
                e.scope = a.scope;
                e.response_type = a.response_type;
                e.session_state = a.session_state;
                e = Mz(null, e);
                c(e)
            }
        }))
    }
    ;
    Rz = function(a) {
        a || (a = jz(void 0, !0));
        a && "object" === typeof a || (a = {
            error: "invalid_request",
            error_description: "no callback data"
        });
        var b = a.error_description;
        b && window.console && (window.console.error(a.error),
        window.console.error(b));
        a.error || (_.Be.drw = null);
        _.kz(a);
        if (b = a.authuser)
            _.Ke("googleapis.config/sessionIndex"),
            _.Le("googleapis.config/sessionIndex", b);
        _.Vy.Rm(_.Wy, a);
        return a
    }
    ;
    Tz = ["client_id", "cookie_policy", "response_type"];
    Uz = "client_id response_type login_hint authuser prompt include_granted_scopes after_redirect access_type hl state".split(" ");
    Vz = function(a) {
        var b = _.mj(a);
        b.session_state && b.session_state.extraQueryParams && (b.authuser = b.session_state.extraQueryParams.authuser);
        b.session_state = null;
        a.expires_at && (b.expires_at = parseInt(a.expires_at / 1E3).toString());
        a.expires_in && (b.expires_in = a.expires_in.toString());
        a.first_issued_at && (b.issued_at = parseInt(a.first_issued_at / 1E3).toString(),
        delete b.first_issued_at);
        _.aw(b);
        return b
    }
    ;
    Wz = function(a) {
        if (void 0 === a.include_granted_scopes) {
            var b = _.Ke("include_granted_scopes");
            a.include_granted_scopes = !!b
        }
    }
    ;
    Xz = function(a) {
        window.console && ("function" === typeof window.console.warn ? window.console.warn(a) : "function" === typeof window.console.log && window.console.log(a))
    }
    ;
    Yz = function(a) {
        var b = a || {}
          , c = {};
        _.Sb(Uz, function(d) {
            null != b[d] && (c[d] = b[d])
        });
        a = _.Ke("googleapis/overrideClientId");
        null != a && (c.client_id = a);
        Wz(c);
        "string" === typeof b.scope ? c.scope = b.scope : Array.isArray(b.scope) && (c.scope = b.scope.join(" "));
        null != b["openid.realm"] && (c.openid_realm = b["openid.realm"]);
        null != b.cookie_policy ? c.cookie_policy = b.cookie_policy : null != b.cookiepolicy && (c.cookie_policy = b.cookiepolicy);
        null == c.login_hint && null != b.user_id && (c.login_hint = b.user_id);
        try {
            _.Pw(c.cookie_policy)
        } catch (d) {
            c.cookie_policy && Xz("The cookie_policy configuration: '" + c.cookie_policy + "' is illegal, and thus ignored."),
            delete c.cookie_policy
        }
        null != b.hd && (c.hosted_domain = b.hd);
        null == c.prompt && (1 == b.immediate || "true" == b.immediate ? c.prompt = "none" : "force" == b.approval_prompt && (c.prompt = "consent"));
        "none" == c.prompt && (c.session_selection = "first_valid");
        "none" == c.prompt && "offline" == c.access_type && delete c.access_type;
        "undefined" === typeof c.authuser && (a = _.Eh(),
        null != a && (c.authuser = a));
        a = b.redirect_uri || _.Ke("oauth-flow/redirectUri");
        null != a && "postmessage" != a && (c.redirect_uri = a);
        c.gsiwebsdk = "shim";
        return c
    }
    ;
    Zz = function(a, b) {
        var c = Yz(a)
          , d = new _.Lj(function(e, f) {
            _.wx(c, function(h) {
                var k = h || {};
                _.Sb(Tz, function(l) {
                    null == k[l] && (k[l] = c[l])
                });
                !c.include_granted_scopes && a && a.scope && (k.scope = a.scope);
                a && null != a.state && (k.state = a.state);
                k.error ? ("none" == c.prompt && "user_logged_out" == k.error && (k.error = "immediate_failed_user_logged_out"),
                f(k)) : (h = Vz(k),
                null != h.authuser && _.Le("googleapis.config/sessionIndex", h.authuser),
                e(h))
            })
        }
        );
        b && d.then(b, b);
        return d
    }
    ;
    $z = _.Sh.EL;
    aA = null;
    _.dA = function(a, b) {
        if ("force" !== a.approvalprompt) {
            a = _.bA(a);
            a.prompt = "none";
            delete a.redirect_uri;
            delete a.approval_prompt;
            delete a.immediate;
            if (b = !b)
                aA ? (a.client_id !== aA.client_id && window.console && window.console.log && window.console.log("Ignoring mismatched page-level auth param client_id=" + a.client_id),
                b = !0) : (aA = a,
                b = !1);
            b || cA(a)
        }
    }
    ;
    _.bA = function(a) {
        var b = a.redirecturi || "postmessage"
          , c = (0,
        _.oc)((a.scope || "").replace(/[\s\xa0]+/g, " "));
        b = {
            client_id: a.clientid,
            redirect_uri: b,
            response_type: "code token id_token gsession",
            scope: c
        };
        a.approvalprompt && (b.approval_prompt = a.approvalprompt);
        a.state && (b.state = a.state);
        a.openidrealm && (b["openid.realm"] = a.openidrealm);
        c = "offline" == a.accesstype ? !0 : (c = a.redirecturi) && "postmessage" != c;
        c && (b.access_type = "offline");
        a.requestvisibleactions && (b.request_visible_actions = (0,
        _.oc)(a.requestvisibleactions.replace(/[\s\xa0]+/g, " ")));
        a.after_redirect && (b.after_redirect = a.after_redirect);
        a.cookiepolicy && "none" !== a.cookiepolicy && (b.cookie_policy = a.cookiepolicy);
        "undefined" != typeof a.includegrantedscopes && (b.include_granted_scopes = a.includegrantedscopes);
        a.e && (b.e = a.e);
        (a = a.authuser || _.Ke("googleapis.config/sessionIndex")) && (b.authuser = a);
        (a = _.Ke("useoriginassocialhost")) && (b.use_origin_as_socialhost = a);
        return b
    }
    ;
    cA = function(a) {
        _.zo("waaf0", "signin", "0");
        Zz(a, function(b) {
            _.zo("waaf1", "signin", "0");
            Rz(b)
        })
    }
    ;
    _.eA = function(a) {
        a = _.bA(a);
        _.Le("oauth-flow/authWindowWidth", 445);
        _.Le("oauth-flow/authWindowHeight", 615);
        cA(a)
    }
    ;
    _.fA = function(a) {
        _.Vy.unsubscribe(_.Wy, a);
        _.Vy.subscribe(_.Wy, a)
    }
    ;
    var yA, LA;
    _.hA = function(a) {
        return a.cookiepolicy ? !0 : (_.gA("cookiepolicy is a required field.  See https://developers.google.com/+/web/signin/#button_attr_cookiepolicy for more information."),
        !1)
    }
    ;
    _.gA = function(a) {
        window.console && (window.console.error ? window.console.error(a) : window.console.log && window.console.log(a))
    }
    ;
    _.lA = function(a, b) {
        var c = _.Jn();
        _.te(a, c);
        c = Lz(c);
        if (_.hA(c)) {
            var d = _.iA();
            _.jA(c);
            b ? _.Ae(b, "click", function() {
                _.kA(c, d)
            }) : _.kA(c, d)
        }
    }
    ;
    _.iA = function() {
        var a = new yA;
        _.fA(function(b) {
            a.ZD && b && (b.access_token && _.Le("isPlusUser", !0),
            b["g-oauth-window"] && (a.ZD = !1,
            _.Df.warn("OTA app install is no longer supported.")))
        });
        return a
    }
    ;
    yA = function() {
        this.ZD = !1
    }
    ;
    _.jA = function(a) {
        a = _.JA(a);
        _.KA(a.callback);
        _.Qz(function() {
            _.dA(a)
        })
    }
    ;
    _.JA = function(a) {
        LA(a);
        a.redirecturi && delete a.redirecturi;
        az(function(b) {
            return a[b]
        }) || (a.authuser = 0);
        return a
    }
    ;
    LA = function(a) {
        /^\s*$/.test(a.scope || "") && (a.scope = "https://www.googleapis.com/auth/plus.login")
    }
    ;
    _.KA = function(a) {
        if ("string" === typeof a)
            if (window[a])
                a = window[a];
            else {
                _.gA('Callback function named "' + a + '" not found');
                return
            }
        a && _.fA(a)
    }
    ;
    _.kA = function(a, b) {
        b.ZD = !0;
        a = _.JA(a);
        _.eA(a)
    }
    ;
    _.I("gapi.auth.authorize", Zz);
    _.I("gapi.auth.checkSessionState", function(a, b) {
        var c = _.re();
        c.client_id = a.client_id;
        c.session_state = a.session_state;
        _.Qz(function() {
            Cz() ? xz.send("check_session_state", c, function(d) {
                b.call(null, d[0])
            }, _.ik) : _.If.call(_.Ty, "check_session_state", yz(function(d) {
                b.call(null, d)
            }), c.session_state, c.client_id)
        })
    });
    _.I("gapi.auth.getAuthHeaderValueForFirstParty", $z);
    _.I("gapi.auth.getToken", jz);
    _.I("gapi.auth.getVersionInfo", function(a, b) {
        _.Qz(function() {
            var c = _.Qh() || ""
              , d = null
              , e = null;
            c && (e = c.split(" "),
            2 == e.length && (d = e[1]));
            d ? Cz() ? xz.send("get_versioninfo", {
                xapisidHash: d,
                sessionIndex: b
            }, function(f) {
                a(f[0])
            }, _.ik) : _.If.call(_.Ty, "get_versioninfo", yz(function(f) {
                a(f)
            }), d, b) : a()
        })
    });
    _.I("gapi.auth.init", _.Qz);
    _.I("gapi.auth.setToken", _.kz);
    _.I("gapi.auth.signIn", function(a) {
        _.lA(a)
    });
    _.I("gapi.auth.signOut", function() {
        var a = jz();
        a && Sz(a, a.cookie_policy)
    });
    _.I("gapi.auth.unsafeUnpackIdToken", Nz);
    _.I("gapi.auth._pimf", _.dA);
    _.I("gapi.auth._oart", Kz);
    _.I("gapi.auth._guss", function(a) {
        return mz(a).read()
    });

    var MA = _.Jn();
    MA.clientid && MA.scope && MA.callback && !_.Ke("disableRealtimeCallback") && _.jA(MA);

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var Bx = function() {};
    Bx.prototype.RJ = null;
    Bx.prototype.getOptions = function() {
        var a;
        (a = this.RJ) || (a = {},
        _.Cx(this) && (a[0] = !0,
        a[1] = !0),
        a = this.RJ = a);
        return a
    }
    ;
    var Ex;
    Ex = function() {}
    ;
    _.$a(Ex, Bx);
    _.Cx = function(a) {
        if (!a.hN && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
            for (var b = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], c = 0; c < b.length; c++) {
                var d = b[c];
                try {
                    return new ActiveXObject(d),
                    a.hN = d
                } catch (e) {}
            }
            throw Error("sa");
        }
        return a.hN
    }
    ;
    _.Dx = new Ex;

    _.qg = window.googleapis && window.googleapis.server || {};

    var wg = function(a) {
        return {
            execute: function(b) {
                var c = {
                    method: a.httpMethod || "GET",
                    root: a.root,
                    path: a.url,
                    params: a.urlParams,
                    headers: a.headers,
                    body: a.body
                }
                  , d = window.gapi
                  , e = function() {
                    var f = d.config.get("client/apiKey")
                      , h = d.config.get("client/version");
                    try {
                        var k = d.config.get("googleapis.config/developerKey")
                          , l = d.config.get("client/apiKey", k);
                        d.config.update("client/apiKey", l);
                        d.config.update("client/version", "1.0.0-alpha");
                        var m = d.client;
                        m.request.call(m, c).then(b, b)
                    } finally {
                        d.config.update("client/apiKey", f),
                        d.config.update("client/version", h)
                    }
                };
                d.client ? e() : d.load.call(d, "client", e)
            }
        }
    }, xg = function(a, b) {
        return function(c) {
            var d = {};
            c = c.body;
            var e = _.xf(c)
              , f = {};
            if (e && e.length)
                for (var h = 0, k = e.length; h < k; ++h) {
                    var l = e[h];
                    f[l.id] = l
                }
            h = 0;
            for (k = b.length; h < k; ++h)
                l = b[h].id,
                d[l] = e && e.length ? f[l] : e;
            a(d, c)
        }
    }, yg = function(a) {
        a.transport = {
            name: "googleapis",
            execute: function(b, c) {
                for (var d = [], e = 0, f = b.length; e < f; ++e) {
                    var h = b[e]
                      , k = h.method
                      , l = String(k).split(".")[0];
                    l = _.Ke("googleapis.config/versions/" + k) || _.Ke("googleapis.config/versions/" + l) || "v1";
                    d.push({
                        jsonrpc: "2.0",
                        id: h.id,
                        method: k,
                        apiVersion: String(l),
                        params: h.params
                    })
                }
                b = wg({
                    httpMethod: "POST",
                    root: a.transport.root,
                    url: "/rpc?pp=0",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: d
                });
                b.execute.call(b, xg(c, d))
            },
            root: void 0
        }
    }, zg = function(a) {
        var b = this.method
          , c = this.transport;
        c.execute.call(c, [{
            method: b,
            id: b,
            params: this.rpc
        }], function(d) {
            d = d[b];
            d.error || (d = d.data || d.result);
            a(d)
        })
    }, Bg = function() {
        for (var a = Ag, b = a.split("."), c = function(k) {
            k = k || {};
            k.groupId = k.groupId || "@self";
            k.userId = k.userId || "@viewer";
            k = {
                method: a,
                rpc: k || {}
            };
            yg(k);
            k.execute = zg;
            return k
        }, d = _.D, e = 0, f = b.length; e < f; ++e) {
            var h = d[b[e]] || {};
            e + 1 == f && (h = c);
            d = d[b[e]] = h
        }
        if (1 < b.length && "googleapis" != b[0])
            for (b[0] = "googleapis",
            "delete" == b[b.length - 1] && (b[b.length - 1] = "remove"),
            d = _.D,
            e = 0,
            f = b.length; e < f; ++e)
                h = d[b[e]] || {},
                e + 1 == f && (h = c),
                d = d[b[e]] = h
    }, Ag;
    for (Ag in _.Ke("googleapis.config/methods"))
        Bg();
    _.I("googleapis.newHttpRequest", function(a) {
        return wg(a)
    });
    _.I("googleapis.setUrlParameter", function(a, b) {
        if ("trace" !== a)
            throw Error("w");
        _.Le("client/trace", b)
    });

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.mh = function(a) {
        return null == a ? "" : String(a)
    }
    ;
    _.nh = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    _.oh = function(a, b) {
        if (!b)
            return a;
        var c = a.indexOf("#");
        0 > c && (c = a.length);
        var d = a.indexOf("?");
        if (0 > d || d > c) {
            d = c;
            var e = ""
        } else
            e = a.substring(d + 1, c);
        a = [a.substr(0, d), e, a.substr(c)];
        c = a[1];
        a[1] = b ? c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    }
    ;
    _.ph = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++)
                _.ph(a, String(b[d]), c);
        else
            null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    }
    ;
    _.qh = function(a) {
        var b = [], c;
        for (c in a)
            _.ph(c, a[c], b);
        return b.join("&")
    }
    ;
    _.rh = function(a, b) {
        b = _.qh(b);
        return _.oh(a, b)
    }
    ;

    var ei = function(a, b) {
        a = _.Ne.qK({
            id: a,
            name: a
        });
        a.style.width = "1px";
        a.style.height = "1px";
        a.style.position = "absolute";
        a.style.top = "-100px";
        a.style.display = "none";
        if (window.navigator) {
            var c = window.navigator.userAgent || "";
            var d = window.navigator.product || "";
            c = 0 != c.indexOf("Opera") && -1 == c.indexOf("WebKit") && "Gecko" == d && 0 < c.indexOf("rv:1.")
        } else
            c = !1;
        a.src = c ? "about:blank" : b;
        a.tabIndex = -1;
        "function" === typeof a.setAttribute ? a.setAttribute("aria-hidden", "true") : a["aria-hidden"] = "true";
        document.body.appendChild(a);
        c && (a.src = b);
        return a
    };
    _.Sh = {
        NM: _.Rh,
        h_: _.Oh,
        dM: function() {
            var a = null;
            _.Oh() && (a = window.__PVT,
            null == a && (a = (new _.Gh(document)).get("BEAT")));
            return a
        },
        EL: _.Qh
    };
    var gi, fi;
    gi = function() {
        return !!fi("auth/useFirstPartyAuthV2")
    }
    ;
    fi = function(a) {
        return _.Ke("googleapis.config/" + a)
    }
    ;
    _.hi = function(a, b, c) {
        a = void 0 === a ? {} : a;
        b = void 0 === b ? window.location.href : b;
        c = void 0 === c ? "auto" : c;
        if ("none" == c)
            return a;
        var d = a.Authorization
          , e = a.OriginToken;
        if (!d && !e) {
            (e = _.Uh()) && e.access_token && ("oauth2" == c || "auto" == c) && (d = String(e.token_type || "Bearer") + " " + e.access_token);
            if (e = !d)
                e = (!!fi("auth/useFirstPartyAuth") || "1p" == c) && "oauth2" != c;
            if (e && _.Oh()) {
                if (gi()) {
                    d = fi("primaryEmail");
                    c = fi("appDomain");
                    e = fi("fogId");
                    var f = [];
                    d && f.push({
                        key: "e",
                        value: d
                    });
                    c && f.push({
                        key: "a",
                        value: c
                    });
                    e && f.push({
                        key: "u",
                        value: e
                    });
                    d = _.Qh(f)
                } else
                    d = _.Qh();
                d && (b = _.Eh(b),
                b = a["X-Goog-AuthUser"] || b,
                _.nc(_.mh(b)) && (!gi() || gi() && _.nc(_.mh(fi("primaryEmail"))) && _.nc(_.mh(fi("appDomain"))) && _.nc(_.mh(fi("fogId")))) && (b = "0"),
                _.nc(_.mh(b)) || (a["X-Goog-AuthUser"] = b))
            }
            d ? a.Authorization = d : !1 !== fi("auth/useOriginToken") && (e = _.Sh.dM()) && (a.OriginToken = e)
        }
        return a
    }
    ;
    _.ii = function() {
        function a(n, q, p, t, v) {
            var u = f("proxy");
            if (t || !u) {
                u = f("root");
                var w = f("root-1p") || u;
                u = u || "https://content.googleapis.com";
                w = w || "https://clients6.google.com";
                var z = f("xd3") || "/static/proxy.html";
                u = (t || String(q ? w : u)) + z
            }
            u = String(u);
            p && (u += (0 <= u.indexOf("?") ? "&" : "?") + "usegapi=1");
            (q = _.Ne.jg().jsh || _.Be.h) && (u += (0 <= u.indexOf("?") ? "&" : "?") + "jsh=" + encodeURIComponent(q));
            u += "#parent=" + encodeURIComponent(null != v ? String(v) : _.ng.getOrigin(document.location.href));
            return u + ("&rpctoken=" + n)
        }
        function b(n, q, p, t, v) {
            var u = d(p, t, v);
            k[u] || (p = ei(u, q),
            _.If.register("ready:" + n, function() {
                _.If.unregister("ready:" + n);
                if (!l[u]) {
                    l[u] = !0;
                    var w = m[u];
                    m[u] = [];
                    for (var z = 0, E = w.length; z < E; ++z) {
                        var A = w[z];
                        e(A.Vm, A.K1, A.callback)
                    }
                }
            }),
            _.If.lt(u, q),
            k[u] = p)
        }
        function c(n, q, p) {
            var t = String(2147483647 * _.ai() | 0)
              , v = a(t, n, q, p);
            _.Ff(function() {
                b(t, v, n, q, p)
            })
        }
        function d(n, q, p) {
            n = a("", n, q, p, "");
            p = h[n + q];
            if (!p) {
                p = new _.ug;
                p.Nt(n);
                p = p.Ih().toLowerCase();
                var t = _.ai();
                p += t;
                h[n + q] = p
            }
            return "apiproxy" + p
        }
        function e(n, q, p) {
            var t = void 0
              , v = !1;
            if ("makeHttpRequests" !== n)
                throw 'only "makeHttpRequests" RPCs are implemented';
            var u = function(y) {
                if (y) {
                    if ("undefined" != typeof t && "undefined" != typeof y.root && t != y.root)
                        throw "all requests in a batch must have the same root URL";
                    t = y.root || t;
                    v = _.Sh.NM(y.headers)
                }
            };
            if (q)
                for (var w = 0, z = q.length; w < z; ++w) {
                    var E = q[w];
                    E && u(E.params)
                }
            u = !!f("useGapiForXd3");
            var A = d(v, u, t);
            k[A] || c(v, u, t);
            l[A] ? _.If.call(A, n, function(y) {
                if (this.f == A && this.t == _.If.Ul(this.f) && this.origin == _.If.hm(this.f)) {
                    var J = _.xf(y);
                    p(J, y)
                }
            }, q) : (m[A] || (m[A] = []),
            m[A].push({
                Vm: n,
                K1: q,
                callback: p
            }))
        }
        function f(n) {
            return _.Ke("googleapis.config/" + n)
        }
        var h = {}
          , k = {}
          , l = {}
          , m = {};
        return {
            kba: function(n, q, p) {
                return _.hi(n, q, p)
            },
            zp: e
        }
    }();

    var Cg = {
        V4: "Authorization",
        qS: "Content-ID",
        t5: "Content-Transfer-Encoding",
        u5: "Content-Type",
        Z5: "Date",
        Y8: "OriginToken",
        t7: "hotrod-board-name",
        u7: "hotrod-chrome-cpu-model",
        v7: "hotrod-chrome-processors",
        Daa: "WWW-Authenticate",
        Eaa: "X-ClientDetails",
        Faa: "X-Compass-Routing-Destination",
        Gaa: "X-Goog-AuthUser",
        Jaa: "X-Goog-Encode-Response-If-Executable",
        Kaa: "X-Goog-Meeting-ABR",
        Laa: "X-Goog-Meeting-Botguardid",
        Maa: "X-Goog-Meeting-ClientInfo",
        Naa: "X-Goog-Meeting-ClientVersion",
        Oaa: "X-Goog-Meeting-Debugid",
        Paa: "X-Goog-Meeting-Identifier",
        Qaa: "X-Goog-Meeting-RtcClient",
        Raa: "X-Goog-Meeting-StartSource",
        Saa: "X-Goog-Meeting-Token",
        Taa: "X-Goog-Meeting-ViewerInfo",
        Uaa: "X-Goog-PageId",
        Vaa: "X-Goog-Safety-Content-Type",
        Waa: "X-Goog-Safety-Encoding",
        Haa: "X-Goog-Drive-Client-Version",
        Iaa: "X-Goog-Drive-Resource-Keys",
        Xaa: "X-HTTP-Method-Override",
        Yaa: "X-JavaScript-User-Agent",
        Zaa: "X-Origin",
        $aa: "X-Referer",
        aba: "X-Requested-With",
        cba: "X-Use-HTTP-Status-Code-Override",
        bba: "X-Server-Timeout"
    }
      , Dg = "Accept Accept-Language Authorization Cache-Control cast-device-capabilities Content-Disposition Content-Encoding Content-Language Content-Length Content-MD5 Content-Range Content-Transfer-Encoding Content-Type Date developer-token EES-S7E-MODE financial-institution-id GData-Version google-cloud-resource-prefix hotrod-board-name hotrod-chrome-cpu-model hotrod-chrome-processors Host If-Match If-Modified-Since If-None-Match If-Unmodified-Since linked-customer-id login-customer-id MIME-Version Origin OriginToken Pragma Range request-id Slug Transfer-Encoding Want-Digest x-alkali-account-key x-alkali-application-key x-alkali-auth-apps-namespace x-alkali-auth-entities-namespace x-alkali-auth-entity x-alkali-client-locale x-chrome-connected x-framework-xsrf-token X-Client-Data X-ClientDetails X-Client-Version X-Firebase-Locale X-GData-Client X-GData-Key X-Goog-AuthUser X-Goog-PageId X-Goog-Encode-Response-If-Executable X-GoogApps-Allowed-Domains X-Goog-AdX-Buyer-Impersonation X-Goog-Api-Client X-Goog-Api-Key X-Goog-Visibilities X-Goog-Correlation-Id X-Goog-Request-Info X-Goog-Request-Reason X-Goog-Experiments x-goog-ext-124712974-jspb x-goog-ext-251363160-jspb x-goog-ext-259736195-jspb x-goog-ext-275505673-bin X-Goog-Firebase-Installations-Auth X-Firebase-Client X-Firebase-Client-Log-Type X-Firebase-GMPID X-Firebase-Auth-Token X-Firebase-AppCheck X-Goog-Drive-Client-Version X-Goog-Drive-Resource-Keys x-goog-iam-authority-selector x-goog-iam-authorization-token x-goog-request-params X-Goog-Sn-Metadata X-Goog-Sn-PatientId X-Goog-Spatula X-Goog-Travel-Bgr X-Goog-Travel-Settings X-Goog-Upload-Command X-Goog-Upload-Content-Disposition X-Goog-Upload-Content-Length X-Goog-Upload-Content-Type X-Goog-Upload-File-Name X-Goog-Upload-Header-Content-Encoding X-Goog-Upload-Header-Content-Length X-Goog-Upload-Header-Content-Type X-Goog-Upload-Header-Transfer-Encoding X-Goog-Upload-Offset X-Goog-Upload-Protocol X-Goog-User-Project X-Goog-Visitor-Id X-Goog-FieldMask X-Google-Project-Override X-HTTP-Method-Override X-JavaScript-User-Agent X-Pan-Versionid X-Proxied-User-IP X-Origin X-Referer X-Requested-With X-Stadia-Client-Context X-Upload-Content-Length X-Upload-Content-Type X-Use-HTTP-Status-Code-Override X-Ios-Bundle-Identifier X-Android-Package X-Ariane-Xsrf-Token X-Earth-Engine-App-ID-Token X-Earth-Engine-Computation-Profile X-Earth-Engine-Computation-Profiling X-Play-Console-Experiments-Override X-Play-Console-Session-Id X-YouTube-VVT X-YouTube-Page-CL X-YouTube-Page-Timestamp X-Compass-Routing-Destination X-Goog-Meeting-ABR X-Goog-Meeting-Botguardid X-Goog-Meeting-ClientInfo X-Goog-Meeting-ClientVersion X-Goog-Meeting-Debugid X-Goog-Meeting-Identifier X-Goog-Meeting-RtcClient X-Goog-Meeting-StartSource X-Goog-Meeting-Token X-Goog-Meeting-ViewerInfo x-sdm-id-token X-Sfdc-Authorization X-Server-Timeout".split(" ")
      , Eg = "Digest Cache-Control Content-Disposition Content-Encoding Content-Language Content-Length Content-MD5 Content-Range Content-Transfer-Encoding Content-Type Date ETag Expires Last-Modified Location Pragma Range Server Transfer-Encoding WWW-Authenticate Vary Unzipped-Content-MD5 X-Correlation-ID X-Debug-Tracking-Id X-Goog-Generation X-Goog-Metageneration X-Goog-Safety-Content-Type X-Goog-Safety-Encoding X-Google-Trace X-Goog-Upload-Chunk-Granularity X-Goog-Upload-Control-URL X-Goog-Upload-Size-Received X-Goog-Upload-Status X-Goog-Upload-URL X-Goog-Diff-Download-Range X-Goog-Hash X-Goog-Updated-Authorization X-Server-Object-Version X-Guploader-Customer X-Guploader-Upload-Result X-Guploader-Uploadid X-Google-Gfe-Backend-Request-Cost X-Earth-Engine-Computation-Profile X-Goog-Meeting-ABR X-Goog-Meeting-Botguardid X-Goog-Meeting-ClientInfo X-Goog-Meeting-ClientVersion X-Goog-Meeting-Debugid X-Goog-Meeting-RtcClient X-Goog-Meeting-Token X-Compass-Routing-Destination".split(" ");
    var Fg, Gg, Hg, Ig, Kg, Lg, Mg, Ng, Og, Pg, Qg, Rg;
    Fg = null;
    Gg = null;
    Hg = null;
    Ig = function(a, b) {
        var c = a.length;
        if (c != b.length)
            return !1;
        for (var d = 0; d < c; ++d) {
            var e = a.charCodeAt(d)
              , f = b.charCodeAt(d);
            65 <= e && 90 >= e && (e += 32);
            65 <= f && 90 >= f && (f += 32);
            if (e != f)
                return !1
        }
        return !0
    }
    ;
    _.Jg = function(a) {
        a = String(a || "").split("\x00").join("");
        for (var b = [], c = !0, d = 0, e = a.length; d < e; ++d) {
            var f = a.charAt(d)
              , h = a.charCodeAt(d);
            if (55296 <= h && 56319 >= h && d + 1 < e) {
                var k = a.charAt(d + 1)
                  , l = a.charCodeAt(d + 1);
                56320 <= l && 57343 >= l && (f += k,
                h = 65536 + (h - 55296 << 10) + (l - 56320),
                ++d)
            }
            if (!(0 <= h && 1114109 >= h) || 55296 <= h && 57343 >= h || 64976 <= h && 65007 >= h || 65534 == (h & 65534))
                h = 65533,
                f = String.fromCharCode(h);
            k = !(32 <= h && 126 >= h) || " " == f || c && ":" == f || "\\" == f;
            !c || "/" != f && "?" != f || (c = !1);
            "%" == f && (d + 2 >= e ? k = !0 : (l = 16 * parseInt(a.charAt(d + 1), 16) + parseInt(a.charAt(d + 2), 16),
            0 <= l && 255 >= l ? (h = l,
            f = 0 == h ? "" : "%" + (256 + l).toString(16).toUpperCase().substr(1),
            d += 2) : k = !0));
            k && (f = encodeURIComponent(f),
            1 >= f.length && (0 <= h && 127 >= h ? f = "%" + (256 + h).toString(16).toUpperCase().substr(1) : (h = 65533,
            f = encodeURIComponent(String.fromCharCode(h)))));
            b.push(f)
        }
        a = b.join("");
        a = a.split("#")[0];
        a = a.split("?");
        b = a[0].split("/");
        c = [];
        d = 0;
        for (e = b.length; d < e; ++d)
            f = b[d],
            h = f.split("%2E").join("."),
            h = h.split(encodeURIComponent("\uff0e")).join("."),
            "." == h ? d + 1 == e && c.push("") : ".." == h ? (0 < c.length && c.pop(),
            d + 1 == e && c.push("")) : c.push(f);
        a[0] = c.join("/");
        for (a = a.join("?"); a && "/" == a.charAt(0); )
            a = a.substr(1);
        return "/" + a
    }
    ;
    Kg = {
        "access-control-allow-origin": !0,
        "access-control-allow-credentials": !0,
        "access-control-expose-headers": !0,
        "access-control-max-age": !0,
        "access-control-allow-headers": !0,
        "access-control-allow-methods": !0,
        p3p: !0,
        "proxy-authenticate": !0,
        "set-cookie": !0,
        "set-cookie2": !0,
        status: !0,
        tsv: !0,
        "": !0
    };
    Lg = {
        "accept-charset": !0,
        "accept-encoding": !0,
        "access-control-request-headers": !0,
        "access-control-request-method": !0,
        "client-ip": !0,
        clientip: !0,
        connection: !0,
        "content-length": !0,
        cookie: !0,
        cookie2: !0,
        date: !0,
        dnt: !0,
        expect: !0,
        forwarded: !0,
        "forwarded-for": !0,
        "front-end-https": !0,
        host: !0,
        "keep-alive": !0,
        "max-forwards": !0,
        method: !0,
        origin: !0,
        "raw-post-data": !0,
        referer: !0,
        te: !0,
        trailer: !0,
        "transfer-encoding": !0,
        upgrade: !0,
        url: !0,
        "user-agent": !0,
        version: !0,
        via: !0,
        "x-att-deviceid": !0,
        "x-chrome-connected": !0,
        "x-client-data": !0,
        "x-client-ip": !0,
        "x-do-not-track": !0,
        "x-forwarded-by": !0,
        "x-forwarded-for": !0,
        "x-forwarded-host": !0,
        "x-forwarded-proto": !0,
        "x-geo": !0,
        "x-googapps-allowed-domains": !0,
        "x-origin": !0,
        "x-proxyuser-ip": !0,
        "x-real-ip": !0,
        "x-referer": !0,
        "x-uidh": !0,
        "x-user-ip": !0,
        "x-wap-profile": !0,
        "": !0
    };
    Mg = function(a) {
        if (!_.Eb(a))
            return null;
        for (var b = {}, c = 0; c < a.length; c++) {
            var d = a[c];
            if ("string" === typeof d && d) {
                var e = d.toLowerCase();
                Ig(d, e) && (b[e] = d)
            }
        }
        for (var f in Cg)
            Object.prototype.hasOwnProperty.call(Cg, f) && (d = Cg[f],
            e = d.toLowerCase(),
            Ig(d, e) && Object.prototype.hasOwnProperty.call(b, e) && (b[e] = d));
        return b
    }
    ;
    Ng = new RegExp("(" + /[\t -~\u00A0-\u2027\u202A-\uD7FF\uE000-\uFFFF]/.source + "|" + /[\uD800-\uDBFF][\uDC00-\uDFFF]/.source + "){1,100}","g");
    Og = /[ \t]*(\r?\n[ \t]+)+/g;
    Pg = /^[ \t]+|[ \t]+$/g;
    Qg = function(a, b) {
        if (!b && "object" === typeof a && a && "number" === typeof a.length) {
            b = a;
            a = "";
            for (var c = 0, d = b.length; c < d; ++c) {
                var e = Qg(b[c], !0);
                e && (a && (e = a + ", " + e),
                a = e)
            }
        }
        if ("string" === typeof a && (a = a.replace(Og, " "),
        a = a.replace(Pg, ""),
        "" == a.replace(Ng, "") && a))
            return a
    }
    ;
    Rg = /^[-0-9A-Za-z!#\$%&'\*\+\.\^_`\|~]+$/g;
    _.Sg = function(a) {
        if ("string" !== typeof a || !a || !a.match(Rg))
            return null;
        a = a.toLowerCase();
        if (null == Hg) {
            var b = []
              , c = _.Ke("googleapis/headers/response");
            c && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            (c = _.Ke("client/headers/response")) && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            b = b.concat(Eg);
            (c = _.Ke("googleapis/headers/request")) && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            (c = _.Ke("client/headers/request")) && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            b = b.concat(Dg);
            for (var d in Cg)
                Object.prototype.hasOwnProperty.call(Cg, d) && b.push(Cg[d]);
            Hg = Mg(b)
        }
        return null != Hg && Hg.hasOwnProperty(a) ? Hg[a] : a
    }
    ;
    _.Tg = function(a, b) {
        if (!_.Sg(a) || !Qg(b))
            return null;
        a = a.toLowerCase();
        if (a.match(/^x-google|^x-gfe|^proxy-|^sec-/i) || Lg[a])
            return null;
        if (null == Fg) {
            b = [];
            var c = _.Ke("googleapis/headers/request");
            c && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            (c = _.Ke("client/headers/request")) && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            b = b.concat(Dg);
            Fg = Mg(b)
        }
        return null != Fg && Fg.hasOwnProperty(a) ? Fg[a] : null
    }
    ;
    _.Ug = function(a, b) {
        if (!_.Sg(a) || !Qg(b))
            return null;
        a = a.toLowerCase();
        if (Kg[a])
            return null;
        if (null == Gg) {
            b = [];
            var c = _.Ke("googleapis/headers/response");
            c && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            (c = _.Ke("client/headers/response")) && "object" === typeof c && "number" === typeof c.length || (c = null);
            null != c && (b = b.concat(c));
            b = b.concat(Eg);
            Gg = Mg(b)
        }
        return null != Gg && Gg.hasOwnProperty(a) ? a : null
    }
    ;
    _.Vg = function(a, b) {
        if (_.Sg(b) && null != a && "object" === typeof a) {
            var c = void 0, d;
            for (d in a)
                if (Object.prototype.hasOwnProperty.call(a, d) && Ig(d, b)) {
                    var e = Qg(a[d]);
                    e && (void 0 !== c && (e = c + ", " + e),
                    c = e)
                }
            return c
        }
    }
    ;
    _.Wg = function(a, b, c, d) {
        var e = _.Sg(b);
        if (e) {
            c && (c = Qg(c));
            b = b.toLowerCase();
            for (var f in a)
                Object.prototype.hasOwnProperty.call(a, f) && Ig(f, b) && delete a[f];
            c && (d || (b = e),
            a[b] = c)
        }
    }
    ;
    _.Xg = function(a, b) {
        var c = {};
        if (!a)
            return c;
        a = a.split("\r\n");
        for (var d = 0, e = a.length; d < e; ++d) {
            var f = a[d];
            if (!f)
                break;
            var h = f.indexOf(":");
            if (!(0 >= h)) {
                var k = f.substring(0, h);
                if (k = _.Sg(k)) {
                    for (f = f.substring(h + 1); d + 1 < e && a[d + 1].match(/^[ \t]/); )
                        f += "\r\n" + a[d + 1],
                        ++d;
                    if (f = Qg(f))
                        if (k = _.Ug(k, f) || (b ? void 0 : k))
                            k = k.toLowerCase(),
                            h = _.Vg(c, k),
                            void 0 !== h && (f = h + ", " + f),
                            _.Wg(c, k, f, !0)
                }
            }
        }
        return c
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Rt = function() {
        return Date.now()
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var Fx;
    _.Gx = function(a) {
        return (new Fx).Xc(a)
    }
    ;
    Fx = function() {}
    ;
    Fx.prototype.Xc = function(a) {
        var b = [];
        Hx(this, a, b);
        return b.join("")
    }
    ;
    var Hx = function(a, b, c) {
        if (null == b)
            c.push("null");
        else {
            if ("object" == typeof b) {
                if (Array.isArray(b)) {
                    var d = b;
                    b = d.length;
                    c.push("[");
                    for (var e = "", f = 0; f < b; f++)
                        c.push(e),
                        Hx(a, d[f], c),
                        e = ",";
                    c.push("]");
                    return
                }
                if (b instanceof String || b instanceof Number || b instanceof Boolean)
                    b = b.valueOf();
                else {
                    c.push("{");
                    e = "";
                    for (d in b)
                        Object.prototype.hasOwnProperty.call(b, d) && (f = b[d],
                        "function" != typeof f && (c.push(e),
                        Ix(d, c),
                        c.push(":"),
                        Hx(a, f, c),
                        e = ","));
                    c.push("}");
                    return
                }
            }
            switch (typeof b) {
            case "string":
                Ix(b, c);
                break;
            case "number":
                c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
                break;
            case "boolean":
                c.push(String(b));
                break;
            case "function":
                c.push("null");
                break;
            default:
                throw Error("ua`" + typeof b);
            }
        }
    }
      , Jx = {
        '"': '\\"',
        "\\": "\\\\",
        "/": "\\/",
        "\b": "\\b",
        "\f": "\\f",
        "\n": "\\n",
        "\r": "\\r",
        "\t": "\\t",
        "\x0B": "\\u000b"
    }
      , Kx = /\uffff/.test("\uffff") ? /[\\"\x00-\x1f\x7f-\uffff]/g : /[\\"\x00-\x1f\x7f-\xff]/g
      , Ix = function(a, b) {
        b.push('"', a.replace(Kx, function(c) {
            var d = Jx[c];
            d || (d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).substr(1),
            Jx[c] = d);
            return d
        }), '"')
    };

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.Nx = function(a, b) {
        a.src = _.ic(b);
        var c;
        b = (a.ownerDocument && a.ownerDocument.defaultView || window).document;
        var d = null === (c = b.querySelector) || void 0 === c ? void 0 : c.call(b, "script[nonce]");
        (c = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    }
    ;
    _.Ox = function(a, b) {
        a = a.split(".");
        b = b || _.D;
        for (var c = 0; c < a.length; c++)
            if (b = b[a[c]],
            null == b)
                return null;
        return b
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var Sx, Tx, Wx, $x, by;
    _.Px = function(a) {
        if (!Array.isArray(a))
            for (var b = a.length - 1; 0 <= b; b--)
                delete a[b];
        a.length = 0
    }
    ;
    _.Qx = function(a, b) {
        var c = _.Eb(b)
          , d = c ? b : arguments;
        for (c = c ? 0 : 1; c < d.length; c++) {
            if (null == a)
                return;
            a = a[d[c]]
        }
        return a
    }
    ;
    _.Rx = function(a) {
        if (!a || "object" !== typeof a)
            return a;
        if ("function" === typeof a.clone)
            return a.clone();
        if ("undefined" !== typeof Map && a instanceof Map)
            return new Map(a);
        if ("undefined" !== typeof Set && a instanceof Set)
            return new Set(a);
        var b = Array.isArray(a) ? [] : "function" !== typeof ArrayBuffer || "function" !== typeof ArrayBuffer.isView || !ArrayBuffer.isView(a) || a instanceof DataView ? {} : new a.constructor(a.length), c;
        for (c in a)
            b[c] = _.Rx(a[c]);
        return b
    }
    ;
    Sx = function(a) {
        var b = {};
        a.forEach(function(c) {
            b[c[0]] = c[1]
        });
        return function(c) {
            return b[c.find(function(d) {
                return d in b
            })] || ""
        }
    }
    ;
    Tx = function() {
        var a = _.qb;
        if (_.tb()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1])
                a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a),
                    "7.0" == c[1])
                        if (a && a[1])
                            switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                            }
                        else
                            b = "7.0";
                    else
                        b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("(\\w[\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        for (var d; d = c.exec(a); )
            b.push([d[1], d[2], d[3] || void 0]);
        a = Sx(b);
        return _.sb() ? a(["Version", "Opera"]) : _.rb("Edge") ? a(["Edge"]) : _.rb("Edg/") ? a(["Edg"]) : _.wb() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    }
    ;
    _.Ux = function(a) {
        return 0 <= _.Ac(Tx(), a)
    }
    ;
    _.Vx = function(a) {
        return (a = _.Cx(a)) ? new ActiveXObject(a) : new XMLHttpRequest
    }
    ;
    Wx = function(a, b) {
        var c = [];
        for (b = b || 0; b < a.length; b += 2)
            _.ph(a[b], a[b + 1], c);
        return c.join("&")
    }
    ;
    _.Xx = function(a, b) {
        var c = 2 == arguments.length ? Wx(arguments[1], 0) : Wx(arguments, 1);
        return _.oh(a, c)
    }
    ;
    _.Yx = function(a, b, c) {
        c = null != c ? "=" + encodeURIComponent(String(c)) : "";
        return _.oh(a, b + c)
    }
    ;
    _.Zx = function(a, b) {
        _.Ai(a, "/") && (a = a.substr(0, a.length - 1));
        _.mc(b, "/") && (b = b.substr(1));
        return a + "/" + b
    }
    ;
    $x = {};
    _.ay = function(a) {
        if ($x[a])
            return $x[a];
        a = String(a);
        if (!$x[a]) {
            var b = /function\s+([^\(]+)/m.exec(a);
            $x[a] = b ? b[1] : "[Anonymous]"
        }
        return $x[a]
    }
    ;
    by = function(a, b) {
        var c = [];
        if (_.lb(b, a))
            c.push("[...circular reference...]");
        else if (a && 50 > b.length) {
            c.push(_.ay(a) + "(");
            for (var d = a.arguments, e = 0; d && e < d.length; e++) {
                0 < e && c.push(", ");
                var f = d[e];
                switch (typeof f) {
                case "object":
                    f = f ? "object" : "null";
                    break;
                case "string":
                    break;
                case "number":
                    f = String(f);
                    break;
                case "boolean":
                    f = f ? "true" : "false";
                    break;
                case "function":
                    f = (f = _.ay(f)) ? f : "[fn]";
                    break;
                default:
                    f = typeof f
                }
                40 < f.length && (f = f.substr(0, 40) + "...");
                c.push(f)
            }
            b.push(a);
            c.push(")\n");
            try {
                c.push(by(a.caller, b))
            } catch (h) {
                c.push("[exception trying to get caller]\n")
            }
        } else
            a ? c.push("[...long stack...]") : c.push("[end]");
        return c.join("")
    }
    ;
    _.cy = function(a) {
        var b = Error();
        if (Error.captureStackTrace)
            Error.captureStackTrace(b, a || _.cy),
            b = String(b.stack);
        else {
            try {
                throw b;
            } catch (c) {
                b = c
            }
            b = (b = b.stack) ? String(b) : null
        }
        b || (b = by(a || arguments.callee.caller, []));
        return b
    }
    ;
    _.dy = function(a) {
        switch (a) {
        case 200:
        case 201:
        case 202:
        case 204:
        case 206:
        case 304:
        case 1223:
            return !0;
        default:
            return !1
        }
    }
    ;
    _.ey = function(a, b) {
        _.dj.call(this);
        this.Ok = a || 1;
        this.Ct = b || _.D;
        this.NJ = (0,
        _.R)(this.a4, this);
        this.cO = _.Rt()
    }
    ;
    _.$a(_.ey, _.dj);
    _.g = _.ey.prototype;
    _.g.enabled = !1;
    _.g.uc = null;
    _.g.setInterval = function(a) {
        this.Ok = a;
        this.uc && this.enabled ? (this.stop(),
        this.start()) : this.uc && this.stop()
    }
    ;
    _.g.a4 = function() {
        if (this.enabled) {
            var a = _.Rt() - this.cO;
            0 < a && a < .8 * this.Ok ? this.uc = this.Ct.setTimeout(this.NJ, this.Ok - a) : (this.uc && (this.Ct.clearTimeout(this.uc),
            this.uc = null),
            this.dispatchEvent("tick"),
            this.enabled && (this.stop(),
            this.start()))
        }
    }
    ;
    _.g.start = function() {
        this.enabled = !0;
        this.uc || (this.uc = this.Ct.setTimeout(this.NJ, this.Ok),
        this.cO = _.Rt())
    }
    ;
    _.g.stop = function() {
        this.enabled = !1;
        this.uc && (this.Ct.clearTimeout(this.uc),
        this.uc = null)
    }
    ;
    _.g.na = function() {
        _.ey.H.na.call(this);
        this.stop();
        delete this.Ct
    }
    ;
    var gy, hy, iy;
    _.fy = function(a) {
        _.dj.call(this);
        this.headers = new Map;
        this.Zz = a || null;
        this.vf = !1;
        this.Yz = this.La = null;
        this.mx = "";
        this.Po = 0;
        this.ym = this.tD = this.Iw = this.GB = !1;
        this.rn = 0;
        this.Zc = null;
        this.jl = "";
        this.ZH = this.Dg = !1;
        this.KH = null
    }
    ;
    _.$a(_.fy, _.dj);
    _.fy.prototype.ob = null;
    gy = /^https?$/i;
    hy = ["POST", "PUT"];
    iy = [];
    _.jy = function(a, b, c, d, e, f, h) {
        var k = new _.fy;
        iy.push(k);
        b && k.V("complete", b);
        k.Uo("ready", k.jV);
        f && k.ZG(f);
        h && (k.Dg = h);
        k.send(a, c, d, e)
    }
    ;
    _.fy.prototype.jV = function() {
        this.Ga();
        _.wi(iy, this)
    }
    ;
    _.fy.prototype.ZG = function(a) {
        this.rn = Math.max(0, a)
    }
    ;
    _.fy.prototype.setTrustToken = function(a) {
        this.KH = a
    }
    ;
    _.fy.prototype.send = function(a, b, c, d) {
        if (this.La)
            throw Error("xa`" + this.mx + "`" + a);
        b = b ? b.toUpperCase() : "GET";
        this.mx = a;
        this.Po = 0;
        this.GB = !1;
        this.vf = !0;
        this.La = this.Zz ? _.Vx(this.Zz) : _.Vx(_.Dx);
        this.Yz = this.Zz ? this.Zz.getOptions() : _.Dx.getOptions();
        this.La.onreadystatechange = (0,
        _.R)(this.VO, this);
        try {
            this.tD = !0,
            this.La.open(b, String(a), !0),
            this.tD = !1
        } catch (h) {
            this.qv(5, h);
            return
        }
        a = c || "";
        c = new Map(this.headers);
        if (d)
            if (Object.getPrototypeOf(d) === Object.prototype)
                for (var e in d)
                    c.set(e, d[e]);
            else if ("function" === typeof d.keys && "function" === typeof d.get) {
                e = _.Ba(d.keys());
                for (var f = e.next(); !f.done; f = e.next())
                    f = f.value,
                    c.set(f, d.get(f))
            } else
                throw Error("ya`" + String(d));
        d = Array.from(c.keys()).find(function(h) {
            return "content-type" == h.toLowerCase()
        });
        e = _.D.FormData && a instanceof _.D.FormData;
        !_.lb(hy, b) || d || e || c.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        b = _.Ba(c);
        for (d = b.next(); !d.done; d = b.next())
            c = _.Ba(d.value),
            d = c.next().value,
            c = c.next().value,
            this.La.setRequestHeader(d, c);
        this.jl && (this.La.responseType = this.jl);
        "withCredentials"in this.La && this.La.withCredentials !== this.Dg && (this.La.withCredentials = this.Dg);
        if ("setTrustToken"in this.La && this.KH)
            try {
                this.La.setTrustToken(this.KH)
            } catch (h) {}
        try {
            ky(this),
            0 < this.rn && ((this.ZH = ly(this.La)) ? (this.La.timeout = this.rn,
            this.La.ontimeout = (0,
            _.R)(this.Ag, this)) : this.Zc = _.Lx(this.Ag, this.rn, this)),
            this.Iw = !0,
            this.La.send(a),
            this.Iw = !1
        } catch (h) {
            this.qv(5, h)
        }
    }
    ;
    var ly = function(a) {
        return _.hd && _.Dd(9) && "number" === typeof a.timeout && void 0 !== a.ontimeout
    };
    _.fy.prototype.Ag = function() {
        "undefined" != typeof _.Xa && this.La && (this.Po = 8,
        this.dispatchEvent("timeout"),
        this.abort(8))
    }
    ;
    _.fy.prototype.qv = function(a) {
        this.vf = !1;
        this.La && (this.ym = !0,
        this.La.abort(),
        this.ym = !1);
        this.Po = a;
        my(this);
        ny(this)
    }
    ;
    var my = function(a) {
        a.GB || (a.GB = !0,
        a.dispatchEvent("complete"),
        a.dispatchEvent("error"))
    };
    _.fy.prototype.abort = function(a) {
        this.La && this.vf && (this.vf = !1,
        this.ym = !0,
        this.La.abort(),
        this.ym = !1,
        this.Po = a || 7,
        this.dispatchEvent("complete"),
        this.dispatchEvent("abort"),
        ny(this))
    }
    ;
    _.fy.prototype.na = function() {
        this.La && (this.vf && (this.vf = !1,
        this.ym = !0,
        this.La.abort(),
        this.ym = !1),
        ny(this, !0));
        _.fy.H.na.call(this)
    }
    ;
    _.fy.prototype.VO = function() {
        this.isDisposed() || (this.tD || this.Iw || this.ym ? oy(this) : this.tE())
    }
    ;
    _.fy.prototype.tE = function() {
        oy(this)
    }
    ;
    var oy = function(a) {
        if (a.vf && "undefined" != typeof _.Xa && (!a.Yz[1] || 4 != _.py(a) || 2 != a.getStatus()))
            if (a.Iw && 4 == _.py(a))
                _.Lx(a.VO, 0, a);
            else if (a.dispatchEvent("readystatechange"),
            4 == _.py(a)) {
                a.vf = !1;
                try {
                    _.qy(a) ? (a.dispatchEvent("complete"),
                    a.dispatchEvent("success")) : (a.Po = 6,
                    my(a))
                } finally {
                    ny(a)
                }
            }
    }
      , ny = function(a, b) {
        if (a.La) {
            ky(a);
            var c = a.La
              , d = a.Yz[0] ? _.Cb : null;
            a.La = null;
            a.Yz = null;
            b || a.dispatchEvent("ready");
            try {
                c.onreadystatechange = d
            } catch (e) {}
        }
    }
      , ky = function(a) {
        a.La && a.ZH && (a.La.ontimeout = null);
        a.Zc && (_.Mx(a.Zc),
        a.Zc = null)
    };
    _.fy.prototype.Uc = function() {
        return !!this.La
    }
    ;
    _.qy = function(a) {
        var b = a.getStatus(), c;
        if (!(c = _.dy(b))) {
            if (b = 0 === b)
                a = String(a.mx).match(_.nh)[1] || null,
                !a && _.D.self && _.D.self.location && (a = _.D.self.location.protocol,
                a = a.substr(0, a.length - 1)),
                b = !gy.test(a ? a.toLowerCase() : "");
            c = b
        }
        return c
    }
    ;
    _.py = function(a) {
        return a.La ? a.La.readyState : 0
    }
    ;
    _.fy.prototype.getStatus = function() {
        try {
            return 2 < _.py(this) ? this.La.status : -1
        } catch (a) {
            return -1
        }
    }
    ;
    _.ry = function(a) {
        try {
            return a.La ? a.La.responseText : ""
        } catch (b) {
            return ""
        }
    }
    ;
    _.sy = function(a) {
        try {
            if (!a.La)
                return null;
            if ("response"in a.La)
                return a.La.response;
            switch (a.jl) {
            case "":
            case "text":
                return a.La.responseText;
            case "arraybuffer":
                if ("mozResponseArrayBuffer"in a.La)
                    return a.La.mozResponseArrayBuffer
            }
            return null
        } catch (b) {
            return null
        }
    }
    ;
    _.fy.prototype.getResponseHeader = function(a) {
        if (this.La && 4 == _.py(this))
            return a = this.La.getResponseHeader(a),
            null === a ? void 0 : a
    }
    ;
    _.fy.prototype.getAllResponseHeaders = function() {
        return this.La && 4 == _.py(this) ? this.La.getAllResponseHeaders() || "" : ""
    }
    ;
    _.vi(function(a) {
        _.fy.prototype.tE = a(_.fy.prototype.tE)
    });

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    _.St = function(a) {
        var b = 0, c;
        for (c in a)
            b++;
        return b
    }
    ;
    _.Tt = function(a) {
        var b = [], c = 0, d;
        for (d in a)
            b[c++] = a[d];
        return b
    }
    ;
    _.Ut = function(a) {
        var b = [], c = 0, d;
        for (d in a)
            b[c++] = d;
        return b
    }
    ;
    _.Vt = function(a) {
        return a.Eb && "function" == typeof a.Eb ? a.Eb() : _.Eb(a) || "string" === typeof a ? a.length : _.St(a)
    }
    ;
    _.Wt = function(a) {
        if (a.Sc && "function" == typeof a.Sc)
            return a.Sc();
        if ("undefined" !== typeof Map && a instanceof Map || "undefined" !== typeof Set && a instanceof Set)
            return Array.from(a.values());
        if ("string" === typeof a)
            return a.split("");
        if (_.Eb(a)) {
            for (var b = [], c = a.length, d = 0; d < c; d++)
                b.push(a[d]);
            return b
        }
        return _.Tt(a)
    }
    ;
    _.Xt = function(a) {
        if (a.Ef && "function" == typeof a.Ef)
            return a.Ef();
        if (!a.Sc || "function" != typeof a.Sc) {
            if ("undefined" !== typeof Map && a instanceof Map)
                return Array.from(a.keys());
            if (!("undefined" !== typeof Set && a instanceof Set)) {
                if (_.Eb(a) || "string" === typeof a) {
                    var b = [];
                    a = a.length;
                    for (var c = 0; c < a; c++)
                        b.push(c);
                    return b
                }
                return _.Ut(a)
            }
        }
    }
    ;

    /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
    var $t, du, qu, lu, uu, mu, ou, nu, ru, pu, vu;
    _.Yt = function(a) {
        if (!(a instanceof Array)) {
            a = _.Ba(a);
            for (var b, c = []; !(b = a.next()).done; )
                c.push(b.value);
            a = c
        }
        return a
    }
    ;
    _.Zt = function() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ _.Rt()).toString(36)
    }
    ;
    $t = function(a, b) {
        if (a) {
            a = a.split("&");
            for (var c = 0; c < a.length; c++) {
                var d = a[c].indexOf("=")
                  , e = null;
                if (0 <= d) {
                    var f = a[c].substring(0, d);
                    e = a[c].substring(d + 1)
                } else
                    f = a[c];
                b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
            }
        }
    }
    ;
    _.au = function(a, b, c, d) {
        for (var e = c.length; 0 <= (b = a.indexOf(c, b)) && b < d; ) {
            var f = a.charCodeAt(b - 1);
            if (38 == f || 63 == f)
                if (f = a.charCodeAt(b + e),
                !f || 61 == f || 38 == f || 35 == f)
                    return b;
            b += e + 1
        }
        return -1
    }
    ;
    _.bu = /#|$/;
    _.cu = function(a, b) {
        var c = a.search(_.bu)
          , d = _.au(a, 0, b, c);
        if (0 > d)
            return null;
        var e = a.indexOf("&", d);
        if (0 > e || e > c)
            e = c;
        d += b.length + 1;
        return decodeURIComponent(a.substr(d, e - d).replace(/\+/g, " "))
    }
    ;
    du = function(a, b, c) {
        if (a.forEach && "function" == typeof a.forEach)
            a.forEach(b, c);
        else if (_.Eb(a) || "string" === typeof a)
            Array.prototype.forEach.call(a, b, c);
        else
            for (var d = _.Xt(a), e = _.Wt(a), f = e.length, h = 0; h < f; h++)
                b.call(c, e[h], d && d[h], a)
    }
    ;
    _.eu = function(a, b) {
        this.Vd = this.Cg = this.Sf = "";
        this.Pf = null;
        this.$B = this.Wk = "";
        this.kg = !1;
        var c;
        a instanceof _.eu ? (this.kg = void 0 !== b ? b : a.kg,
        _.fu(this, a.Sf),
        _.gu(this, a.Cg),
        _.hu(this, a.eg()),
        _.iu(this, a.Pf),
        this.setPath(a.getPath()),
        _.ju(this, a.Wc.clone()),
        this.Bj(a.Nv())) : a && (c = String(a).match(_.nh)) ? (this.kg = !!b,
        _.fu(this, c[1] || "", !0),
        _.gu(this, c[2] || "", !0),
        _.hu(this, c[3] || "", !0),
        _.iu(this, c[4]),
        this.setPath(c[5] || "", !0),
        _.ju(this, c[6] || "", !0),
        this.Bj(c[7] || "", !0)) : (this.kg = !!b,
        this.Wc = new _.ku(null,this.kg))
    }
    ;
    _.eu.prototype.toString = function() {
        var a = []
          , b = this.Sf;
        b && a.push(lu(b, mu, !0), ":");
        var c = this.eg();
        if (c || "file" == b)
            a.push("//"),
            (b = this.Cg) && a.push(lu(b, mu, !0), "@"),
            a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
            c = this.Pf,
            null != c && a.push(":", String(c));
        if (c = this.getPath())
            this.Vd && "/" != c.charAt(0) && a.push("/"),
            a.push(lu(c, "/" == c.charAt(0) ? nu : ou, !0));
        (c = this.Wc.toString()) && a.push("?", c);
        (c = this.Nv()) && a.push("#", lu(c, pu));
        return a.join("")
    }
    ;
    _.eu.prototype.resolve = function(a) {
        var b = this.clone()
          , c = !!a.Sf;
        c ? _.fu(b, a.Sf) : c = !!a.Cg;
        c ? _.gu(b, a.Cg) : c = !!a.Vd;
        c ? _.hu(b, a.eg()) : c = null != a.Pf;
        var d = a.getPath();
        if (c)
            _.iu(b, a.Pf);
        else if (c = !!a.Wk) {
            if ("/" != d.charAt(0))
                if (this.Vd && !this.Wk)
                    d = "/" + d;
                else {
                    var e = b.getPath().lastIndexOf("/");
                    -1 != e && (d = b.getPath().substr(0, e + 1) + d)
                }
            e = d;
            if (".." == e || "." == e)
                d = "";
            else if (_.pb(e, "./") || _.pb(e, "/.")) {
                d = _.mc(e, "/");
                e = e.split("/");
                for (var f = [], h = 0; h < e.length; ) {
                    var k = e[h++];
                    "." == k ? d && h == e.length && f.push("") : ".." == k ? ((1 < f.length || 1 == f.length && "" != f[0]) && f.pop(),
                    d && h == e.length && f.push("")) : (f.push(k),
                    d = !0)
                }
                d = f.join("/")
            } else
                d = e
        }
        c ? b.setPath(d) : c = a.Bo();
        c ? _.ju(b, a.Wc.clone()) : c = !!a.$B;
        c && b.Bj(a.Nv());
        return b
    }
    ;
    _.eu.prototype.clone = function() {
        return new _.eu(this)
    }
    ;
    _.fu = function(a, b, c) {
        a.Sf = c ? qu(b, !0) : b;
        a.Sf && (a.Sf = a.Sf.replace(/:$/, ""));
        return a
    }
    ;
    _.gu = function(a, b, c) {
        a.Cg = c ? qu(b) : b;
        return a
    }
    ;
    _.eu.prototype.eg = function() {
        return this.Vd
    }
    ;
    _.hu = function(a, b, c) {
        a.Vd = c ? qu(b, !0) : b;
        return a
    }
    ;
    _.iu = function(a, b) {
        if (b) {
            b = Number(b);
            if (isNaN(b) || 0 > b)
                throw Error("L`" + b);
            a.Pf = b
        } else
            a.Pf = null;
        return a
    }
    ;
    _.eu.prototype.getPath = function() {
        return this.Wk
    }
    ;
    _.eu.prototype.setPath = function(a, b) {
        this.Wk = b ? qu(a, !0) : a;
        return this
    }
    ;
    _.eu.prototype.Bo = function() {
        return "" !== this.Wc.toString()
    }
    ;
    _.ju = function(a, b, c) {
        b instanceof _.ku ? (a.Wc = b,
        a.Wc.bG(a.kg)) : (c || (b = lu(b, ru)),
        a.Wc = new _.ku(b,a.kg));
        return a
    }
    ;
    _.eu.prototype.Ra = function(a, b) {
        return _.ju(this, a, b)
    }
    ;
    _.eu.prototype.getQuery = function() {
        return this.Wc.toString()
    }
    ;
    _.su = function(a, b, c) {
        a.Wc.set(b, c);
        return a
    }
    ;
    _.g = _.eu.prototype;
    _.g.Zg = function(a) {
        return this.Wc.get(a)
    }
    ;
    _.g.Nv = function() {
        return this.$B
    }
    ;
    _.g.Bj = function(a, b) {
        this.$B = b ? qu(a) : a;
        return this
    }
    ;
    _.g.removeParameter = function(a) {
        this.Wc.remove(a);
        return this
    }
    ;
    _.g.bG = function(a) {
        this.kg = a;
        this.Wc && this.Wc.bG(a)
    }
    ;
    _.tu = function(a, b) {
        return a instanceof _.eu ? a.clone() : new _.eu(a,b)
    }
    ;
    qu = function(a, b) {
        return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
    }
    ;
    lu = function(a, b, c) {
        return "string" === typeof a ? (a = encodeURI(a).replace(b, uu),
        c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
        a) : null
    }
    ;
    uu = function(a) {
        a = a.charCodeAt(0);
        return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
    }
    ;
    mu = /[#\/\?@]/g;
    ou = /[#\?:]/g;
    nu = /[#\?]/g;
    ru = /[#\?@]/g;
    pu = /#/g;
    _.ku = function(a, b) {
        this.Ud = this.yc = null;
        this.Df = a || null;
        this.kg = !!b
    }
    ;
    vu = function(a) {
        a.yc || (a.yc = new Map,
        a.Ud = 0,
        a.Df && $t(a.Df, function(b, c) {
            a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
        }))
    }
    ;
    _.g = _.ku.prototype;
    _.g.Eb = function() {
        vu(this);
        return this.Ud
    }
    ;
    _.g.add = function(a, b) {
        vu(this);
        this.Df = null;
        a = wu(this, a);
        var c = this.yc.get(a);
        c || this.yc.set(a, c = []);
        c.push(b);
        this.Ud += 1;
        return this
    }
    ;
    _.g.remove = function(a) {
        vu(this);
        a = wu(this, a);
        return this.yc.has(a) ? (this.Df = null,
        this.Ud -= this.yc.get(a).length,
        this.yc.delete(a)) : !1
    }
    ;
    _.g.clear = function() {
        this.yc = this.Df = null;
        this.Ud = 0
    }
    ;
    _.g.isEmpty = function() {
        vu(this);
        return 0 == this.Ud
    }
    ;
    _.g.re = function(a) {
        vu(this);
        a = wu(this, a);
        return this.yc.has(a)
    }
    ;
    _.g.Ui = function(a) {
        var b = this.Sc();
        return _.lb(b, a)
    }
    ;
    _.g.forEach = function(a, b) {
        vu(this);
        this.yc.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    }
    ;
    _.g.Ef = function() {
        vu(this);
        for (var a = Array.from(this.yc.values()), b = Array.from(this.yc.keys()), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], f = 0; f < e.length; f++)
                c.push(b[d]);
        return c
    }
    ;
    _.g.Sc = function(a) {
        vu(this);
        var b = [];
        if ("string" === typeof a)
            this.re(a) && (b = b.concat(this.yc.get(wu(this, a))));
        else {
            a = Array.from(this.yc.values());
            for (var c = 0; c < a.length; c++)
                b = b.concat(a[c])
        }
        return b
    }
    ;
    _.g.set = function(a, b) {
        vu(this);
        this.Df = null;
        a = wu(this, a);
        this.re(a) && (this.Ud -= this.yc.get(a).length);
        this.yc.set(a, [b]);
        this.Ud += 1;
        return this
    }
    ;
    _.g.get = function(a, b) {
        if (!a)
            return b;
        a = this.Sc(a);
        return 0 < a.length ? String(a[0]) : b
    }
    ;
    _.g.setValues = function(a, b) {
        this.remove(a);
        0 < b.length && (this.Df = null,
        this.yc.set(wu(this, a), _.mb(b)),
        this.Ud += b.length)
    }
    ;
    _.g.toString = function() {
        if (this.Df)
            return this.Df;
        if (!this.yc)
            return "";
        for (var a = [], b = Array.from(this.yc.keys()), c = 0; c < b.length; c++) {
            var d = b[c]
              , e = encodeURIComponent(String(d));
            d = this.Sc(d);
            for (var f = 0; f < d.length; f++) {
                var h = e;
                "" !== d[f] && (h += "=" + encodeURIComponent(String(d[f])));
                a.push(h)
            }
        }
        return this.Df = a.join("&")
    }
    ;
    _.g.clone = function() {
        var a = new _.ku;
        a.Df = this.Df;
        this.yc && (a.yc = new Map(this.yc),
        a.Ud = this.Ud);
        return a
    }
    ;
    var wu = function(a, b) {
        b = String(b);
        a.kg && (b = b.toLowerCase());
        return b
    };
    _.ku.prototype.bG = function(a) {
        a && !this.kg && (vu(this),
        this.Df = null,
        this.yc.forEach(function(b, c) {
            var d = c.toLowerCase();
            c != d && (this.remove(c),
            this.setValues(d, b))
        }, this));
        this.kg = a
    }
    ;
    _.ku.prototype.extend = function(a) {
        for (var b = 0; b < arguments.length; b++)
            du(arguments[b], function(c, d) {
                this.add(d, c)
            }, this)
    }
    ;

    var OA = function(a) {
        if (!a || "function" !== typeof a)
            throw new NA("Must provide a function.");
        this.Qf = null;
        this.gW = a
    }, PA = function(a) {
        return new _.Lj(function(b) {
            var c = a.length
              , d = [];
            if (c)
                for (var e = function(k, l, m) {
                    c--;
                    d[k] = l ? {
                        zv: !0,
                        value: m
                    } : {
                        zv: !1,
                        reason: m
                    };
                    0 == c && b(d)
                }, f = 0, h; f < a.length; f++)
                    h = a[f],
                    _.Sj(h, _.ri(e, f, !0), _.ri(e, f, !1));
            else
                b(d)
        }
        )
    }, QA, RA, SA, TA = {
        KJ: function(a) {
            QA = a;
            try {
                delete TA.KJ
            } catch (b) {}
        },
        LJ: function(a) {
            RA = a;
            try {
                delete TA.LJ
            } catch (b) {}
        },
        MJ: function(a) {
            SA = a;
            try {
                delete TA.MJ
            } catch (b) {}
        }
    }, UA = function(a) {
        return _.dy(a.status)
    }, VA = function() {
        var a = !0
          , b = _.Vx(_.Dx);
        b && void 0 !== b.withCredentials || (a = !1);
        return a
    }, WA = function(a, b) {
        if (null == b)
            return b;
        b = String(b);
        b.match(/^\/\/.*/) && (b = ("http:" == window.location.protocol ? "http:" : "https:") + b);
        b.match(/^\/([^\/].*)?$/) && window.location.host && String(window.location.protocol).match(/^https?:$/) && (b = window.location.protocol + "//" + window.location.host + b);
        var c = b.match(/^(https?:)(\/\/)?(\/([^\/].*)?)?$/i);
        c && window.location.host && String(window.location.protocol).match(/^https?:$/) && (b = c[1] + "//" + window.location.host + (c[3] || ""));
        b = b.replace(/^(https?:\/\/[^\/?#@]*)\/$/i, "$1");
        b = b.replace(/^(http:\/\/[-_a-z0-9.]+):0*80([\/?#].*)?$/i, "$1$2");
        b = b.replace(/^(https:\/\/[-_a-z0-9.]+):0*443([\/?#].*)?$/i, "$1$2");
        b.match(/^https?:\/\/[-_a-z0-9.]*[-_a-z][-_a-z0-9.]*$/i) && (b = b.toLowerCase());
        c = _.Ke("client/rewrite");
        _.Bb(c) && Object.prototype.hasOwnProperty.call(c, b) ? b = String(c[b] || b) : (b = b.replace(/^(https?):\/\/www\.googleapis\.com$/, "$1://content.googleapis.com"),
        b = b.replace(/^(https?):\/\/www-(googleapis-[-_a-z0-9]+\.[-_a-z0-9]+\.google\.com)$/, "$1://content-$2"),
        b.match(/^https?:\/\/content(-[-_a-z0-9.]+)?\.googleapis\.com$/) || (b = b.replace(/^(https?):\/\/([-_a-z0-9]+(\.[-_a-z0-9]+)?\.googleapis\.com)$/, "$1://content-$2")));
        a && (a = _.Ke("client/firstPartyRewrite"),
        _.Bb(a) && Object.prototype.hasOwnProperty.call(a, b) ? b = String(a[b] || b) : (b = b.replace(/^(https?):\/\/content\.googleapis\.com$/, "$1://clients6.google.com"),
        b = b.replace(/^(https?):\/\/content-([-a-z0-9]+)\.([-a-z0-9]+)\.googleapis\.com$/, "$1://$2-googleapis.$3.google.com"),
        b = b.replace(/^(https?):\/\/content-([-a-z0-9]+)\.googleapis\.com$/, "$1://$2.clients6.google.com"),
        b = b.replace(/^(https?):\/\/([-a-z0-9]+)-www-googleapis\.([-a-z0-9]+).google.com$/, "$1://content-googleapis-$2.$3.google.com")));
        return b
    }, NA = function(a) {
        _.jb.call(this, a)
    };
    _.O(NA, _.jb);
    NA.prototype.name = "gapix.client.GapiClientError";
    OA.prototype.then = function(a, b, c) {
        this.Qf || (this.Qf = this.gW());
        return this.Qf.then(a, b, c)
    }
    ;
    OA.prototype.kz = function(a) {
        this.Qf || (this.Qf = a)
    }
    ;
    var XA = function(a) {
        var b = {}, c;
        for (c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                var d = _.Vg(a, c);
                d && (c = _.Ug(c, d)) && _.Wg(b, c, d, !0)
            }
        return b
    }
      , YA = {
        error: {
            code: -1,
            message: "A network error occurred and the request could not be completed."
        }
    }
      , ZA = function(a, b, c, d) {
        _.fy.call(this);
        this.$c = a;
        this.cE = b;
        this.od = c;
        a = {};
        if (d)
            for (var e in d)
                Object.prototype.hasOwnProperty.call(d, e) && (b = _.Vg(d, e),
                void 0 !== b && (e = _.Tg(e, b)) && _.Wg(a, e, b));
        d = {};
        for (e in a)
            Object.prototype.hasOwnProperty.call(a, e) && (d[unescape(encodeURIComponent(e))] = unescape(encodeURIComponent(a[e])));
        this.Lr = d;
        this.Qf = null
    };
    _.O(ZA, _.fy);
    ZA.prototype.then = function(a) {
        this.Qf || (this.Qf = (new _.Lj(function(b, c) {
            this.V("error", (0,
            _.R)(function() {
                c($A(this))
            }, this));
            this.V("success", (0,
            _.R)(function() {
                b($A(this))
            }, this));
            this.send(this.$c, this.cE, this.od, this.Lr)
        }
        ,this)).then(function(b) {
            b.headers = XA(b.headers);
            return b
        }, function(b) {
            return b.status ? (b.headers = XA(b.headers),
            _.Qj(b)) : _.Qj({
                result: YA,
                body: '{"error":{"code":-1,"message":"A network error occurred and the request could not be completed."}}',
                headers: null,
                status: null,
                statusText: null
            })
        }));
        return this.Qf.then.apply(this.Qf, arguments)
    }
    ;
    var $A = function(a) {
        var b = a.getStatus()
          , c = _.ry(a);
        var d = 204 == b ? !1 : "" == a.jl ? _.xf(c) : _.sy(a);
        var e = a.getAllResponseHeaders();
        e = _.Xg(e, !1);
        try {
            var f = 2 < _.py(a) ? a.La.statusText : ""
        } catch (h) {
            f = ""
        }
        return {
            result: d,
            body: c,
            headers: e,
            status: b,
            statusText: f
        }
    }
      , aB = /;\s*charset\s*=\s*("utf-?8"|utf-?8)\s*(;|$)/i
      , bB = /^(text\/[^\s;\/""]+|application\/(json(\+[^\s;\/""]*)?|([^\s;\/""]*\+)?xml))\s*(;|$)/i
      , cB = /;\s*charset\s*=/i
      , dB = /(([\r\n]{0,2}[A-Za-z0-9+\/]){4,4}){0,1024}([\r\n]{0,2}[A-Za-z0-9+\/][\r\n]{0,2}[AQgw]([\r\n]{0,2}=){2,2}|([\r\n]{0,2}[A-Za-z0-9+\/]){2,2}[\r\n]{0,2}[AEIMQUYcgkosw048][\r\n]{0,2}=|([\r\n]{0,2}[A-Za-z0-9+\/]){4,4})[\r\n]{0,2}/g
      , eB = function(a) {
        var b = [];
        a = a.replace(dB, function(c) {
            b.push(_.Zy(c));
            return ""
        });
        if (a.length)
            throw Error("za");
        return b.join("")
    }
      , fB = function(a) {
        var b = a.headers;
        if (b && "base64" === _.Vg(b, "X-Goog-Safety-Encoding")) {
            var c = eB(a.body)
              , d = _.Vg(b, "X-Goog-Safety-Content-Type");
            b["Content-Type"] = d;
            if (d.match(aB) || d.match(bB) && !d.match(cB))
                c = _.Zv(_.fh(c));
            _.Wg(b, "X-Goog-Safety-Encoding");
            _.Wg(b, "X-Goog-Safety-Content-Type");
            a.body = c
        }
    }
      , gB = function(a, b, c) {
        c || ((c = _.Ke("googleapis.config/proxy")) && (c = String(c).replace(/\/static\/proxy\.html$/, "") || "/"),
        c = String(c || ""));
        c || (c = _.Ke("googleapis.config/root"),
        b && (c = _.Ke("googleapis.config/root-1p") || c),
        c = String(c || ""));
        c = String(WA(b, c) || c);
        return a = _.Zx(c, a)
    }
      , hB = function(a, b) {
        var c = a.params || _.re();
        c.url = c.path;
        var d = c.root;
        d = gB("/", _.Rh(c.headers), d);
        d.match(/^(.*[^\/])?\/$/) && (d = d.substr(0, d.length - 1));
        c.root = d;
        a.params = c;
        _.ii.zp("makeHttpRequests", [a], function(e, f) {
            e && e.gapiRequest ? (e.gapiRequest.data ? fB(e.gapiRequest.data) : fB(e),
            b(e, _.yf(e))) : b(e, f)
        })
    }
      , iB = function(a) {
        var b = _.Qx(a, "params", "headers");
        b && "object" === typeof b || (b = {});
        a = {};
        for (var c in b)
            if (Object.prototype.hasOwnProperty.call(b, c)) {
                var d = _.Vg(b, c);
                d && (_.Tg(c, d),
                _.Wg(a, c, d))
            }
        c = "chrome-extension" == (window.location.href.match(_.nh)[1] || null);
        a = _.Rh(a);
        return !(c && a) && VA()
    }
      , jB = function(a) {
        return new _.Lj(function(b, c) {
            var d = function(e) {
                e && e.gapiRequest ? e = e.gapiRequest.data || e : c(e);
                e = {
                    result: 204 != e.status && _.xf(e.body),
                    body: e.body,
                    headers: e.headers || null,
                    status: e.status || null,
                    statusText: e.statusText || null
                };
                UA(e) ? b(e) : c(e)
            };
            try {
                hB(a, d)
            } catch (e) {
                c(e)
            }
        }
        )
    }
      , kB = function(a) {
        var b = !_.Ke("client/cors") || !!_.Ke("client/xd4")
          , c = {};
        _.am(a, function(d, e) {
            (d = _.Tg(e, d)) || b || (d = _.Sg(e));
            d && (e = _.Vg(a, d)) && _.Wg(c, d, e)
        });
        return c
    }
      , lB = function(a) {
        var b = a.params || _.re();
        a = _.mj(b.headers || {});
        var c = b.httpMethod || "GET"
          , d = String(b.url || "")
          , e = encodeURIComponent("$unique");
        if (!("POST" === c || 0 <= _.au(d, 0, "$unique", d.search(_.bu)) || 0 <= _.au(d, 0, e, d.search(_.bu)))) {
            var f = [];
            for (h in a)
                Object.prototype.hasOwnProperty.call(a, h) && f.push(h.toLowerCase());
            f.sort();
            f.push(_.pg(location.href));
            var h = f.join(":");
            f = _.Jh();
            f.update(h);
            h = f.Ih().toLowerCase().substr(0, 7);
            h = String(parseInt(h, 16) % 1E3 + 1E3).substr(1);
            d = _.Xx(d, e, "gc" + h)
        }
        e = b.body || null;
        h = b.responseType || null;
        b = _.Rh(a) || "1p" == b.authType;
        f = !!_.Ke("googleapis.config/auth/useUberProxyAuth");
        _.Wg(a, "X-Referer", void 0);
        a = kB(a);
        var k = new ZA(d,c,e,a);
        k.Dg = b || f;
        h && (k.jl = h);
        return new _.Lj(function(l, m) {
            k.then(function(n) {
                fB(n);
                l(n)
            }, function(n) {
                m(n)
            })
        }
        )
    }
      , mB = function(a, b) {
        var c = function(d) {
            d = _.mj(d);
            delete d.result;
            d = {
                gapiRequest: {
                    data: d
                }
            };
            b && b(d, _.yf(d))
        };
        lB(a).then(c, c)
    }
      , nB = function(a, b) {
        (_.Ke("client/cors") || _.Ke("client/xd4")) && iB(a) ? mB(a, b) : hB(a, b)
    }
      , oB = function(a) {
        this.Qs = a;
        this.vf = !1;
        this.promise = {
            then: (0,
            _.R)(function(b, c, d) {
                this.vf || (this.vf = !0);
                this.Ps && !this.Ns ? this.Qs.resolve(this.Ps) : this.Ns && !this.Ps && this.Qs.reject(this.Ns);
                return this.Qs.promise.then(b, c, d)
            }, this)
        }
    };
    oB.prototype.resolve = function(a) {
        this.vf ? this.Qs.resolve(a) : this.Ps || this.Ns || (this.Ps = a)
    }
    ;
    oB.prototype.reject = function(a) {
        this.vf ? this.Qs.reject(a) : this.Ps || this.Ns || (this.Ns = a)
    }
    ;
    var pB = function(a) {
        a = _.Rx(a.error);
        return {
            code: a.code,
            data: a.errors,
            message: a.message
        }
    }
      , qB = function(a) {
        throw Error("Ca`" + a);
    };
    var rB = function(a) {
        OA.call(this, rB.prototype.Qm);
        if (!a || "object" != typeof a && "string" != typeof a)
            throw new NA("Missing required parameters");
        if ("string" === typeof a) {
            var b = {};
            b.path = a
        } else
            b = a;
        if (!b.path)
            throw new NA('Missing required parameter: "path"');
        this.xh = {};
        this.xh.path = b.path;
        this.xh.method = b.method || "GET";
        this.xh.params = b.params || {};
        this.xh.headers = b.headers || {};
        this.xh.body = b.body;
        this.xh.root = b.root;
        this.xh.responseType = b.responseType;
        this.xh.apiId = b.apiId;
        this.Bl = b.authType || "auto";
        this.r_ = !!b.isXd4;
        this.IN = !1;
        this.zi(this.Bl);
        this.QP = !1
    };
    _.O(rB, OA);
    rB.prototype.Ae = function() {
        return this.xh
    }
    ;
    rB.prototype.zi = function(a) {
        this.Bl = a;
        this.IN = "1p" === this.Bl
    }
    ;
    rB.prototype.Ar = function() {
        return this.IN
    }
    ;
    rB.prototype.tj = function() {
        if (!this.QP) {
            this.QP = !0;
            var a = this.xh
              , b = a.headers = a.headers || {}
              , c = []
              , d = [];
            for (h in b)
                if (Object.prototype.hasOwnProperty.call(b, h)) {
                    c.push(h);
                    var e = h
                      , f = _.Vg(b, e);
                    f && (e = _.Tg(e, f) || _.Sg(e)) && d.push([e, f])
                }
            var h = 0;
            for (e = c.length; h < e; ++h)
                delete b[c[h]];
            c = 0;
            for (h = d.length; c < h; ++c)
                _.Wg(b, d[c][0], d[c][1]);
            if (this.r_)
                d = "1p" == this.Bl;
            else {
                d = b;
                c = String(_.Ke("client/version", "1.1.0"));
                h = String(_.Ke("client/name", "google-api-javascript-client"));
                h = !0 === sB[h] ? h : "google-api-javascript-client";
                e = String(_.Ke("client/appName", ""));
                f = [];
                e && (f.push(e),
                f.push(" "));
                f.push(h);
                c && (f.push("/"),
                f.push(c));
                _.Wg(d, "X-JavaScript-User-Agent", f.join(""));
                _.Wg(b, "X-Requested-With", "XMLHttpRequest");
                d = _.Vg(b, "Content-Type");
                a.body && !d && _.Wg(b, "Content-Type", "application/json");
                _.Ke("client/allowExecutableResponse") || _.Wg(b, "X-Goog-Encode-Response-If-Executable", "base64");
                (d = _.Vg(b, "Content-Type")) && "application/json" == d.toLowerCase() && !a.params.alt && (a.params.alt = "json");
                (d = a.body || null) && _.Bb(d) && (a.body = _.yf(d));
                a.key = a.id;
                b = _.hi(b, void 0, this.Bl);
                d = _.Rh(b);
                if ((c = b) && window.navigator) {
                    h = [];
                    for (e = 0; e < tB.length; e++)
                        (f = window.navigator[tB[e]]) && h.push(encodeURIComponent(tB[e]) + "=" + encodeURIComponent(f));
                    _.Wg(c, "X-ClientDetails", h.join("&"))
                }
                (c = _.Ke("client/apiKey")) && void 0 === a.params.key && (a.params.key = c);
                (c = _.Ke("client/trace")) && !a.params.trace && (a.params.trace = c)
            }
            "auto" == this.Bl && (d ? this.zi("1p") : (b = _.Vg(b, "Authorization")) && String(b).match(/^(Bearer|MAC)[ \t]/i) ? this.zi("oauth2") : this.zi("none"));
            if ((b = String(a.path || "").match(/^(https?:\/\/[^\/?#]+)([\/?#].*)?$/i)) && !a.root)
                if (a.root = String(b[1]),
                a.path = String(b[2] || "/"),
                a.path.match(/^\/_ah\/api(\/.*)?$/))
                    a.root += "/_ah/api",
                    a.path = a.path.substr(8);
                else {
                    b = _.Ke("googleapis.config/root");
                    d && (b = _.Ke("googleapis.config/root-1p") || b);
                    b = String(b || "");
                    c = a.root + a.path;
                    if (h = b && c.substr(0, b.length) === b)
                        h = _.tu(b),
                        e = _.tu(c),
                        h = (!h.Vd && !e.Vd || h.eg() == e.eg()) && (null == h.Pf && null == e.Pf || h.Pf == e.Pf);
                    h && (a.path = c.substr(b.length),
                    a.root = b)
                }
            b = a.params;
            c = _.Jg(a.path);
            h = String(_.Ke("googleapis.config/xd3") || "");
            18 <= h.length && "/static/proxy.html" == h.substring(h.length - 18) && (h = h.substring(0, h.length - 18));
            h || (h = "/");
            e = _.Jg(h);
            if (h != e)
                throw Error("y");
            "/" != h.charAt(h.length - 1) && (h += "/");
            c = _.Zx(h, c);
            _.Ai(c, "/") && (c = c.substring(0, c.length - 1));
            h = _.re();
            for (var k in b)
                Object.prototype.hasOwnProperty.call(b, k) && (e = encodeURIComponent(k),
                h[e] = b[k]);
            c = _.rh(c, h);
            a.path = c;
            a.root = WA(!!d, a.root);
            a.url = gB(a.path, !!d, a.root)
        }
    }
    ;
    var uB = function(a) {
        a.tj();
        var b = a.xh;
        return {
            key: "gapiRequest",
            params: {
                id: b.id,
                key: b.key,
                url: b.url,
                path: b.path,
                httpMethod: b.method,
                body: b.body || "",
                headers: b.headers || {},
                urlParams: {},
                root: b.root,
                authType: a.Bl
            }
        }
    };
    rB.prototype.execute = function(a) {
        var b = uB(this);
        nB(b, function(c, d) {
            var e = c;
            c.gapiRequest && (e = c.gapiRequest);
            e && e.data && (e = e.data);
            c = e instanceof Array ? e[0] : e;
            if (204 != c.status && c.body)
                try {
                    var f = _.xf(c.body)
                } catch (h) {}
            a && a(f, d)
        })
    }
    ;
    rB.prototype.Qm = function() {
        var a = uB(this);
        return (_.Ke("client/cors") || _.Ke("client/xd4")) && iB(a) ? lB(a) : jB(a)
    }
    ;
    rB.prototype.Sh = function() {
        return this.Qm()
    }
    ;
    var tB = ["appVersion", "platform", "userAgent"]
      , sB = {
        "google-api-gwt-client": !0,
        "google-api-javascript-client": !0
    };
    rB.prototype.execute = rB.prototype.execute;
    rB.prototype.then = rB.prototype.then;
    rB.prototype.getPromise = rB.prototype.Sh;
    var vB = function(a) {
        if (!a || "object" != typeof a)
            throw new NA("Missing rpc parameters");
        if (!a.method)
            throw new NA("Missing rpc method");
        this.Dy = a
    };
    vB.prototype.dm = function() {
        var a = this.Dy.transport;
        return a ? a.root || null : null
    }
    ;
    vB.prototype.execute = function(a) {
        var b = RA();
        b.add(this, {
            id: "gapiRpc",
            callback: this.ls(a)
        });
        b.execute()
    }
    ;
    vB.prototype.xx = function(a) {
        var b = this.Dy.method, c = String, d;
        (d = this.Dy.apiVersion) || (d = String(b).split(".")[0],
        d = _.Ke("googleapis.config/versions/" + b) || _.Ke("googleapis.config/versions/" + d) || "v1",
        d = String(d));
        a = {
            jsonrpc: "2.0",
            id: a,
            method: b,
            apiVersion: c(d)
        };
        (b = this.Dy.rpcParams) && (a.params = b);
        return a
    }
    ;
    vB.prototype.ls = function(a) {
        return function(b, c) {
            if (b)
                if (b.error) {
                    var d = b.error;
                    null == d.error && (d.error = _.mj(b.error))
                } else
                    d = b.result || b.data,
                    _.Bb(d) && null == d.result && (d.result = _.mj(b.result || b.data));
            else
                d = !1;
            a(d, c)
        }
    }
    ;
    vB.prototype.execute = vB.prototype.execute;
    var xB = function(a, b) {
        this.Wd = b || 0;
        2 == this.Wd ? (b = null,
        null != a && _.Bb(a) && (b = {},
        b.method = a.method,
        b.rpcParams = a.rpcParams,
        b.transport = a.transport,
        b.root = a.root,
        b.apiVersion = a.apiVersion,
        b.authType = a.authType),
        this.lb = new vB(b)) : (0 == this.Wd && (b = a && a.callback) && (a.callback = wB(b)),
        b = null,
        null != a && (_.Bb(a) ? (b = {},
        b.path = a.path,
        b.method = a.method,
        b.params = a.params,
        b.headers = a.headers,
        b.body = a.body,
        b.root = a.root,
        b.responseType = a.responseType,
        b.authType = a.authType,
        b.apiId = a.apiId) : "string" === typeof a && (b = a)),
        this.lb = new rB(b))
    }
      , wB = function(a) {
        return function(b) {
            if (null != b && _.Bb(b) && b.error) {
                var c = pB(b);
                b = _.yf([{
                    id: "gapiRpc",
                    error: c
                }]);
                c.error = _.Rx(c)
            } else
                null == b && (b = {}),
                c = _.Rx(b),
                c.result = _.Rx(b),
                b = _.yf([{
                    id: "gapiRpc",
                    result: b
                }]);
            a(c, b)
        }
    };
    _.g = xB.prototype;
    _.g.getFormat = function() {
        return this.Wd
    }
    ;
    _.g.execute = function(a) {
        this.lb.execute(a && 1 == this.Wd ? wB(a) : a)
    }
    ;
    _.g.then = function(a, b, c) {
        2 == this.Wd && qB('The "then" method is not available on this object.');
        return this.lb.then(a, b, c)
    }
    ;
    _.g.kz = function(a) {
        this.lb.kz && this.lb.kz(a)
    }
    ;
    _.g.Ae = function() {
        if (this.lb.Ae)
            return this.lb.Ae()
    }
    ;
    _.g.tj = function() {
        this.lb.Ae && this.lb.tj()
    }
    ;
    _.g.dm = function() {
        if (this.lb.dm)
            return this.lb.dm()
    }
    ;
    _.g.xx = function(a) {
        if (this.lb.xx)
            return this.lb.xx(a)
    }
    ;
    _.g.zi = function(a) {
        this.lb.zi && this.lb.zi(a)
    }
    ;
    _.g.Ar = function() {
        return this.lb.Ar()
    }
    ;
    _.g.Sh = function() {
        if (this.lb.Sh)
            return this.lb.Sh()
    }
    ;
    xB.prototype.execute = xB.prototype.execute;
    xB.prototype.then = xB.prototype.then;
    xB.prototype.getPromise = xB.prototype.Sh;
    var yB = /<response-(.*)>/
      , zB = /^application\/http(;.+$|$)/
      , AB = ["clients6.google.com", "content.googleapis.com", "www.googleapis.com"]
      , BB = function(a, b) {
        a = _.Vg(a, b);
        if (!a)
            throw new NA("Unable to retrieve header.");
        return a
    }
      , CB = function(a) {
        var b = void 0;
        a = _.Ba(a);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value.Ae().apiId;
            if ("string" !== typeof c)
                return "batch";
            if (void 0 === b)
                b = c;
            else if (b != c)
                return "batch"
        }
        b = _.Ke("client/batchPath/" + b) || "batch/" + b.split(":").join("/");
        return String(b)
    }
      , DB = function(a) {
        a = a.map(function(b) {
            return b.request
        });
        return CB(a)
    }
      , EB = function(a, b) {
        var c = [];
        a = a.Ae();
        var d = function(f, h) {
            _.am(f, function(k, l) {
                h.push(l + ": " + k)
            })
        }
          , e = {
            "Content-Type": "application/http",
            "Content-Transfer-Encoding": "binary"
        };
        e["Content-ID"] = "<" + b + ">";
        d(e, c);
        c.push("");
        c.push(a.method + " " + a.path);
        d(a.headers, c);
        c.push("");
        a.body && c.push(a.body);
        return c.join("\r\n")
    }
      , HB = function(a, b) {
        a = FB(a, b);
        var c = {};
        _.nb(a, function(d, e) {
            c[e] = GB(d, e)
        });
        return c
    }
      , GB = function(a, b) {
        return {
            result: a.result || a.body,
            rawResult: _.yf({
                id: b,
                result: a.result || a.body
            }),
            id: b
        }
    }
      , FB = function(a, b) {
        a = (0,
        _.oc)(a);
        _.Ai(a, "--") && (a = a.substring(0, a.length - 2));
        a = a.split(b);
        b = _.re();
        for (var c = 0; c < a.length; c++)
            if (a[c]) {
                var d;
                if (d = a[c]) {
                    _.Ai(d, "\r\n") && (d = d.substring(0, d.length - 2));
                    if (d) {
                        d = d.split("\r\n");
                        for (var e = 0, f = {
                            headers: {},
                            body: ""
                        }; e < d.length && "" == d[e]; )
                            e++;
                        for (f.outerHeaders = IB(d, e); e < d.length && "" != d[e]; )
                            e++;
                        e++;
                        var h = d[e++].split(" ");
                        f.status = Number(h[1]);
                        f.statusText = h.slice(2).join(" ");
                        for (f.headers = IB(d, e); e < d.length && "" != d[e]; )
                            e++;
                        e++;
                        f.body = d.slice(e).join("\r\n");
                        fB(f);
                        d = f
                    } else
                        d = null;
                    e = _.re();
                    f = BB(d.outerHeaders, "Content-Type");
                    if (null == zB.exec(f))
                        throw new NA("Unexpected Content-Type <" + f + ">");
                    f = BB(d.outerHeaders, "Content-ID");
                    f = yB.exec(f);
                    if (!f)
                        throw new NA("Unable to recognize Content-Id.");
                    e.id = decodeURIComponent(f[1].split("@")[0].replace(/^.*[+]/, ""));
                    e.response = {
                        status: d.status,
                        statusText: d.statusText,
                        headers: d.headers
                    };
                    204 != d.status && (e.response.body = d.body,
                    e.response.result = _.xf(d.body));
                    d = e
                } else
                    d = null;
                d && d.id && (b[d.id] = d.response)
            }
        return b
    }
      , IB = function(a, b) {
        for (var c = []; b < a.length && a[b]; b++)
            c.push(a[b]);
        return _.Xg(c.join("\r\n"), !1)
    }
      , JB = function(a, b, c) {
        a = a || b;
        if (!a || "https" !== _.tu(a).Sf)
            if (a = c ? _.Ke("googleapis.config/root-1p") : _.Ke("googleapis.config/root"),
            !a)
                return !1;
        a = WA(c, String(a)) || a;
        return AB.includes(_.tu(a).eg())
    };
    var KB = function(a) {
        OA.call(this, KB.prototype.Qm);
        this.$i = {};
        this.Au = {};
        this.dl = [];
        this.Ke = a;
        this.O_ = !!a;
        this.PM = this.Aw = !1
    };
    _.O(KB, OA);
    var LB = function(a, b) {
        a = _.Ba(Object.values(a.$i));
        for (var c = a.next(); !c.done; c = a.next())
            if (c.value.map(function(d) {
                return d.id
            }).includes(b))
                return !0;
        return !1
    }
      , MB = function(a) {
        (function(b) {
            setTimeout(function() {
                throw b;
            })
        }
        )(a)
    };
    KB.prototype.add = function(a, b) {
        var c = b || _.re();
        b = _.re();
        if (!a)
            throw new NA("Batch entry " + (_.se(c, "id") ? '"' + c.id + '" ' : "") + "is missing a request method");
        a.tj();
        b.request = a;
        var d = _.Vj();
        d = new oB(d);
        b.Ay = d;
        a.kz(b.Ay.promise);
        d = a.Ae().headers;
        _.Rh(d) && (this.Aw = !0);
        (d = String((d || {}).Authorization || "") || null) && d.match(/^Bearer|MAC[ \t]/i) && (this.PM = !0);
        d = a.Ae().root;
        if (!this.O_) {
            if (d && this.Ke && d != this.Ke)
                throw new NA('The "root" provided in this request is not consistent with that of existing requests in the batch.');
            this.Ke = d || this.Ke
        }
        if (_.se(c, "id")) {
            d = c.id;
            if (LB(this, d))
                throw new NA('Batch ID "' + d + '" already in use, please use another.');
            b.id = d
        } else {
            do
                b.id = String(Math.round(2147483647 * _.ai()));
            while (LB(this, b.id))
        }
        b.callback = c.callback;
        c = "batch";
        JB(this.Ke, a.Ae().path, this.Aw) && (c = DB([b]));
        this.$i[c] = this.$i[c] || [];
        this.$i[c].push(b);
        this.Au[b.id] = b;
        return b.id
    }
    ;
    var NB = function(a) {
        var b = []
          , c = JB(a.Ke, void 0, a.Aw);
        1 < Object.entries(a.$i).length && _.Df.warn("Heterogeneous batch requests are deprecated. See https://developers.googleblog.com/2018/03/discontinuing-support-for-json-rpc-and.html");
        for (var d = _.Ba(Object.entries(a.$i)), e = d.next(); !e.done; e = d.next()) {
            e = _.Ba(e.value);
            var f = e.next().value;
            e = e.next().value;
            for (var h = !0, k = _.Ba(e), l = k.next(); !l.done; l = k.next())
                l = l.value,
                l.request.tj(),
                "batch" === f && c && (h = !1,
                l.i_ = !0,
                l.request.Ae.root = a.Ke,
                b.push(l.request),
                a.dl.push([l]));
            if (h) {
                f = a.Ke;
                h = a.Aw;
                k = a.PM;
                l = "batch" + String(Math.round(2147483647 * _.ai())) + String(Math.round(2147483647 * _.ai()));
                var m = "--" + l;
                l = "multipart/mixed; boundary=" + l;
                for (var n = {
                    path: DB(e),
                    method: "POST"
                }, q = [], p = 0; p < e.length; p++)
                    q.push(EB(e[p].request, [m.substr(m.indexOf("--") + 2), "+", encodeURIComponent(e[p].id).split("(").join("%28").split(")").join("%29").split(".").join("%2E"), "@googleapis.com"].join("")));
                n.body = [m, q.join("\r\n" + m + "\r\n"), m + "--"].join("\r\n") + "\r\n";
                n.root = f || null;
                _.Ke("client/xd4") && VA() ? (n.isXd4 = !0,
                n.params = {
                    $ct: l
                },
                n.headers = {},
                _.Wg(n.headers, "Content-Type", "text/plain; charset=UTF-8"),
                h ? n.authType = "1p" : k && (n.authType = "oauth2"),
                f = new rB(n)) : (n.headers = {},
                _.Wg(n.headers, "Content-Type", l),
                f = SA(n));
                b.push(f);
                a.dl.push(e)
            }
        }
        return b
    };
    KB.prototype.execute = function(a) {
        if (!(1 > Object.keys(this.$i).length)) {
            var b = this.ls(a);
            a = NB(this);
            var c = []
              , d = a.map(function(e) {
                return new _.Lj(function(f) {
                    try {
                        e.execute(function(h, k) {
                            return f({
                                IJ: h,
                                l1: k
                            })
                        })
                    } catch (h) {
                        c.push(h),
                        f({
                            IJ: {
                                zv: !1,
                                reason: h
                            }
                        })
                    }
                }
                )
            });
            if (0 < c.length && c.length === a.length)
                throw c[0];
            _.Tj(d).then(function(e) {
                var f = e.map(function(h) {
                    return h.l1
                });
                e = e.map(function(h) {
                    return h.IJ
                });
                b(e, f)
            })
        }
    }
    ;
    KB.prototype.Qm = function() {
        var a = this;
        if (1 > Object.keys(this.$i).length)
            return _.Pj({});
        var b = NB(this).map(function(c) {
            return new _.Lj(function(d, e) {
                return c.Sh().then(d, e)
            }
            )
        });
        return PA(b).then(function(c) {
            c = c.map(function(d) {
                return d.zv ? d.value : d
            });
            return OB(a, c, !0)
        })
    }
    ;
    var OB = function(a, b, c, d, e) {
        for (var f = !1, h = {}, k, l = 0, m = 0; m < b.length; m++) {
            var n = b[m];
            if (!1 === n.zv) {
                l++;
                b[m] = n.reason;
                for (var q = PB([b[m]]), p = _.Ba(a.dl[m]), t = p.next(); !t.done; t = p.next())
                    h[t.value.id] = q
            } else {
                if (1 > a.dl[m].length)
                    throw new NA("Error processing batch responses.");
                try {
                    var v = !(1 === a.dl[m].length && a.dl[m][0].i_)
                      , u = a.dl[m][0].id;
                    if (!c) {
                        t = n;
                        var w = d[m];
                        q = t;
                        if (w && (!q || !v)) {
                            var z = _.xf(w);
                            z && (q = z.gapiRequest ? z.gapiRequest.data : z,
                            !v && t && (q.body = t))
                        }
                        if (!q)
                            throw new NA("The batch response is missing.");
                        n = q
                    }
                    t = void 0;
                    if (q = n) {
                        var E = q.headers;
                        if (E) {
                            var A = _.re();
                            for (t in E)
                                if (Object.prototype.hasOwnProperty.call(E, t)) {
                                    var y = _.Vg(E, t);
                                    _.Wg(A, t, y, !0)
                                }
                            q.headers = A
                        }
                    }
                    if (v && 0 != BB(n.headers, "Content-Type").indexOf("multipart/mixed"))
                        throw new NA("The response's Content-Type is not multipart/mixed.");
                    k = k || _.Rx(n);
                    var J = UA(n);
                    J && !UA(k) && (k.status = n.status,
                    k.statusText = n.statusText);
                    if (J || c || !v) {
                        f = !0;
                        t = Object;
                        var Q = t.assign;
                        q = h;
                        p = a;
                        var T = n
                          , M = c;
                        n = {};
                        if (v) {
                            M = M ? FB : HB;
                            var L = BB(T.headers, "Content-Type").split("boundary=")[1];
                            if (!L)
                                throw new NA("Boundary not indicated in response.");
                            n = M(T.body, "--" + L)
                        } else
                            M ? (T.result = _.xf(T.body),
                            n[u] = T) : n[u] = GB(T, u);
                        T = {};
                        for (var V = _.Ba(Object.entries(n)), oa = V.next(); !oa.done; oa = V.next()) {
                            var ia = _.Ba(oa.value)
                              , ra = ia.next().value
                              , Ka = ia.next().value;
                            T[ra] = Ka;
                            if (!p.Au[ra])
                                throw new NA("Could not find batch entry for id " + ra + ".");
                        }
                        h = Q.call(t, q, T)
                    }
                } catch (Ga) {
                    for (l++,
                    b[m] = Ga,
                    q = PB([Ga]),
                    p = _.Ba(a.dl[m]),
                    t = p.next(); !t.done; t = p.next())
                        h[t.value.id] = q
                }
            }
        }
        if (l === b.length) {
            d = PB(b);
            h = _.yf(d);
            k = 0;
            a = Array.from(Object.values(a.$i)).flat();
            f = _.Ba(a);
            for (l = f.next(); !l.done; l = f.next())
                if (l = l.value,
                c)
                    l.Ay.reject(d);
                else if (l.callback)
                    try {
                        k++,
                        l.callback(d, h)
                    } catch (Ga) {
                        MB(Ga)
                    }
            if (e)
                try {
                    e(d, h)
                } catch (Ga) {
                    MB(Ga)
                }
            else if (k !== a.length)
                throw 1 === b.length ? b[0] : d;
        } else {
            if (f)
                for (f = _.Ba(Object.entries(h)),
                l = f.next(); !l.done; l = f.next())
                    if (l = _.Ba(l.value),
                    m = l.next().value,
                    l = l.next().value,
                    c)
                        m = a.Au[m],
                        l && UA(l) ? m.Ay.resolve(l) : m.Ay.reject(l);
                    else if (m = a.Au[m],
                    m.callback) {
                        if (l && l.rawResult)
                            try {
                                delete l.rawResult
                            } catch (Ga) {}
                        try {
                            m.callback(l || !1, _.yf(l))
                        } catch (Ga) {
                            MB(Ga)
                        }
                    }
            k.result = h || {};
            k.body = 1 === b.length ? k.body : "";
            if (e)
                try {
                    e(h || null, 1 === d.length ? d[0] : null)
                } catch (Ga) {
                    MB(Ga)
                }
            return k
        }
    }
      , PB = function(a) {
        var b = {
            error: {
                code: 0,
                message: "The batch request could not be fulfilled.  "
            }
        };
        a = _.Ba(a);
        for (var c = a.next(); !c.done; c = a.next())
            (c = c.value) && c.message || c instanceof Error && c.message ? b.error.message += (c.message || c instanceof Error && c.message) + "  " : c && c.error && c.error.message && (b.error.message += c.error.message + "  ",
            b.error.code = c.error.code || b.error.code || 0);
        b.error.message = b.error.message.trim();
        return {
            result: b,
            body: _.yf(b),
            headers: null,
            status: null,
            statusText: null
        }
    };
    KB.prototype.ls = function(a) {
        var b = this;
        return function(c, d) {
            b.KA(c, d, a)
        }
    }
    ;
    KB.prototype.KA = function(a, b, c) {
        OB(this, a, !1, b, c)
    }
    ;
    KB.prototype.add = KB.prototype.add;
    KB.prototype.execute = KB.prototype.execute;
    KB.prototype.then = KB.prototype.then;
    var QB = function() {
        this.jk = [];
        this.Ke = this.Ie = null
    };
    QB.prototype.add = function(a, b) {
        b = b || {};
        var c = {}
          , d = Object.prototype.hasOwnProperty;
        if (a)
            c.Vm = a;
        else
            throw new NA("Batch entry " + (d.call(b, "id") ? '"' + b.id + '" ' : "") + "is missing a request method");
        if (d.call(b, "id")) {
            a = b.id;
            for (d = 0; d < this.jk.length; d++)
                if (this.jk[d].id == a)
                    throw new NA('Batch ID "' + a + '" already in use, please use another.');
            c.id = a
        } else {
            do
                c.id = String(2147483647 * _.ai() | 0);
            while (d.call(this.jk, c.id))
        }
        c.callback = b.callback;
        this.jk.push(c);
        return c.id
    }
    ;
    var RB = function(a) {
        return function(b) {
            var c = b.body;
            if (b = b.result) {
                for (var d = {}, e = 0, f = b.length; e < f; ++e)
                    d[b[e].id] = b[e];
                a(d, c)
            } else
                a(b, c)
        }
    };
    QB.prototype.execute = function(a) {
        this.Ie = [];
        for (var b, c, d = 0; d < this.jk.length; d++)
            b = this.jk[d],
            c = b.Vm,
            this.Ie.push(c.xx(b.id)),
            this.Ke = c.dm() || this.Ke;
        c = this.ls(a);
        a = {
            requests: this.Ie,
            root: this.Ke
        };
        b = {};
        d = a.headers || {};
        for (var e in d) {
            var f = e;
            if (Object.prototype.hasOwnProperty.call(d, f)) {
                var h = _.Vg(d, f);
                h && (f = _.Tg(f, h) || _.Sg(f)) && _.Wg(b, f, h)
            }
        }
        _.Wg(b, "Content-Type", "application/json");
        e = RB(c);
        SA({
            method: "POST",
            root: a.root || void 0,
            path: "/rpc",
            params: a.urlParams,
            headers: b,
            body: a.requests || []
        }).then(e, e)
    }
    ;
    QB.prototype.ls = function(a) {
        var b = this;
        return function(c, d) {
            b.KA(c, d, a)
        }
    }
    ;
    QB.prototype.KA = function(a, b, c) {
        a || (a = {});
        for (var d = 0; d < this.jk.length; d++) {
            var e = this.jk[d];
            e.callback && e.callback(a[e.id] || !1, b)
        }
        c && c(a, b)
    }
    ;
    TA.LJ(function() {
        return new QB
    });
    QB.prototype.add = QB.prototype.add;
    QB.prototype.execute = QB.prototype.execute;
    var SB = function(a, b) {
        this.N0 = a;
        this.Wd = b || null;
        this.yq = null
    };
    SB.prototype.yD = function(a) {
        this.Wd = a;
        this.yq = 2 == this.Wd ? new QB : new KB(this.N0)
    }
    ;
    SB.prototype.add = function(a, b) {
        if (!a)
            throw a = b || _.re(),
            new NA("Batch entry " + (_.se(a, "id") ? '"' + a.id + '" ' : "") + "is missing a request method");
        null === this.Wd && this.yD(a.getFormat());
        this.Wd !== a.getFormat() && qB("Unable to add item to batch.");
        var c = b && b.callback;
        1 == this.Wd && c && (b.callback = function(d) {
            d = TB(d);
            var e = _.yf([d]);
            c(d, e)
        }
        );
        return this.yq.add(a, b)
    }
    ;
    SB.prototype.execute = function(a) {
        var b = a && 1 == this.Wd ? function(c) {
            var d = [];
            _.am(c, function(f, h) {
                f = TB(f);
                c[h] = f;
                d.push(f)
            });
            var e = _.yf(d);
            a(c, e)
        }
        : a;
        this.yq && this.yq.execute(b)
    }
    ;
    var TB = function(a) {
        var b = a ? _.Qx(a, "result") : null;
        _.Bb(b) && null != b.error && (b = pB(b),
        a = {
            id: a.id,
            error: b
        });
        return a
    };
    SB.prototype.then = function(a, b, c) {
        2 == this.Wd && qB('The "then" method is not available on this object.');
        return this.yq.then(a, b, c)
    }
    ;
    SB.prototype.add = SB.prototype.add;
    SB.prototype.execute = SB.prototype.execute;
    SB.prototype.then = SB.prototype.then;
    var UB = function(a) {
        OA.call(this, UB.prototype.Qm);
        this.lb = a
    };
    _.O(UB, OA);
    var VB = function(a) {
        a.lb.tj();
        var b = a.lb
          , c = b.Ae();
        return !(JB(c.root, c.path, a.lb.Ar()) ? "batch" !== CB([b]) : 1)
    };
    _.g = UB.prototype;
    _.g.execute = function(a) {
        var b = this;
        if (VB(this))
            this.lb.execute(a);
        else {
            var c = function(d) {
                if ("function" === typeof a) {
                    var e = {
                        gapiRequest: {
                            data: {
                                status: d && d.status,
                                statusText: d && d.statusText,
                                headers: d && d.headers,
                                body: d && d.body
                            }
                        }
                    };
                    if (1 === b.getFormat()) {
                        a = wB(a);
                        var f = {}
                    }
                    var h = d ? d.result : !1;
                    d && 204 == d.status && (h = f,
                    delete e.gapiRequest.data.body);
                    a(h, _.yf(e))
                }
            };
            this.Sh().then(c, c)
        }
    }
    ;
    _.g.Qm = function() {
        return VB(this) ? this.lb.Sh() : new _.Lj(function(a, b) {
            var c = QA()
              , d = c.add(this.lb, {
                id: "gapiRequest"
            });
            c.then(function(e) {
                var f = e.result;
                if (f && (f = f[d])) {
                    Object.prototype.hasOwnProperty.call(f, "result") || (f.result = !1);
                    Object.prototype.hasOwnProperty.call(f, "body") || (f.body = "");
                    UA(f) ? a(f) : b(f);
                    return
                }
                b(e)
            }, b)
        }
        ,this)
    }
    ;
    _.g.Ae = function() {
        if (this.lb.Ae)
            return this.lb.Ae()
    }
    ;
    _.g.tj = function() {
        this.lb.tj && this.lb.tj()
    }
    ;
    _.g.dm = function() {
        if (this.lb.dm)
            return this.lb.dm()
    }
    ;
    _.g.zi = function(a) {
        this.lb.zi && this.lb.zi(a)
    }
    ;
    _.g.Ar = function() {
        return this.lb.Ar()
    }
    ;
    _.g.getFormat = function() {
        return this.lb.getFormat ? this.lb.getFormat() : 0
    }
    ;
    _.g.Sh = function() {
        return this.Qm()
    }
    ;
    UB.prototype.execute = UB.prototype.execute;
    UB.prototype.then = UB.prototype.then;
    UB.prototype.getPromise = UB.prototype.Sh;
    var WB = "/rest?fields=" + encodeURIComponent("kind,name,version,rootUrl,servicePath,resources,parameters,methods,batchPath,id") + "&pp=0"
      , XB = function(a, b) {
        return "/discovery/v1/apis/" + (encodeURIComponent(a) + "/" + encodeURIComponent(b) + WB)
    }
      , ZB = function(a, b, c, d) {
        if (_.Bb(a)) {
            var e = a;
            var f = a.name;
            a = a.version || "v1"
        } else
            f = a,
            a = b;
        if (!f || !a)
            throw new NA("Missing required parameters.");
        var h = c || function() {}
          , k = _.Bb(d) ? d : {};
        c = function(l) {
            var m = l && l.result;
            if (!m || m.error || !m.name || !l || l.error || l.message || l.message)
                h(m && m.error ? m : l && (l.error || l.message || l.message) ? l : new NA("API discovery response missing required fields."));
            else {
                l = k.root;
                l = null != m.rootUrl ? String(m.rootUrl) : l;
                l = "string" === typeof l ? l.replace(/([^\/])\/$/, "$1") : void 0;
                k.root = l;
                m.name && m.version && !m.id && (m.id = [m.name, m.version].join(":"));
                m.id && (k.apiId = m.id,
                l = "client/batchPath/" + m.id,
                m.batchPath && !_.Ke(l) && _.Le(l, m.batchPath));
                var n = m.servicePath
                  , q = m.parameters
                  , p = function(v) {
                    _.am(v, function(u) {
                        if (!(u && u.id && u.path && u.httpMethod))
                            throw new NA("Missing required parameters");
                        var w = u.id.split("."), z = window.gapi.client, E;
                        for (E = 0; E < w.length - 1; E++) {
                            var A = w[E];
                            z[A] = z[A] || {};
                            z = z[A]
                        }
                        var y, J;
                        k && (k.hasOwnProperty("root") && (y = k.root),
                        k.hasOwnProperty("apiId") && (J = k.apiId));
                        A = window.gapi.client[w[0]];
                        A.mI || (A.mI = {
                            servicePath: n || "",
                            parameters: q,
                            apiId: J
                        });
                        w = w[E];
                        z[w] || (z[w] = _.ri(YB, {
                            path: "string" === typeof u.path ? u.path : null,
                            httpMethod: "string" === typeof u.httpMethod ? u.httpMethod : null,
                            parameters: u.parameters,
                            parameterName: (u.request || {}).parameterName || "",
                            request: u.request,
                            root: y
                        }, A.mI))
                    })
                }
                  , t = function(v) {
                    _.am(v, function(u) {
                        p(u.methods);
                        t(u.resources)
                    })
                };
                t(m.resources);
                p(m.methods);
                h.call()
            }
        }
        ;
        e ? c({
            result: e
        }) : 0 < f.indexOf("://") ? SA({
            path: f,
            params: {
                pp: 0,
                fields: 0 <= ("/" + f).indexOf("/discovery/v1/apis/") ? "kind,name,version,rootUrl,servicePath,resources,parameters,methods,batchPath,id" : 'fields["kind"],fields["name"],fields["version"],fields["rootUrl"],fields["servicePath"],fields["resources"],fields["parameters"],fields["methods"],fields["batchPath"],fields["id"]'
            }
        }).then(c, c) : SA({
            path: XB(f, a),
            root: d && d.root
        }).then(c, c)
    }
      , YB = function(a, b, c, d, e) {
        e = void 0 === e ? {} : e;
        var f = b.servicePath || "";
        _.mc(f, "/") || (f = "/" + f);
        var h = $B(a.path, [a.parameters, b.parameters], c || {});
        c = h.Yk;
        var k = h.m4;
        f = _.Zx(f, h.path);
        h = k.root;
        delete k.root;
        var l = a.parameterName;
        !l && 1 == _.St(k) && k.hasOwnProperty("resource") && (l = "resource");
        if (l) {
            var m = k[l];
            delete k[l]
        }
        null == m && (m = d);
        null == m && a.request && (_.yi(k) && (k = void 0),
        m = k);
        e = e || {};
        l = a.httpMethod;
        "GET" == l && void 0 !== m && "" != String(m) && (_.Wg(e, "X-HTTP-Method-Override", l),
        l = "POST");
        if ((null == m || null != d) && k)
            for (var n in k)
                "string" === typeof k[n] && (c[n] = k[n]);
        return SA({
            path: f,
            method: l,
            params: c,
            headers: e,
            body: m,
            root: h || a.root,
            apiId: b.apiId
        }, 1)
    }
      , $B = function(a, b, c) {
        c = _.mj(c);
        var d = {};
        _.$l(b, function(e) {
            _.am(e, function(f, h) {
                var k = f.required;
                if ("path" == f.location)
                    if (Object.prototype.hasOwnProperty.call(c, h))
                        _.pb(a, "{" + h + "}") ? (f = encodeURIComponent(String(c[h])),
                        a = a.replace("{" + h + "}", f)) : _.pb(a, "{+" + h + "}") && (f = encodeURI(String(c[h])),
                        a = a.replace("{+" + h + "}", f)),
                        delete c[h];
                    else {
                        if (k)
                            throw new NA("Required path parameter " + h + " is missing.");
                    }
                else
                    "query" == f.location && Object.prototype.hasOwnProperty.call(c, h) && (d[h] = c[h],
                    delete c[h])
            })
        });
        if (b = c.trace)
            d.trace = b,
            delete c.trace;
        return {
            path: a,
            Yk: d,
            m4: c
        }
    };
    var aC = function(a, b, c, d) {
        var e = b || "v1"
          , f = _.Bb(d) ? d : {
            root: d
        };
        if (c)
            ZB(a, e, function(h) {
                if (h)
                    if (h.error)
                        c(h);
                    else {
                        var k = "API discovery was unsuccessful.";
                        if (h.message || h.message)
                            k = h.message || h.message;
                        c({
                            error: k,
                            code: 0
                        })
                    }
                else
                    c()
            }, f);
        else
            return new _.Lj(function(h, k) {
                var l = function(m) {
                    m ? k(m) : h()
                };
                try {
                    ZB(a, e, l, f)
                } catch (m) {
                    k(m)
                }
            }
            )
    }
      , bC = new RegExp(/^((([Hh][Tt][Tt][Pp][Ss]?:)?\/\/[^\/?#]*)?\/)?/.source + /(_ah\/api\/)?(batch|rpc)(\/|\?|#|$)/.source)
      , cC = function(a, b) {
        if (!a)
            throw new NA("Missing required parameters");
        var c = "object" === typeof a ? a : {
            path: a
        };
        a = c.callback;
        delete c.callback;
        b = new xB(c,b);
        if (c = !!_.Ke("client/xd4") && VA()) {
            var d = b.Ae();
            c = d.path;
            (d = d.root) && "/" !== d.charAt(d.length - 1) && (d += "/");
            d && c && c.substr(0, d.length) === d && (c = c.substr(d.length));
            c = !c.match(bC)
        }
        c && (b = new UB(b));
        return a ? (b.execute(a),
        null) : b
    };
    TA.MJ(function(a) {
        return cC.apply(null, arguments)
    });
    var dC = function(a, b) {
        if (!a)
            throw new NA("Missing required parameters");
        for (var c = a.split("."), d = window.gapi.client, e = 0; e < c.length - 1; e++) {
            var f = c[e];
            d[f] = d[f] || {};
            d = d[f]
        }
        c = c[c.length - 1];
        if (!d[c]) {
            var h = b || {};
            d[c] = function(k) {
                var l = "string" == typeof h ? h : h.root;
                k && k.root && (l = k.root);
                return new xB({
                    method: a,
                    apiVersion: h.apiVersion,
                    rpcParams: k,
                    transport: {
                        name: "googleapis",
                        root: l
                    }
                },2)
            }
        }
    }
      , eC = function(a) {
        return new SB(a)
    };
    TA.KJ(function(a) {
        return eC.apply(null, arguments)
    });
    var fC = function(a) {
        if (_.Fh.JSONRPC_ERROR_MOD)
            throw new NA(a + " is discontinued. See https://developers.googleblog.com/2018/03/discontinuing-support-for-json-rpc-and.html");
        _.Df.log(a + " is deprecated. See https://developers.google.com/api-client-library/javascript/reference/referencedocs")
    };
    _.I("gapi.client.init", function(a) {
        a.apiKey && _.Le("client/apiKey", a.apiKey);
        var b = _.Tb(a.discoveryDocs || [], function(d) {
            return aC(d)
        });
        if ((a.clientId || a.client_id) && a.scope) {
            var c = new _.Lj(function(d, e) {
                var f = function() {
                    _.D.gapi.auth2.init.call(_.D.gapi.auth2, a).then(function() {
                        d()
                    }, e)
                };
                _.D.gapi.load("auth2", {
                    callback: function() {
                        f()
                    },
                    onerror: function(h) {
                        e(h || Error("Da"))
                    }
                })
            }
            );
            b.push(c)
        } else
            (a.clientId || a.client_id || a.scope) && _.Df.log("client_id and scope must both be provided to initialize OAuth.");
        return _.Tj(b).then(function() {})
    });
    _.I("gapi.client.load", aC);
    _.I("gapi.client.newBatch", eC);
    _.I("gapi.client.newRpcBatch", function() {
        fC("gapi.client.newRpcBatch");
        return eC()
    });
    _.I("gapi.client.newHttpBatch", function(a) {
        fC("gapi.client.newHttpBatch");
        return new SB(a,0)
    });
    _.I("gapi.client.register", function(a, b) {
        fC("gapi.client.register");
        var c;
        b && (c = {
            apiVersion: b.apiVersion,
            root: b.root
        });
        dC(a, c)
    });
    _.I("gapi.client.request", cC);
    _.I("gapi.client.rpcRequest", function(a, b, c) {
        fC("gapi.client.rpcRequest");
        if (!a)
            throw new NA('Missing required parameter "method".');
        return new xB({
            method: a,
            apiVersion: b,
            rpcParams: c,
            transport: {
                name: "googleapis",
                root: c && c.root || ""
            }
        },2)
    });
    _.I("gapi.client.setApiKey", function(a) {
        _.Le("client/apiKey", a);
        _.Le("googleapis.config/developerKey", a)
    });
    _.I("gapi.client.setApiVersions", function(a) {
        fC("gapi.client.setApiVersions");
        _.Le("googleapis.config/versions", a)
    });
    _.I("gapi.client.getToken", function(a) {
        return _.Uh(a)
    });
    _.I("gapi.client.setToken", function(a, b) {
        a ? _.aw(a, b) : _.bw(b)
    });
    _.I("gapi.client.AuthType", {
        W4: "auto",
        NONE: "none",
        Q8: "oauth2",
        W6: "1p"
    });
    _.I("gapi.client.AuthType.AUTO", "auto");
    _.I("gapi.client.AuthType.NONE", "none");
    _.I("gapi.client.AuthType.OAUTH2", "oauth2");
    _.I("gapi.client.AuthType.FIRST_PARTY", "1p");

});
// Google Inc.
